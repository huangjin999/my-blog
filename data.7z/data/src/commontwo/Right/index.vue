<template>
  <!-- <dv-border-box-8> -->
  <div class="ech-box">
    <div class="calendar-wrap">
      <div class="calendar-header">
        <div class="calendar-header-content">
          <!-- <span class="calendar-header-dir calendar-header-left" @click="changeYear(-1)">上一年</span> -->
          <span class="calendar-header-dir calendar-header-left cur" @click="changeMonth(-1)">上个月</span>
          <h2 id="calendar-header-title">{{ displayYear }}年{{ displayMonth + 1 }}月</h2>
          <span class="calendar-header-dir calendar-header-right cur" @click="changeMonth(1)">下个月</span>
          <!-- <span class="calendar-header-dir calendar-header-right" @click="changeYear(1)">下一年</span> -->
          <span class="calendar-header-dir calendar-header-right textccc">E(运行能效) KW/KW</span>
          <span class="calendar-header-dir calendar-header-right textccc">C(日制冷量)KWH</span>
          <span class="calendar-header-dir calendar-header-right textccc">P(日制电量) KWH</span>
          <span class="calendar-header-dir calendar-header-right textccc">M(冷量单价)元/KWH</span>

        </div>
      </div>
      <div class="calendar-panel">
        <div class="calendar-date-panel">
          <div class="calendar-date-body">
            <div class="calendar-date-content">
              <div class="calendar-date-header">
                <div class="calendar-item">周日</div>
                <div class="calendar-item">周一</div>
                <div class="calendar-item">周二</div>
                <div class="calendar-item">周三</div>
                <div class="calendar-item">周四</div>
                <div class="calendar-item">周五</div>
                <div class="calendar-item">周六</div>
              </div>
              <div class="calendar-date-tbody-content">
                <div class="calendar-date-tbody">
                  <div
                    v-for="(day, index) in days"
                    :key="index"
                    class="calendar-item"
                    :class="{ active: day === currentDate.getDate() }"
                  >
                    <div v-if="day" class="one">
                      {{ day }}<br>
                      <span v-if="day" class="bottom textccc">E:598</span>
                      <span v-if="day" class="bottom textccc">C:29733</span>
                      <span v-if="day" class="bottom textccc">P:4968.3</span>
                      <span v-if="day" class="bottom textccc">M:O</span>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- </dv-border-box-8> -->
</template>

<script>
export default {
  data() {
    return {
      currentDate: new Date(),
      displayYear: null,
      displayMonth: null,
      days: []
    }
  },
  computed: {
    daysInMonth() {
      return new Date(this.displayYear, this.displayMonth + 1, 0).getDate()
    },
    firstDayOfWeek() {
      return new Date(this.displayYear, this.displayMonth, 1).getDay()
    }
  },
  watch: {
    displayYear() {
      this.updateDaysArray()
    },
    displayMonth() {
      this.updateDaysArray()
    }
  },
  mounted() {
    this.displayYear = this.currentDate.getFullYear()
    this.displayMonth = this.currentDate.getMonth()
    this.updateDaysArray()
  },
  methods: {
    changeYear(amount) {
      this.displayYear += amount
    },
    changeMonth(amount) {
      const newMonth = this.displayMonth + amount
      if (newMonth < 0) {
        this.displayMonth = 11
        this.displayYear -= 1
      } else if (newMonth > 11) {
        this.displayMonth = 0
        this.displayYear += 1
      } else {
        this.displayMonth = newMonth
      }
    },
    updateDaysArray() {
      const daysArray = []
      const firstDay = new Date(this.displayYear, this.displayMonth, 1).getDay()
      for (let i = 1; i <= this.daysInMonth; i++) {
        daysArray.push(i)
      }
      for (let i = 0; i < firstDay; i++) {
        daysArray.unshift('')
      }
      this.days = daysArray
    }
  }
}
</script>

<style scoped lang="scss">
.ech-box {
  width: 100%;
  height: 100%;
  padding: 10px;
  box-sizing: border-box;
  overflow: hidden;
  border: 1px solid #024596;

}

.calendar-wrap {
  width: 100%;
  height: 100%;
  margin: auto;
}

.calendar-header {
  // padding: 10px;
  text-align: center;
}

.calendar-header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.calendar-date-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 5px 0;
  border: 1px solid #ccc;
}

.calendar-item {
  flex: 1;
  text-align: center;
  padding: 5px;
  font-weight: bold;
  /* border: 1px solid #ccc; */
}

.calendar-item.active {
  background-color: #3498db;
  /* color: white; */
  /* border-radius: 50%; */
}

.calendar-date-tbody-content {
  height: 100%;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.calendar-date-tbody {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 5px;
  height: 100%;
  width: 100%;
  grid-auto-rows: 5.6rem;

  .calendar-item {
    height: 100%;
    /* 设置百分比高度 */
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: .13rem;
    border: 1px solid #ccc;
    // position: relative;

    .one {
      // position: absolute;
      // top: 3px;
      // right: 3px;
      width: 100%;
      height: 100%;
      text-align: right;
      display: flex;
      // justify-content: flex-end;
      // justify-content: center;
      // align-items: center;
      flex-direction: column;

      .bottom {
        flex: 1;
        display: flex;
        justify-content: flex-start;
        align-items: center;
        padding-left: 5px;
      }
    }
  }
}

.textccc {
  color: #ccc;
  font-size: 0.1rem;
}

// 小手指
.cur {
  cursor: pointer;
}
</style>

<template>
  <div class="ech-box">
    <div class="top">
      <div class="left">
        负荷预测与实际负荷曲线
      </div>
      <div class="right" />
    </div>
    <div class="bottom">
      <div ref="chartContainer" style="width: 100%; height: 100%;" />
    </div>

  </div>
</template>

<script>
import echarts from 'echarts'
import { echartDataOne } from '@/api/echart'

export default {
  name: 'LeftTop',
  data() {
    return {
      echartList: {

      }
    }
  },
  mounted() {
    this.getChartData()
    window.addEventListener('resize', this.handleResize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    async getChartData() {
      try {
        const response = await echartDataOne()
        // console.log(response);
        this.echartList = response.data
        this.renderChart() // 获取到数据再渲染图表
        console.log(this.echartList)
      } catch (error) {
        console.error(error)
      }
    },
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      this.chart = echarts.init(chartContainer)

      const option = {
        textStyle: {
          color: '#fff'
        },

        title: {
          // text: '负荷预测与实际负荷曲线',
          // top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#fff'

          }
        },
        grid: {
          top: '40px',
          bottom: '10%',
          right: '13%'
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          // top: '20px',
          data: ['负荷、', 'PUE、', 'COP、', 'CLF曲线、'],

          textStyle: {
            fontSize: 8,
            color: '#AEC8DF'
          },
          itemWidth: 6, // 设置图例项宽度
          itemHeight: 6 // 设置图例项高度
        },
        xAxis: {
          type: 'category',
          // boundaryGap: true,
          boundaryGap: false, //
          data: this.echartList.xAxisData,
          // data: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'],
          axisLabel: {
            interval: 0,
            // rotate: 45,
            textStyle: {
              fontSize: 10
            }
          }
        },
        yAxis: [
          {
            type: 'value',
            name: '负荷',
            nameTextStyle: {
              fontSize: 8
            },
            splitLine: {
              show: true,
              lineStyle: {
                type: 'dashed'
              }
            },
            axisLabel: {
              fontSize: 10
            }
          },
          {
            type: 'value',
            name: 'PUE、COP、CLF',
            nameTextStyle: {
              fontSize: 8
            },
            position: 'right',
            splitLine: {
              show: true,
              lineStyle: {
                type: 'dashed'
              }
            },
            axisLabel: {
              fontSize: 10
            }
          }
        ],
        series: [
          {
            name: '负荷、',
            type: 'bar',
            stack: 'stacked',
            data: this.echartList.one,
            // data: [110, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 132, 101, 134],
            itemStyle: {
              color: '#045FDA', //
              fontSize: 10,
              barBorderRadius: [5, 5, 0, 0] // 设置圆角

            },
            yAxisIndex: 0 // 使用第一个 Y 轴
          },
          {
            name: 'PUE、',
            type: 'line',
            stack: 'stacked',
            data: this.echartList.two,

            // data: [132, 220, 182, 191, 234, 290, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 132, 101, 134, 134, 90,],
            itemStyle: {
              color: '#009DEE', //
              fontSize: 10
            },
            yAxisIndex: 1 // 使用第二个 Y 轴
          },
          {
            name: 'COP、',
            type: 'line',
            stack: 'stacked',
            data: this.echartList.three,

            // data: [132, 220, 182, 191, 234, 290, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 132, 101, 134, 134, 90,],
            itemStyle: {
              color: '#F79C07', //
              fontSize: 10
            },
            yAxisIndex: 1 // 使用第二个 Y 轴

          },
          {
            name: 'CLF曲线、',
            type: 'line',
            stack: 'stacked',
            data: this.echartList.four,
            // data: [132, 220, 182, 191, 234, 290, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 132, 101, 134, 134, 90,],
            itemStyle: {
              color: '#894DA8', //
              fontSize: 10
            },
            yAxisIndex: 1 // 使用第二个 Y 轴

          }

        ]
      }

      this.chart.setOption(option)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    }
  }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;
    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;

        }

        .right {
            display: flex;
            font-size: .2133rem;

            .day,
            .mouth,
            .year {
                background-color: #024596;
                border-radius: .1333rem;
                margin: 2px;
                padding: 2px;
                box-sizing: border-box;
                cursor: pointer;

                span {
                    color: #fff;

                }
            }

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
    }

}

</style>

<template>
  <!-- <dv-border-box-8> -->
  <div class="ech-box">
    <div class="one-top">
      <div class="top-left textright">负荷比</div>
      <div class="top-right textblue">Q&lt;25% </div>
    </div>
    <div class="one-bottom">
      <div class="bottom-left">
        <div class="bottom-left-item textccc">运行时间(H) :</div>
        <div class="bottom-left-item textccc">时间占比 :</div>
        <div class="bottom-left-item textccc">平均室外温度(C) :</div>
        <div class="bottom-left-item textccc"> 平均系统效率(W/W) :</div>
      </div>
      <div class="bottom-right">
        <div class="bottom-right-item textright">022</div>
        <div class="bottom-right-item textright">98%</div>
        <div class="bottom-right-item textright">22</div>
        <div class="bottom-right-item textright">65</div>

      </div>
    </div>
  </div>
  <!-- </dv-border-box-8> -->
</template>

<script>
export default {
  name: 'BottomTwo',
  data() {
    return {

    }
  },
  created() {

  },
  mounted() {

  },
  methods: {

  }
}
</script>
<style scoped lang='scss'>
.ech-box{
    width: 100%;
    height: 100%;
    border: 1px solid #024596;
    display: flex;
    flex-direction: column;

    // 第一个上半部分
    .one-top {
        flex: 1;
        height: 100%;
        position: relative;
        &::before {
                content: "";
                position: absolute;
                bottom: 0;
                left: 10px;
                right: 5px;
                // width: 100%;
                height: 1px;
                border-bottom: 1px dashed #324B73;
            }

        // 上半部分左侧文字
        .top-left {
            position: absolute;
            top: 50%;
            left: 15px;
            transform: translateY(-50%);
            &::before {
            content: "";
            position: absolute;
            bottom: 0;
            left: -5px;
            width: 2px;
            height: 100%;
            background-color: #1181bd;
        }

        }

        // 上半部分右侧文字
        .top-right {
            position: absolute;
            top: 50%;
            right: 5px;
            transform: translateY(-50%);

        }

    }

    // 第一个下半部分
    .one-bottom {
        flex: 5;
        height: 100%;
        width: 100%;
        position: relative;
        display: flex;
        margin-top: 10px;

        .bottom-left {
            flex: 1;
            position: absolute;
            top: 50%;
            left: 5px;
            transform: translateY(-50%);
            line-height: 0.26rem;
            // background-color: pink;
            height: 100%;
            display: flex;
            flex-direction: column;
            /* 垂直排列 */
            justify-content: space-between;
            /* 平均分配空间 */
            box-sizing: border-box;

            .bottom-left-item {
                flex: 1;
                line-height: 1;
                /* 垂直居中 */
                text-align: left;
                /* 文字左对齐 */
                padding-left: 10px;
                /* 左侧留出一些间距 */
            }
        }

        .bottom-right {
            flex: 1;
            // background-color: blue;
            height: 100%;
            position: absolute;
            top: 50%;
            right: 5px;
            transform: translateY(-50%);
            display: flex;
            flex-direction: column;
            /* 垂直排列 */
            justify-content: space-between;
            /* 平均分配空间 */

            .bottom-right-item {
                flex: 1;
                text-align: left;
                /* 文字左对齐 */
                line-height: 1;
                /* 垂直居中 */
                // background-color: lightblue;
            }
        }

    }

}

    // 灰色color
.textccc{
    color: #AEC8DF;
    font-size: .28rem;
}
.textblue{
    color: #1181bd;
    font-size: .32rem;

}
.textright{
    font-size: .32rem;

}

</style>

<template>

  <div class="ech-box">
    <div class="top">
      <div class="left">
        出水温度与能耗
      </div>
      <div class="right">
        <div class="day"><span>日</span></div>
        <div class="mouth"><span>月</span></div>
        <div class="year"><span>年</span></div>
      </div>
    </div>
    <div class="bottom">
      <div ref="chartContainer" style="width: 100%; height: 100%;" />
    </div>

  </div>
</template>

<script>
import echarts from 'echarts'

export default {
  name: 'LeftBottom',
  mounted() {
    this.renderChart()
    window.addEventListener('resize', this.handleResize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      this.chart = echarts.init(chartContainer)

      const option = {
        textStyle: {
          color: '#fff'
        },
        title: {
          // text: '出水温度与能耗',
          // top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#fff'
          }
        },
        grid: {
          top: '40px',
          bottom: '13%',
          left: '13%',
          right: '13%'
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            crossStyle: {
              color: '#999'
            }
          }
        },
        legend: {
          // top: '20px',
          data: ['能耗', '温度'],
          textStyle: {
            fontSize: 8,
            color: '#AEC8DF'
          },
          itemWidth: 6,
          itemHeight: 6
        },
        xAxis: [
          {
            type: 'category',
            data: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'],
            axisPointer: {
              type: 'shadow'
            },
            axisLabel: {
              textStyle: {
                fontSize: 10
              }
            }
          }
        ],
        yAxis: [
          {
            type: 'value',
            name: '℃', // 添加单位
            nameTextStyle: {
              fontSize: 8
            },
            splitLine: {
              show: true,
              lineStyle: {
                type: 'dashed'
              }
            }
          },
          {
            type: 'value',
            name: 'KWH', // 添加单位
            nameTextStyle: {
              fontSize: 8
            },
            splitLine: {
              show: true,
              lineStyle: {
                type: 'dashed'
              }
            },
            axisLabel: {
              textStyle: {
                fontSize: 10
              }
            }
          }

        ],
        series: [
          {
            name: '能耗',
            type: 'bar',
            yAxisIndex: 1, // 指定使用第2个 Y 轴
            itemStyle: {
              color: '#01FFF7',
              fontSize: 10
            },
            data: [2.0, 4.9, 7.0, 23.2, 2.0, 4.9, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0]
          },
          {
            name: '温度',
            type: 'line',
            yAxisIndex: 0, // 指定使用第1个 Y 轴
            itemStyle: {
              color: '#FD9D04',
              fontSize: 10
            },
            data: [2.0, 2.2, 175.6, 182.2, 48.7, 18.8, 3.3, 4.5, 182.2, 48.7, 18.8, 6.2]
          }
        ]
      }

      this.chart.setOption(option)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    }
  }
}
</script>

  <style scoped lang="scss">
  .ech-box {
      width: 100%;
      height: 100%;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
      border: 1px solid #024596;
      .top {
          flex: 0.5;
          display: flex;
          justify-content: space-between;
          height: 100%;
          width: 100%;
          padding: 5px;

          .left {
              font-size: 8px;
              margin-top: .1333rem;
              margin-left: 1%;

          }

          .right {
              display: flex;
              font-size: .2133rem;

              .day,
              .mouth,
              .year {
                  background-color: #024596;
                  border-radius: .1333rem;
                  margin: 2px;
                  padding: 2px;
                  box-sizing: border-box;
                  cursor: pointer;

                  span {
                      color: #fff;

                  }
              }

          }
      }

      .bottom {
          flex: 9;
          height: 100%;
          width: 100%;
      }

  }

  </style>

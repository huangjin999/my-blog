<template>
  <div class="ech-box">
    <div class="top">
      <div class="left">
        室外温度与负荷散点图(全年)
      </div>
      <div class="right" />
    </div>
    <div class="bottom">
      <div ref="chartContainer" style="width: 100%; height: 100%;" />
    </div>

  </div>
</template>

<script>
import echarts from 'echarts'

export default {
  name: 'RightOne',
  mounted() {
    this.renderChart()
    window.addEventListener('resize', this.handleResize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      this.chart = echarts.init(chartContainer)

      // 温度和负荷的散点数据
      const temperatureData = [
        [5, 12], [13, 15], [16, 14], [15, 16], [17, 18], [17, 18], [18, 18], [19, 18], [20, 18], [21, 18]
      ]

      const loadData = [
        [16, 14], [15, 16], [17, 18], [17, 18], [5, 12], [13, 15], [16, 14], [15, 16], [17, 18], [17, 18]
      ]

      const option = {
        textStyle: {
          color: '#fff'
        },
        title: {
          // text: '室外温度与负荷散点图(全年)',
          // top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#fff'
          }
        },
        grid: {
          top: '40px',
          bottom: '13%',
          left: '13%',
          right: '13%'
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            crossStyle: {
              color: '#999'
            }
          }
        },
        legend: {
          // top: '20px',
          data: ['温度', '负荷'],
          textStyle: {
            fontSize: 8,
            color: '#AEC8DF'
          },
          itemWidth: 6,
          itemHeight: 6
        },
        xAxis: [
          {
            type: 'value',
            name: '温度', // 添加单位
            nameTextStyle: {
              fontSize: 8
            },
            splitLine: {
              show: true,
              lineStyle: {
                type: 'dashed'
              }
            },
            axisLabel: {
              textStyle: {
                fontSize: 10
              }
            }
          }
        ],
        yAxis: [
          {
            type: 'value',
            name: '负荷', // 添加单位
            nameTextStyle: {
              fontSize: 8
            },
            splitLine: {
              show: true,
              lineStyle: {
                type: 'dashed'
              }
            },
            axisLabel: {
              textStyle: {
                fontSize: 10
              }
            }
          }
        ],
        series: [
          {
            name: '温度',
            type: 'scatter', // 使用散点图
            symbolSize: 10, // 设置散点的大小
            data: temperatureData,
            itemStyle: {
              color: '#358FC1'
            }
          },
          {
            name: '负荷',
            type: 'scatter', // 使用散点图
            symbolSize: 10, // 设置散点的大小
            data: loadData,
            itemStyle: {
              color: '#FD9D04'
            }
          }
        ]
      }

      this.chart.setOption(option)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    }
  }
}
</script>
<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;
    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;

        }

        .right {
            display: flex;
            font-size: .2133rem;

            .day,
            .mouth,
            .year {
                background-color: #024596;
                border-radius: .1333rem;
                margin: 2px;
                padding: 2px;
                box-sizing: border-box;
                cursor: pointer;

                span {
                    color: #fff;

                }
            }

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
    }

}

</style>

<template>
  <div class="ech-box">
    <div class="top">
      <div class="left">
        室外平均温度与COP/PUE
      </div>
      <div class="right" />
    </div>
    <div class="bottom">
      <div ref="chartContainer" style="width: 100%; height: 100%;" />
    </div>

  </div>
</template>

<script>
import echarts from 'echarts'

export default {
  name: 'RightThree',
  mounted() {
    this.renderChart()
    window.addEventListener('resize', this.handleResize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      this.chart = echarts.init(chartContainer)

      const option = {
        textStyle: {
          color: '#fff'
        },
        title: {
          // text: '室外平均温度与COP/PUE',
          // top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#fff'
          }
        },
        grid: {
          top: '40px',
          bottom: '13%',
          left: '13%',
          right: '13%'
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          // top: '20px',
          data: ['室外平均温度', 'COP', 'PUE'],
          textStyle: {
            fontSize: 6,
            color: '#AEC8DF'
          },
          itemWidth: 8,
          itemHeight: 8
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: [
            '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18',
            '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31'
          ],
          axisLabel: {
            interval: 0,
            textStyle: {
              fontSize: 8
            }
          }
        },
        yAxis: [
          {
            type: 'value',
            name: '℃', // 温度单位
            nameTextStyle: {
              fontSize: 10
            },
            splitLine: {
              show: true,
              lineStyle: {
                type: 'dashed'
              }
            },
            axisLabel: {
              textStyle: {
                fontSize: 10
              }
            }
          },
          {
            type: 'value',
            name: 'COP/PUE', // 能耗和冷负荷单位
            nameTextStyle: {
              fontSize: 10
            },
            splitLine: {
              show: true,
              lineStyle: {
                type: 'dashed'
              }
            },
            axisLabel: {
              textStyle: {
                fontSize: 10
              }
            }
          }
        ],
        series: [
          {
            name: '室外平均温度',
            type: 'line',
            stack: 'stacked',
            yAxisIndex: 0, // 使用左侧 Y 轴（温度）
            data: [120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290,
              132, 101, 134, 101, 134, 90, 220, 182, 191, 234, 20],
            itemStyle: {
              color: '#FA9908',
              fontSize: 10
            }
          },
          {
            name: 'COP',
            type: 'line',
            stack: 'stacked',
            yAxisIndex: 1, // 使用右侧 Y 轴（能耗和冷负荷）
            data: [290, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 220, 182, 191, 234, 191, 234, 290,
              132, 101, 134, 134, 90, 101, 134, 90, 220, 182, 191, 234, 290],
            itemStyle: {
              color: '#8D4DA4',
              fontSize: 10
            }
          },
          {
            name: 'PUE',
            type: 'line',
            stack: 'stacked',
            yAxisIndex: 1, // 使用右侧 Y 轴（能耗和冷负荷）
            data: [220, 182, 191, 234, 290, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290,
              132, 101, 134, 134, 90, 220, 182, 191, 234, 101, 134, 90, 220],
            itemStyle: {
              color: '#01FBF6',
              fontSize: 10
            }
          }
        ]
      }

      this.chart.setOption(option)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    }
  }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;
    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;

        }

        .right {
            display: flex;
            font-size: .2133rem;

            .day,
            .mouth,
            .year {
                background-color: #024596;
                border-radius: .1333rem;
                margin: 2px;
                padding: 2px;
                box-sizing: border-box;
                cursor: pointer;

                span {
                    color: #fff;

                }
            }

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
    }

}

</style>


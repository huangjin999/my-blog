<template>
  <div>
    <!-- 左上的上半部分 -->
    <div class="top-half">
      <div class="sub-box">
        <div class="icon">
          <i class="el-icon-coin" />
        </div>
        <div class="text">干球温度:25C</div>
      </div>
      <div class="sub-box">
        <div class="icon">
          <i class="el-icon-coin" />
        </div>
        <div class="text">温球温度:50%</div>
      </div>
      <div class="sub-box">
        <div class="icon">
          <i class="el-icon-coin" />
        </div>
        <div class="text">相对湿度:50%</div>
      </div>
    </div>
    <!-- 左上的下半部分 -->
    <div class="bottom-half">
      <!-- 下左 -->
      <div class="left-half">
        <div class="left-column">
          <span class="text">累计电耗：</span>
          <span class="text">累计IT电耗：</span>
          <span class="text">累计空调电耗：</span>
          <span class="text">累计冷量：</span>
          <span class="text">累计补水量：</span>
        </div>
        <div class="right-column">
          <span class="text">10000kwh</span>
          <span class="text">500kwh</span>
          <span class="text">7000kwh</span>
          <span class="text">200KW</span>
          <span class="text">150t</span>
        </div>
      </div>
      <!-- 下右 -->
      <div class="right-half">
        <div class="left-column">
          <span class="text">电费：</span>
          <span class="text">节能率：</span>
          <span class="text">累节能量：</span>
          <span class="text">节省标准煤：</span>
          <span class="text">CO2减排：</span>
        </div>
        <div class="right-column">
          <span class="text">20000万元</span>
          <span class="text">20%</span>
          <span class="text">20000kwh</span>
          <span class="text">2000t</span>
          <span class="text">150t</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'LeftTop',

  data() {
    return {

    }
  },
  created() {

  },
  mouted() {

  },
  methods: {

  }
}
</script>
<style scoped lang='scss'>
.top-half {
    flex: 1;
    display: flex;
    flex-wrap: wrap;
    border-bottom: 1px dashed #ff0404;
    // height: 100%;
}

.bottom-half {
    flex: 2;
    display: flex;
    height: auto;
}

.bottom-half-center {
    flex: 9;
    display: flex;
    // overflow: hidden;
}

.bottom-half-lef {
    flex: 9;
    display: flex;
    flex-direction: row;
}

.sub-box {
    flex-basis: 33.33%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.icon {
    margin-top: .2667rem;
}

.text {
    font-size: .32rem;
    text-align: center;
    display: flex;
    align-items: center;
    margin-top: 1rem;
    // line-height: .5333rem;
}

.left-half {
    flex: 1;
    // padding: 10px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: flex-start;
    border-right: 1px dashed #ff0404;
    position: relative;
}

.left-column {
    display: flex;
    flex: 1;
    // height: 100%;
    // background-color: #ff0404;
    flex-direction: column;
    align-items: flex-start;
    margin-left: 2%;

}

.right-column {
    display: flex;
    // background-color: antiquewhite;
    flex: 1;
    flex-direction: column;
    align-items: flex-start;
    position: absolute;
    top: 0;
    right: 0;
    margin-right: 2%;

}

.right-half {
    flex: 1;
    position: relative;

}
</style>

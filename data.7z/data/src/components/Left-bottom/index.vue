<!-- <template>
    <div class="capsule-chart"></div>
  </template> -->

  <!-- <script>
  import echarts from 'echarts';

  export default {
    name: 'Left-bottom',
    mounted() {
      this.renderChart();
    },
    methods: {
      renderChart() {
        const chartContainer = this.$el;
        const chart = echarts.init(chartContainer);

        const option = {
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'shadow'
            }
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: {
            type: 'value',
            show: false
          },
          yAxis: {
            type: 'category',
            data: ['Category 1', 'Category 2', 'Category 3', 'Category 4', 'Category 5'],
            axisTick: {
              show: false
            },
            axisLine: {
              show: false
            }
          },
          series: [
            {
              type: 'bar',
              data: [120, 200, 150, 80, 70],
              barWidth: 20,
              itemStyle: {
                color: '#409EFF'
              }
            }
          ]
        };

        chart.setOption(option);
      }
    }
  };
  </script> -->
<!--
  <style scoped>
  .capsule-chart {
    width: 400px;
    height: 300px;
  }
  </style> -->

<template>
  <div>
    <!-- 左下的上半部分 -->
    <div class="top-half-lef">
      运行能耗的实时统计
    </div>
    <!-- 左下的下半部分 -->
    <div class="bottom-half-lef">

      <div class="left-part">
        <span class="text text-cent">设备</span>
        <span class="text text-cent">精密空调</span>
        <span class="text text-cent">列头柜</span>
        <span class="text text-cent">冷冻泵</span>
        <span class="text text-cent">主机</span>
        <span class="text text-cent">冷却水泵</span>
        <span class="text text-cent">冷却水塔</span>
        <span class="text text-cent">蒸发冷</span>
      </div>
      <div class="center-part">
        <span class="text text-cent">运行台数</span>
        <span class="text text-cent"><i :class="colorClass">{{ leftValue }}</i>/{{ rightValue }}</span>
        <span class="text text-cent"><i :class="colorClass">{{ leftValue }}</i>/{{ rightValue }}</span>
        <span class="text text-cent"><i :class="colorClass">{{ leftValue }}</i>/{{ rightValue }}</span>
        <span class="text text-cent"><i :class="colorClass">{{ leftValue }}</i>/{{ rightValue }}</span>
        <span class="text text-cent"><i :class="colorClass">{{ leftValue }}</i>/{{ rightValue }}</span>
        <span class="text text-cent"><i :class="colorClass">{{ leftValue }}</i>/{{ rightValue }}</span>
        <span class="text text-cent"><i :class="colorClass">{{ leftValue }}</i>/{{ rightValue }}</span>

      </div>
      <div class="right-part">
        <span class="text text-cent">运行总功率</span>
        <span class="text text-cent">6088kw <div class="jnt" /></span>
        <span class="text text-cent">5088kw</span>
        <span class="text text-cent">4088kw</span>
        <span class="text text-cent">9088kw</span>
        <span class="text text-cent">3088kw</span>
        <span class="text text-cent">2088kw</span>
        <span class="text text-cent">1088kw</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'LeftBottom',
  data() {
    return {
      leftValue: 10,
      rightValue: 20
    }
  },
  computed: {
    colorClass() {
      const leftValue = parseInt(this.leftValue)
      const rightValue = parseInt(this.rightValue)

      if (leftValue < rightValue) {
        return 'green-text'
      } else if (leftValue > rightValue) {
        return 'red-text'
      } else {
        return ''
      }
    }
  },

  created() {

  },
  mouted() {

  },
  methods: {

  }
}
</script>
<style scoped lang="scss">
// *{
//   margin: 0;
//   padding: 0;
//   color: #fff;
// }
.left-title {
  // font-size: 12px;
}

.green-text {
  color: green;
}

.red-text {
  color: red;
}

.dashboard {
  display: flex;
  height: 100vh;
}

.left-section,
.right-section {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
}

.center-section {
  flex: 2;
  display: flex;
  flex-direction: column;
}

.top-section {
//   background-color: antiquewhite;
//   height: 70vh;
  display: flex;
  flex-direction: column;
}

.small-box {
  flex: 1;
  background-color: lightblue;
}

.big-box {
  flex: 5;
  background-color: lightgreen;
}

.bottom-section {
  flex: 1;
  display: flex;
  // justify-content: space-between;
  flex-direction: row;
}

// .box {
//   width: calc(100% - 20px);
//   height: calc(100vh / 3 - 20px);
// //   background-color: #ccc;
//   margin: 10px;
//   display: flex;
//   flex-direction: column;
//   box-sizing: border-box;
// }

.top-half {
  flex: 1;
  display: flex;
  flex-wrap: wrap;
  border-bottom: 1px dashed #ff0404;
}

.bottom-half {
  flex: 2;
  display: flex;
}

.top-half-center,
.top-half-lef {
  flex: 1;
  display: flex;
  // flex-wrap: wrap;
  // border-bottom: 1px dashed #ff0404;
  margin: 5px;
}

.bottom-half-center {
  flex: 9;
  display: flex;
  // overflow: hidden;
}

.bottom-half-lef {
  flex: 9;
  display: flex;
  flex-direction: row;
}

.left-part {
  flex: 1;
  // background-color: lightblue;

}

.center-part {
  flex: 1;
  // background-color: lightgreen;

}

.right-part {
  flex: 2;
//   background-color: lightyellow;

}

.sub-box {
  flex-basis: 33.33%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.icon {
  margin-bottom: 10px;
}

.text {
  font-size: .32rem;
  text-align: center;
  display: flex;
  align-items: center;
  margin-top: 10px;
}

.text-cent {
  justify-content: center;
}

.left-half {
  flex: 1;
  // padding: 10px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
  border-right: 1px dashed #ff0404;
  position: relative;
}

.left-column {
  display: flex;
  flex: 1;
  // height: 100%;
  // background-color: #ff0404;
  flex-direction: column;
  align-items: flex-start;
  margin-left: 10px;

}

.right-column {
  display: flex;
  // background-color: antiquewhite;
  flex: 1;
  flex-direction: column;
  align-items: flex-start;
  position: absolute;
  top: 0;
  right: 0;
  margin-right: 10px;

}

.right-half {
  flex: 1;
  position: relative;

}

.title {
  font-size: 24px;
  margin-bottom: 20px;
}

.image {
  width: 400px;
  height: auto;
}

.big {
  display: flex;
  flex-direction: row;
}

.box-left-bottom,
.box-right-bottom {
  display: flex;
  flex: 1;
}

// @media (max-width: 768px) {
//   .dashboard {
//     flex-direction: column;
//   }

//   .left-section,
//   .right-section {
//     flex: none;
//     height: auto;
//   }

//   .center-section {
//     flex: none;
//   }

//   .top-section {
//     height: auto;
//   }

//   .box {
//     width: 100%;
//     height: auto;
//     margin: 10px 0;
//   }
// }
</style>

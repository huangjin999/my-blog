<template>
  <div>
    <Chart />
  </div>
</template>

<script>
import Chart from './chart.vue'
export default {
  data () {
    return {
   
    };
  },
  components: {
    Chart,
  },
  mounted () {
    // this.setData();
  },
  methods: {
    // 根据业务情况修改
    // setData () {
    //   for (let i = 0; i < this.cdata.barData.length -1; i++) {
    //     let rate = this.cdata.jianData[i] / this.cdata.fengData[i]/ this.cdata.guData[i]/ this.cdata.pingData[i];
    //     this.cdata.rateData.push(rate.toFixed(2));
    //   }
    // },
  }
};
</script>

<style lang="scss" scoped>
</style>
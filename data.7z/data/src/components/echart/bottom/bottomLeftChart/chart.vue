<!-- <template>
  <div>
    
    <Echart
    :config="config"
      id="bottomLeftChart"
      height="480px"
      width="100%"
      ><div class="ref" ref="chart">

    </div></Echart>
  </div>
</template>

<script>
import Echart from '@/common/echart'
export default {
  data() {
    return {
      option: {
        xAxis: {
          type: "category",
          data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
        },
        yAxis: {
          type: "value",
        },
        series: [
          {
            data: [120, 200, 150, 80, 70, 110, 130],
            type: "bar",
            showBackground: true,
            backgroundStyle: {
              color: "rgba(180, 180, 180, 0.2)",
            },
          },
        ],
      },
      // 配置可视化图形
    };
  },
  mounted() {
    this.getchart();
  },
  methods: {
    getchart() {
      // 引用chart并初始化
      this.chart = this.$echarts.init(this.$refs.chart);      
      // 使用刚指定的配置项和数据显示图表。
      this.chart.setOption(this.option)
      //自适应
      window.addEventListener("resize", () => {
        this.chart.resize();
      });
    },
  },
};

</script> -->
<template>
  <div class="echart" id="mychart" :style="myChartStyle"></div>
</template>

<script>
import * as echarts from "echarts";

export default {
  data() {
    return {
      myChart: {},
      myChartStyle: { float: "left", width: "100%", height: "400px" }, //图表样式
    };
  },
  mounted() {
    this.initEcharts();
  },
  methods: {
    initEcharts() {
      
      // 柱条间距
      const option = {
        xAxis: {
          data: ["六月", "七月", "八月", "九月", "十月","十一月","十二月"],
          axisLine: {  //这是x轴文字颜色
                lineStyle: {
                    color: "#fff",
                }
            }

        },
        yAxis: {
          axisLine: {  //这是y轴文字颜色
                lineStyle: {
                    color: "#fff",
                }
            }

        },
        series: [
          {
            type: "bar",
            data: [123, 99, 62, 95, 78,56,110],
            // barGap: "0%", // 两个柱子之间的距离相对于柱条宽度的百分比;
            barCategoryGap: "60%", // 每侧空余的距离相对于柱条宽度的百分比
            itemStyle:{
                        normal:{color:'#2D96DD'}
                    },
          },
        
        ]
      };
      const myChart = echarts.init(document.getElementById("mychart"));
      myChart.setOption(option);
      //随着屏幕大小调节图表
      window.addEventListener("resize", () => {
        myChart.resize();
      });
    }
  }
};
</script>

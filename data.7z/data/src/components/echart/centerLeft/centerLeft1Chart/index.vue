<template>
  <div>
    <Chart :cdata="cdata" />
  </div>
</template>
<!-- 接入总电表数据 -->
<script>
import Chart from './chart.vue';
export default {
  data () {
    return {
      cdata: {
        xData: ["接入电表", "在线电表", "故障电表", "离线电表"],
        seriesData: [
          { value: 313, name: "接入电表" },
          { value: 313, name: "在线电表" },
          { value: 0, name: "故障电表" },
          { value: 0, name: "离线电表" },
          // { value: 20, name: "data5" },
          // { value: 35, name: "data6" }
        ]
      }
    }
  },
  components: {
    Chart,
  },
  mounted () {
  },
  methods: {
  }
}
</script>

<style lang="scss" scoped>
</style>
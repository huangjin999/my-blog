<template>
  <div>
    <div class="ech-box">
      <div ref="chartContainer" style="width: 100%; height: 100%;" />
    </div>

  </div>
</template>

<script>
import echarts from 'echarts'

export default {
  name: 'RightTop',
  data() {
    return {}
  },
  created() {},
  mounted() {
    this.renderChart()
  },
  methods: {
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      const chart = echarts.init(chartContainer)

      const option = {
        // ECharts 配置选项
        // 可根据实际需要配置折线图的数据、样式等
        title: {
          // text: '折线图标题',
        },
        xAxis: {
          type: 'category',
          data: ['现在', '12点', '14点', '16点', '18点', '20点']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name: '1',
            type: 'line',
            data: [10, 20, 15, 30, 25, 15]
          }
        ]
      }

      chart.setOption(option)
    }
  }
}
</script>

  <style scoped lang='scss'>

.ech-box {
    width: calc(100% - 0.5333rem);
    /* height: calc(100vh / 3 - 40px); */
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;

}
  </style>

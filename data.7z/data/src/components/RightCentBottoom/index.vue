<template>
  <div class="ech-box">
    <div ref="chartContainer" style="width: 100%; height: 100%;" />
  </div>
</template>

<script>
import echarts from 'echarts'

export default {
  name: 'LeftCenter',
  mounted() {
    this.renderChart()
  },
  methods: {
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      const chart = echarts.init(chartContainer)

      const option = {

        title: {
          // text: '负荷预测与实际负荷曲线',
          textStyle: {
            fontSize: 14
          }
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: ['负荷、', 'PUE、', 'COP、', 'CLF曲线、']
        },
        xAxis: {
          type: 'category',
          // boundaryGap: true,
          boundaryGap: false, //
          data: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'],
          axisLabel: {
            interval: 0,
            // rotate: 45,
            textStyle: {
              fontSize: 10
            }
          }
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: true,
            lineStyle: {
              type: 'dashed' // S
            }
          }
        },
        series: [
          {
            name: '负荷、',
            type: 'line',
            stack: 'stacked',
            data: [110, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 132, 101, 134],
            itemStyle: {
              color: '#358FC1', //
              fontSize: 10

            }
          },
          {
            name: 'PUE、',
            type: 'line',
            stack: 'stacked',
            data: [132, 220, 182, 191, 234, 290, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 132, 101, 134, 134, 90],
            itemStyle: {
              color: '#C39F49', //
              fontSize: 10
            }
          },
          {
            name: 'COP、',
            type: 'line',
            stack: 'stacked',
            data: [132, 220, 182, 191, 234, 290, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 132, 101, 134, 134, 90],
            itemStyle: {
              color: '#C39F49', //
              fontSize: 10
            }
          },
          {
            name: 'CLF曲线、',
            type: 'line',
            stack: 'stacked',
            data: [132, 220, 182, 191, 234, 290, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 132, 101, 134, 134, 90],
            itemStyle: {
              color: '#C39F49', //
              fontSize: 10
            }
          }

        ]
      }

      chart.setOption(option)
    }
  }
}
</script>

<style scoped>
.ech-box {
    width: calc(100% - 20px);
    /* height: calc(100vh / 3 - 40px); */
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;

}
</style>

<template>
    <div class="carousel-table">
      <div class="table-container">
        <table class="main-table">
          <thead>
            <tr>
              <th>Header 1</th>
              <th>Header 2</th>
              <th>Header 3</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item, index) in tableData" :key="index" @mouseover="showHoverTable(index)" @mouseout="hideHoverTable">
              <td>{{ item.data1 }}</td>
              <td>{{ item.data2 }}</td>
              <td>{{ item.data3 }}</td>
            </tr>
          </tbody>
        </table>
        <table v-if="hoveredRowIndex !== null" class="hover-table">
          <thead>
            <tr>
              <th>Hover Header 1</th>
              <th>Hover Header 2</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>{{ tableData[hoveredRowIndex].hoverData1 }}</td>
              <td>{{ tableData[hoveredRowIndex].hoverData2 }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        tableData: [
          { data1: 'Data 1', data2: 'Data 2', data3: 'Data 3', hoverData1: 'Hover Data 1', hoverData2: 'Hover Data 2' },
          { data1: 'Data 4', data2: 'Data 5', data3: 'Data 6', hoverData1: 'Hover Data 3', hoverData2: 'Hover Data 4' },
          // Add more rows as needed
        ],
        hoveredRowIndex: null,
      };
    },
    methods: {
      showHoverTable(index) {
        this.hoveredRowIndex = index;
      },
      hideHoverTable() {
        this.hoveredRowIndex = null;
      },
    },
  };
  </script>
  
  <style>
  .carousel-table {
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  
  .table-container {
    position: relative;
    width: 100%;
    overflow: hidden;
  }
  
  .main-table,
  .hover-table {
    width: 100%;
    border-collapse: collapse;
    border: 1px solid #ccc;
  }
  
  thead {
    background-color: #f0f0f0;
  }
  
  th, td {
    padding: 8px;
    border: 1px solid #ccc;
  }
  
  .hover-table {
    display: none;
    position: absolute;
    top: 0;
    left: 0;
  }
  
  tr:hover .hover-table {
    display: block;
  }
  
  </style>
  
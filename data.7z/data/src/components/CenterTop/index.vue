<template>
  <div>
    <div class="small-box">
      <div class="small-box-item right-line">
        <div class="small-box-content">
          <div class="small-box-title">系统PUE</div>
          <div class="small-box-text">

            1.2
          </div>
        </div>
        <div class="small-box-stats">
          <div class="small-box-text">
            同比: 12.70%
          </div>
          <div class="small-box-text">
            环比: 6.30%
          </div>
        </div>
      </div>
      <div class="small-box-item right-line">
        <div class="small-box-content">
          <div class="small-box-title">系统COP</div>
          <div class="small-box-text">

            1.2
          </div>
        </div>
        <div class="small-box-stats">
          <div class="small-box-text">
            同比: 12.70% ↑
          </div>
          <div class="small-box-text">
            环比: 6.30% ↓
          </div>
        </div>
      </div>
      <div class="small-box-item">
        <div class="small-box-content">
          <div class="small-box-title">制冷因子CLF</div>
          <div class="small-box-text">

            1.2
          </div>
        </div>
        <div class="small-box-stats ">
          <div class="small-box-text">
            同比: 12.70%
          </div>
          <div class="small-box-text">
            环比: 6.30%
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CenterTop',
  data() {
    return {

    }
  },
  created() {

  },
  mounted() {

  },
  methods: {

  }
}
</script>
<style scoped lang='scss'>

// 中间上面

.small-box {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
//   background-color: lightblue;
  padding: 10px;
}

.small-box-item {
  flex: 1;
  margin: 0 5px;
  display: flex;
  justify-content: space-between;

}
.small-box-item-inner {
  display: flex;
  justify-content: space-between;
  width: 100%;
}
.small-box-content {
  display: flex;
  flex-direction: column;
}

.small-box-title {
  font-weight: bold;
  margin-bottom: 5px;
}

.small-box-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.small-box-stats {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  margin-right: 20px;
}
.right-line{
  border-right: 1px solid red;
}

</style>

<template>
  <div>
    <div class="ech">
      <div ref="chartContainer" style="width: 100%; height: 100%;" />
    </div>

  </div>
</template>

<script>
import * as echarts from 'echarts'

export default {
  name: 'LeftCentBottom',
  mounted() {
    this.renderChart()
  },
  methods: {
    renderChart() {
      const chartContainer = this.$refs.chartContainer

      // 创建饼图实例
      const chart = echarts.init(chartContainer)
      const data = [
        { name: '001', value: 1501 },
        { name: '002', value: 1305 },
        { name: '003', value: 1014 },
        { name: '004', value: 1330 }
      ]
      const totalCount = data.reduce((vs, v) => vs + v.value, 0)
      const formatNumber = (num) => num.toString().replace(/(?=(\B)(\d{3})+$)/g, ',')

      // 配置饼图的数据和样式
      const options = {
        title: [
          {
            text: `{name|主机总数/台}\n{val|${formatNumber(totalCount)}}`,
            top: 'center',
            left: 'center',
            textStyle: {
              rich: {
                name: {
                  fontSize: 10,
                  color: '#666666',
                  padding: [5, 0]
                },
                val: {
                  fontSize: 10,
                  fontWeight: 'bold',
                  color: '#333333'
                }
              }
            }
          },
          {
            text: '主机分布',
            top: 20,
            left: 'center',
            textStyle: { fontSize: 10, color: '#666666', fontWeight: 150 }
          }
        ],
        tooltip: {
          trigger: 'item',
          backgroundColor: 'rgba(0,0,0,0.9)',
          formatter: (params) => `${params.data.name}<br/>
    ${params.marker}<span style="color:${params.color}">主机占比: ${params.percent} %</span><br/>
    ${params.marker}<span style="color:${params.color}">主机数量: ${params.value} 台</span>`
        },
        series: {
          type: 'pie',
          radius: [25, 50],
          left: 'center',
          top: 'center',
          width: 150,
          itemStyle: { borderColor: '#fff', borderWidth: 1 },
          label: {
            alignTo: 'edge',
            formatter: '{name|{b}}\n{value|{d}% - {c}台}',
            minMargin: 5,
            edgeDistance: 10,
            lineHeight: 10,
            rich: { value: { fontSize: 10, color: '#999999' }}
          },
          labelLine: {
            length: 10,
            length2: 0,
            maxSurfaceAngle: 80
          },
          labelLayout: (params) => {
            const isLeft = params.labelRect.x < myChart.getWidth() / 2
            const points = params.labelLinePoints
            points[2][0] = isLeft ? params.labelRect.x : params.labelRect.x + params.labelRect.width
            return params
          },
          data: data
        }
      }

      // 渲染饼图
      chart.setOption(options)
    }
  }
}
</script>

<style scoped lang="scss">
.ech {
    flex: 9;
    // margin-top: 1rem;
    /* 调整图表向下的距离 */
    width: calc(100% - 20px);
    // height: calc(100vh / 3 - 40px);
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
}
</style>

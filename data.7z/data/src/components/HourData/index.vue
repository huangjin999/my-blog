<template>
  <div class="data-table">
    <el-form :inline="true" class="filter-form">
      <el-form-item label="站点选择">
        <el-select v-model="selectedStation" placeholder="请选择">
          <el-option v-for="station in stations" :key="station" :label="station" :value="station" />
        </el-select>
      </el-form-item>
      <el-form-item label="日期选择">
        <el-date-picker v-model="selectedDate" type="date" placeholder="选择日期" />
      </el-form-item>
      <el-form-item label="时间选择">
        <el-time-picker v-model="selectedTime" placeholder="选择时间" />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="fetchData">读取数据</el-button>
        <el-button type="success" @click="exportToExcel">导出 Excel</el-button>
      </el-form-item>
    </el-form>

    <el-table ref="table" height="250" :data="filteredData" style="width: 100%">
      <el-table-column type="index" label="序号" width="60" />
      <el-table-column prop="station" label="厂站" />
      <el-table-column prop="interval" label="间隔" />
      <el-table-column prop="node" label="节点" />
      <el-table-column prop="time" label="时间" />
      <el-table-column prop="uab" label="Uab(V)" />
      <el-table-column prop="ubc" label="Ubc(V)" />
      <el-table-column prop="uca" label="Uca(V)" />
      <el-table-column prop="ia" label="Ia(A)" />
      <el-table-column prop="ib" label="Ib(A)" />
      <el-table-column prop="ic" label="Ic(A)" />
      <el-table-column prop="p" label="P(kW)" />
      <el-table-column prop="q" label="Q(kVar)" />
      <el-table-column prop="pf" label="PF" />
      <el-table-column prop="activeEnergy" label="正向有功电能(kW)" />
    </el-table>

    <el-pagination
      v-if="total > 0"
      class="pagination"
      layout="prev, pager, next"
      :total="total"
      :page-size="pageSize"
      @current-change="handleCurrentChange"
    />
  </div>
</template>

<script>
import XLSX from 'xlsx'

export default {
  name: 'HourData',
  data() {
    return {
      selectedStation: '',
      selectedDate: '',
      selectedTime: '',
      filteredData: [],
      total: 0,
      pageSize: 10,
      currentPage: 1,
      stations: ['站点A', '站点B', '站点C'],
      tableData: []// 空数组用于存储数据

    }
  },
  methods: {

    //         async fetchData() {
    //     try {
    //       // 模拟发送请求
    //       const response = await this.simulateDataRequest();

    //       // 假设请求返回的数据在 response.data 中，您需要根据实际情况进行修改
    //       this.tableData = response.data;

    //       this.total = this.tableData.length;

    //       // 更新分页数据
    //       this.updateFilteredData();
    //     } catch (error) {
    //       console.error('Error fetching data:', error);
    //     }
    //   },
    //   // ...其他方法不变...
    //   simulateDataRequest() {
    //     // 模拟延迟1秒后返回数据
    //     return new Promise((resolve) => {
    //       setTimeout(() => {
    //         resolve({
    //           data: [
    //             {
    //               station: '站点A',
    //               interval: '间隔1',
    //               // ...其他数据...
    //             },
    //             // ...更多数据...
    //           ],
    //         });
    //       }, 1000);
    //     });
    //   },
    fetchData() {
      // 模拟从服务器获取数据并更新 this.tableData
      // 示例数据，实际开发中需要替换为实际的 API 调用
      this.tableData = [
        {
          station: '站点A',
          interval: '间隔1',
          node: '节点1',
          time: '2023-08-10 12:00:00',
          uab: '100',
          ubc: '101',
          uca: '102',
          ia: '10',
          ib: '11',
          ic: '12',
          p: '50',
          q: '30',
          pf: '0.6',
          activeEnergy: '500'
        }
        // 更多数据行...
      ]
      this.total = this.tableData.length
      this.updateFilteredData()
    },
    exportToExcel() {
      const wb = XLSX.utils.book_new()
      const ws = XLSX.utils.table_to_sheet(this.$refs.table.$el)
      const wscols = [
        { wch: 6 }, // 序号
        { wch: 12 }, // 厂站
        { wch: 10 }, // 间隔
        { wch: 8 }, // 节点
        { wch: 18 }, // 时间
        { wch: 8 }, // Uab(V)
        { wch: 8 }, // Ubc(V)
        { wch: 8 }, // Uca(V)
        { wch: 6 }, // Ia(A)
        { wch: 6 }, // Ib(A)
        { wch: 6 }, // Ic(A)
        { wch: 6 }, // P(kW)
        { wch: 6 }, // Q(kVar)
        { wch: 4 }, // PF
        { wch: 12 } // 正向有功电能(kW)
      ]
      ws['!cols'] = wscols
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1')
      XLSX.writeFile(wb, 'data.xlsx')
    },
    handleCurrentChange(currentPage) {
      this.currentPage = currentPage
      this.updateFilteredData()
    },
    updateFilteredData() {
      const startIndex = (this.currentPage - 1) * this.pageSize
      this.filteredData = this.tableData.slice(startIndex, startIndex + this.pageSize)
    }
  }
}
</script>

<style scoped>
.data-table {
    padding: 20px;
}

.filter-form {
    margin-bottom: 20px;
}

.pagination {
    margin-top: 20px;
    text-align: right;
}
</style>

<template>
  <div>
    <div class="rigrh-center">
      <div class="right-top">
        建议策略
        <span class="right-top-icon">{{ currentTime }}</span>
      </div>
      <!-- 上 -->
      <div class="right-cent">
        <div class="host-section">
          <div class="host-title">主机</div>
          <div class="host-details">
            <div class="host-detail">主机B3-X-L-1:开，出水温度:5C</div>
            <div class="host-detail">主机B3-X-L-2:开，出水温度:5C</div>
            <div class="host-detail">主机B3-X-L-3:关</div>
          </div>
        </div>
      </div>
      <!-- 下 -->
      <div class="right-bottom">
        <div class="host-section">
          <div class="host-title">冷冻泵</div>
          <div class="host-details">
            <div class="host-detail">冷冻泵1:开，频率:70Hz</div>
            <div class="host-detail">冷冻泵2: 开，频率: 70Hz</div>
            <div class="host-detail">冷冻泵3:关</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'RightCenter',
  data() {
    return {
      currentTime: new Date().toLocaleString()
    }
  },

  created() {

  },
  mounted() {
    // 每秒更新一次时间
    this.timer = setInterval(() => {
      this.currentTime = new Date().toLocaleString()
    }, 1000)
  },
  // 卸载的时候清除
  beforeDestroy() {
    clearInterval(this.timer)
  }
}
</script>
<style scoped lang='scss'>
.rigrh-center {
    display: flex;
    flex-direction: column;
    flex: 1;
    margin: 5px;

    .right-top,
    .right-cent,
    .right-bottom {
        height: 100%;
    }

    .right-top {
        position: relative;
        flex: 1;
        display: flex;
        align-items: flex-start;
        /* 使内容从顶部对齐 */
        // margin: 5px;

        .right-top-icon {
            position: absolute;
            top: 0;
            right: 0;
            padding: 5px;
        }
    }

    .right-cent {
        flex: 2;

        .host-section {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .host-title {
            font-weight: bold;
            width: 100%;
            color: green;
            border-bottom: 1px dashed #333;
            /* 添加底部虚线 */
            padding-bottom: 5px;
            margin-bottom: 5px;
        }

        .host-details {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
    }

    .right-bottom {
        flex: 2;

        .host-section {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .host-title {
            font-weight: bold;
            color: blue;
            width: 100%;
            border-bottom: 1px dashed #333;
            /* 添加底部虚线 */
            padding-bottom: 5px;
            margin-bottom: 5px;
        }

        .host-details {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
    }
}
</style>

<template>
  <div class="dashboard">
    <div class="top-section">
      <div class="top-left">
        <TopLeft />
      </div>
      <div class="top-right">
        <TopRight />
      </div>
    </div>
    <!-- <CardFive></CardFive> -->
    <div class="bottom-section">
      <Bottom />
    </div>
  </div>
</template>

<script>
import TopLeft from '@/commoneight/TopLeft'
import TopRight from '@/commoneight/TopRight'
import Bottom from '@/commoneight/Bottom'
// import CardFive from "@/commoneight/CardFive"

export default {
  components: {
    TopLeft,
    TopRight,
    Bottom

  }
}
</script>

  <style scoped lang="scss">
  .dashboard {
    display: grid;
    grid-template-rows: 1fr 3.5fr; /* 上下部分的比例 */
    width: 100%;
    height: 100%;
    padding: 5px;
    background-color: #041D45;
    color: #fff;
  }

  .top-section {
    display: grid;
    grid-template-columns: 1fr 1fr; /* 上部分左右两列的比例 */
    width: 100%;
    height: 100%;
    padding: 3px;
    .top-right{
    padding: 3px;

    }
    .top-left{
    padding: 3px;

    }
  }

  .bottom-section {
    display: grid;
    grid-template-columns: 1fr; /* 下部分只有一列 */
    height: 100%;
    width: 100%;
    padding: 3px;

  }
  </style>

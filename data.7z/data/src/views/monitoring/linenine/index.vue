<template>
  <div class="dashboardnine">
    <div class="filter-container">
      <div class="container-item">
        <el-button type="primary" @click="add">新增 </el-button>
      </div>
      <div class="container-item">
        <el-select v-model="tableData.address" placeholder="空间位置">
          <el-option v-for="item in tableData" :key="item.id" :label="item.address" :value="item.id" />
        </el-select>
      </div>
      <div class="container-item">

        <el-select v-model="tableData.type" placeholder="设备类型">
          <el-option v-for="item in tableData" :key="item.id" :label="item.type" :value="item.id" />
        </el-select>
      </div>
      <!-- <el-select v-model="tableData.status" placeholder="在线状态">
    <el-option
      v-for="item in tableData"
      :key="item.id"
      :label="item.status"
      :value="item.id">
    </el-option>
  </el-select> -->
      <!-- <el-select v-model="tableData.status" placeholder="报警等级">
    <el-option
      v-for="item in tableData"
      :key="item.id"
      :label="item.status"
      :value="item.id">
    </el-option>
  </el-select>
  <el-select v-model="tableData.status" placeholder="运行状态">
    <el-option
      v-for="item in tableData"
      :key="item.id"
      :label="item.status"
      :value="item.id">
    </el-option>
  </el-select> -->
      <div class="container-item">
        <el-input v-model="searchKeyword" placeholder="请输入设备名称" style="width: 150px;margin-right: 0.27rem;" />
        <el-button type="primary" @click="handleSearch">搜索</el-button>
      </div>

    </div>
    <el-table :data="paginatedData" border style="width: 100%" :row-class-name="tableRowClassName" :header-cell-style="{ background: '#002C69', color: '#fff' }">
      <el-table-column prop="id" label="序号" />
      <el-table-column prop="name" label="设备名称" />
      <el-table-column prop="type" label="设备类型" />
      <el-table-column prop="address" label="空间位置" />
      <el-table-column prop="status" label="链接状态">
        <template slot-scope="scope">
          <div class="status-tags">
            <el-tag v-for="(type, index) in getStatusTagTypes(scope.row.status)" :key="index" :type="type">
              {{ scope.row.status[index] }}
            </el-tag>
          </div>
        </template>
      </el-table-column>

      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="editDetails(scope.row)">组态配置</el-button>
          <el-button type="text" size="small" @click="showDetails(scope.row)">详情</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页组件 -->
    <el-pagination
      :current-page="currentPage"
      :page-sizes="[3, 6, 9]"
      :page-size="pageSize"
      layout="->,sizes, prev, pager, next, jumper"
      :total="tableData.length"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
    />
    <!-- 新增编辑数据 -->
    <el-dialog :title="isEdit ? '编辑' : '添加'" :visible.sync="dialogVisible" width="500px">
      <div>
        <el-form :label-position="labelPosition" label-width="80px" :model="formLabelAlign">
          <el-form-item label="设备名称">
            <el-input v-model="formLabelAlign.name" />
          </el-form-item>
          <el-form-item label="设备类型">
            <el-input v-model="formLabelAlign.type" />
          </el-form-item>
          <el-form-item label="空间位置">
            <el-input v-model="formLabelAlign.address" />
          </el-form-item>
          <el-form-item label="链接状态">
            <el-checkbox-group v-model="formLabelAlign.status">
              <el-checkbox label="在线">在线</el-checkbox>
              <el-checkbox label="运行">运行</el-checkbox>
              <el-checkbox label="正常">正常</el-checkbox>
              <el-checkbox label="停机">停机</el-checkbox>
              <el-checkbox label="告警">告警</el-checkbox>
              <el-checkbox label="未知">未知</el-checkbox>
              <el-checkbox label="离线">离线</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="submit">确 定</el-button>
      </span>
    </el-dialog>
    <!-- 详情 -->
    <el-dialog title="详情" :visible.sync="detailsDialogVisible" width="500px">
      <div>
        <el-form :label-position="labelPosition" label-width="80px" :model="detailsFormData">
          <el-form-item label="设备名称">
            <el-input v-model="detailsFormData.name" style="background-color: aliceblue;" :disabled="true" />
          </el-form-item>
          <el-form-item label="设备类型">
            <el-input v-model="detailsFormData.type" :disabled="true" />
          </el-form-item>
          <el-form-item label="空间位置">
            <el-input v-model="detailsFormData.address" :disabled="true" />
          </el-form-item>
          <el-form-item label="链接状态">
            <el-input v-model="detailsFormData.status" placeholder="在线, 运行, 正常" :disabled="true" />
          </el-form-item>
        </el-form>
      </div>
    </el-dialog>

  </div>
</template>

<script>
export default {
  data() {
    return {
      currentPage: 1, // 当前页码
      pageSize: 3, // 每页显示条数
      searchKeyword: '', // 存储搜索关键字
      originalData: [], // 存储原始数据，用于搜索
      dialogVisible: false, // 对话框显示与隐藏
      detailsDialogVisible: false, // 详情对话框显示与隐藏
      labelPosition: 'right', // 表单label的位置
      isEdit: false, // 编辑添加文字提示
      formLabelAlign: { // 表单数据对象
        name: '',
        type: '',
        address: '',
        status: []
      },
      detailsFormData: { // 新增的对象，用于存储详情对话框中的表单数据
        name: '',
        type: '',
        address: '',
        status: []
      },
      select: { // 最上面选择框的数据
        name: '',
        type: '',
        address: '',
        status: []
      },
      tableData: [ // 表格数据
        {
          id: '1',
          name: 'L-2F-201-123',
          type: 'AHU01',
          address: '设备平面AAA，2F，201房',
          status: ['在线', '运行', '正常']
        },
        {
          id: '2',
          name: 'L-2F-201-133',
          type: 'AHU01',
          address: '设备平面AAA，2F，201房',
          status: ['告警', '运行', '停机']
        },
        {
          id: '3',
          name: 'L-2F-201-143',
          type: 'AHU01',
          address: '设备平面AAA，2F，201房',
          status: ['告警', '未知', '离线']
        },
        {
          id: '4',
          name: 'L-2F-201-153',
          type: 'AHU01',
          address: '设备平面AAA，2F，201房',
          status: ['告警', '未知', '离线']
        },
        {
          id: '5',
          name: 'T-2F-201-123',
          type: 'AHU01',
          address: '设备平面AAA，2F，201房',
          status: ['告警', '未知', '离线']
        },
        {
          id: '6',
          name: 'L-2F-201-123',
          type: 'AHU01',
          address: '设备平面AAA，2F，201房',
          status: ['告警', '未知', '离线']
        }
      ]
    }
  },
  computed: {
    // 计算分页后的数据
    paginatedData() {
      const startIndex = (this.currentPage - 1) * this.pageSize
      const endIndex = startIndex + this.pageSize
      return this.tableData.slice(startIndex, endIndex)
    }
  },
  created() {
    // 在组件创建时备份原始数据
    this.originalData = [...this.tableData]
  },
  methods: {
    // 点击行
    handleClick(row) {
      console.log(row)
    },
    // tag标签类型
    getStatusTagTypes(status) {
      const types = []
      for (const s of status) {
        switch (s) {
          case '在线':
            types.push('success') // Green tag for '在线'
            break
          case '运行':
            types.push('primary') // Blue tag for '运行'
            break
          case '正常':
            types.push('success') // Green tag for '正常'
            break
          case '停机':
            types.push('danger') // Red tag for '停机'
            break
          case '告警':
            types.push('warning') // Yellow tag for '告警'
            break
          case '未知':
            types.push('info') // Light blue tag for '未知'
            break
          case '离线':
            types.push('danger') // Red tag for '离线'
            break
          default:
            types.push('info') // Default to light blue tag for unknown values
        }
      }
      return types
    },
    // 分页
    // 当页码改变时触发
    handleCurrentChange(newPage) {
      this.currentPage = newPage
    },
    // 当每页显示条数改变时触发
    handleSizeChange(newSize) {
      this.pageSize = newSize
      this.currentPage = 1 // 切换每页显示条数后，回到第一页
    },
    // 搜索
    // handleSearch() {
    //   // 根据搜索关键字进行过滤
    //   if (this.searchKeyword) {
    //     this.tableData = this.tableData.filter(item => item.name.includes(this.searchKeyword));
    //   }
    //   // 重新设置分页为第一页
    //   this.currentPage = 1;
    // },
    handleSearch() {
      if (this.searchKeyword) {
        this.tableData = this.originalData.filter(item => item.name.includes(this.searchKeyword))
      } else {
        this.tableData = [...this.originalData] // 恢复原始数据
      }
      this.currentPage = 1
    },

    submit() {
      if (this.isEdit) {
        this.handleEditData()
      } else {
        this.handleAddData()
      }
    },
    // 新增
    add() {
      this.isEdit = false
      this.dialogVisible = true
    },
    // 添加数据
    handleAddData() {
      // 将表单数据添加到 tableData 数组中
      this.tableData.push({
        id: (this.tableData.length + 1).toString(),
        name: this.formLabelAlign.name,
        type: this.formLabelAlign.type,
        address: this.formLabelAlign.address,
        status: this.formLabelAlign.status// 分割状态字符串为数组
      })
      this.dialogVisible = false // 关闭对话框
      // 清空表单数据
      this.formLabelAlign.name = ''
      this.formLabelAlign.type = ''
      this.formLabelAlign.address = ''
      this.formLabelAlign.status = []
    },
    // 点击显示详情
    showDetails(row) {
      this.detailsFormData = row
      this.detailsDialogVisible = true
      console.log(row)
    },
    // 组态配置编辑
    editDetails(row) {
      this.isEdit = true
      this.dialogVisible = true
      this.formLabelAlign.name = row.name
      this.formLabelAlign.type = row.type
      this.formLabelAlign.address = row.address
      this.formLabelAlign.status = row.status
    },
    handleEditData() {
      // 找到当前编辑的数据在表格数据中的索引
      this.dialogVisible = false // 关闭编辑对话框
      //   // 清空编辑表单数据
      this.formLabelAlign = {
        name: '',
        type: '',
        address: '',
        status: []
      }
    },
    // 表格颜色
    tableRowClassName({ row, rowIndex }) {
      if ((rowIndex + 1) % 2 === 0) {
        return 'warning-row'
      } else {
        return 'success-row'
      }
    }

  }

  // },

}
</script>
<style  lang='scss'>
// elementui 表格公共样式
@import '@/assets/scss/elementui.scss';
.dashboardnine {
  // height: calc(100vh - 2.24rem);
  width: 100%;
  height: 100vh;
  background-color: #041D45;
  padding: 5px;
  .filter-container{
    display: flex;
    margin: 0.5rem 0;
    .container-item{
      margin: 0 .2667rem;

    }
  }
}

.status-tags {
  display: flex;
  gap: 5px;
  /* 设置标签之间的间距 */
}
</style>

<template>
  <div class="dashboard">
    <div class="top">
      <div class="left">
        <div class="top">
          <LeftTop />
        </div>
        <div class="bottom">
          <LeftCenter />
        </div>
      </div>
      <div class="center">
        <div class="top">
          <CenterTop />
        </div>
        <div class="bottom" />
        <CenterTopTwo></CenterTopTwo>
      </div>
      <div class="right">
        <div class="top">
          <RightTop />
        </div>
        <div class="bottom">
          <RightCenter />
        </div>
      </div>

    </div>
    <div class="bottom">
      <div class="one">
        <LeftBottom />
      </div>
      <div class="two">
        <CenterBottom />
      </div>
      <div class="three">
        <RightBottom />
      </div>

    </div>
  </div>
</template>

<script>
import LeftTop from '@/commonthree/LeftTop'
import LeftCenter from '@/commonthree/LeftCenter'
import LeftBottom from '@/commonthree/LeftBottom'
import CenterBottom from '@/commonthree/CenterBottom'
import CenterTop from '@/commonthree/CenterTop'
import RightTop from '@/commonthree/RightTop'
import RightCenter from '@/commonthree/RightCenter'
import RightBottom from '@/commonthree/RightBottom'
import CenterTopTwo from '@/commonthree/CenterTopTwo'
export default {
  components: {
    LeftTop,
    LeftCenter,
    LeftBottom,
    CenterBottom,
    CenterTop,
    RightTop,
    RightCenter,
    RightBottom,
    CenterTopTwo

  }

}
</script>

<style scoped lang="scss">
.dashboard {
  width: 100%;
  height: 100vh;
  color: #fff;
  display: flex;
  flex-direction: column;
  background-color: #041D45;
  .top{
    flex: 2;
    height: 100%;
    width: 100%;
    display: flex;
    justify-content: space-between;
    .left{
      flex: 1;
      height: 100%;
      width: 100%;
      display: flex;
      flex-direction: column;
      .top{
        flex: 1;
      height: 100%;
      width: 100%;
      padding: 3px;
      }
      .bottom{
        flex: 1;
      height: 100%;
      width: 100%;
      padding: 3px;

      }
    }
    .center{
      flex: 2;
      height: 100%;
      width: 100%;
      display: flex;
      flex-direction: column;
      .top{
        flex: 1;
        height: 100%;
      width: 100%;
      }
      .bottom{
        flex: 5;
        height: 100%;
      width: 100%;
      padding: 0 6px 0 3px;

      }

    }
    .right{
      flex: 1;
      height: 100%;
      width: 100%;
      display: flex;
      flex-direction: column;
      .top{
        flex: 1;
      height: 100%;
      width: 100%;
      padding: 3px;

      }
      .bottom{
        flex: 1;
      height: 100%;
      width: 100%;
      padding: 3px;

      }

    }
  }
  .bottom{
    flex: 1;
    height: 100%;
    width: 100%;
    display: flex;
    justify-content: space-between;
    .one,.two{
      flex: 1.5;
    height: 100%;
    width: 100%;
    padding: 3px;

    }
    .three{
      flex: 1;
    height: 100%;
    width: 100%;
    padding: 3px;

    }
  }

}
</style>

<template>
  <div class="dashboard">
    <div class="left-section">
      <div class="sub-row">
        <LeftTop />
      </div>
      <div class="sub-row">
        <LeftCenter />
      </div>
      <div class="sub-row">
        <LeftBottom />
      </div>
    </div>
    <div class="right-section">
      <div class="row1">
        <div class="sub-column">
          <RightOne />
        </div>
        <div class="sub-column">
          <RightTwo />
        </div>
      </div>
      <div class="row2">
        <div class="sub-column">
          <RightThree />
        </div>
        <div class="sub-column">
          <RightFour />
        </div>
      </div>
      <div class="row3">
        <!-- <dv-border-box-8> -->
        <!-- <BottomOne></BottomOne> -->
        <!-- </dv-border-box-8> -->

        <div class="sub-column"><BottomOne /></div>
        <div class="sub-column"><BottomTwo /></div>
        <div class="sub-column"><BottomThree /></div>
        <div class="sub-column"><BottomFour /></div>
      </div>
    </div>
  </div>
</template>

<script>
import LeftTop from '@/commonsix/LeftTop'
import LeftBottom from '@/commonsix/LeftBottom'
import LeftCenter from '@/commonsix/LeftCenter'
import RightOne from '@/commonsix/RightOne'
import RightTwo from '@/commonsix/RightTwo'
import RightThree from '@/commonsix/RightThree'
import RightFour from '@/commonsix/RightFour'
import BottomOne from '@/commonsix/BottomOne'
import BottomTwo from '@/commonsix/BottomTwo'
import BottomThree from '@/commonsix/BottomThree'
import BottomFour from '@/commonsix/BottomFour'

export default {
  components: {
    LeftTop,
    LeftBottom,
    LeftCenter,
    RightOne,
    RightTwo,
    RightThree,
    RightFour,
    BottomOne,
    BottomTwo,
    BottomThree,
    BottomFour
  }
}
</script>

<style scoped lang="scss">
.dashboard {
  display: flex;
  width: 100%;
  height: 100vh;
  background-color: #041D45;
  padding: 5px;
justify-content: space-between;
color: #fff;
}

.left-section {
  flex: 1;
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
  .sub-row {
    flex: 1;
    height: 100%;
    width: 100%;
    padding: 3px;

  }
}

.right-section {
  flex: 2;
  /* 占比三份 */
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
  .row1,.row2,.row3 {
    flex: 1;
    display: flex;
    justify-content: space-between;
    height: 100%;
    width: 100%;
    .sub-column {
      flex: 1;
      height: 100%;
      width: 100%;
      padding: 3px;
    }
  }
}

</style>

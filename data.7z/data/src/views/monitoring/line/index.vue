<template>
  <div class="dashboard">
    <div class="top">
      <div class="left">
        <div class="top">
          <LeftTop />
        </div>
        <div class="bottom">
          <LeftCenter />
        </div>
      </div>
      <div class="center">
        <div class="top">
          <CenterTop />
        </div>
        <div class="bottom">
          <CenterBottom />
        </div>
      </div>
      <div class="right">
        <div class="top">
          <RightTop />
        </div>
        <div class="bottom">
          <RightCenter />
        </div>
      </div>

    </div>
    <div class="bottom">
      <div class="one">
        <LeftBottom />
      </div>
      <div class="one">
        <LeftCenterOne />
      </div>
      <div class="one">
        <RightCenterOne />
      </div>
      <div class="one">
        <RightBottom />
      </div>

    </div>

  </div>
</template>

<script>
import LeftTop from '@/commonone/LeftTop'
import LeftCenter from '@/commonone/LeftCenter'
import LeftBottom from '@/commonone/LeftBottom'
import LeftCenterOne from '@/commonone/LeftCenterOne'
import RightCenter from '@/commonone/RightCenter'
import RightCenterOne from '@/commonone/RightCenterOne'
import RightBottom from '@/commonone/RightBottom'
import CenterTop from '@/commonone/CenterTop'
import CenterBottom from '@/commonone/CenterBottom'
import RightTop from '@/commonone/RightTop'

export default {
  components: {
    LeftTop,
    LeftCenter,
    LeftBottom,
    LeftCenterOne,
    RightCenter,
    RightCenterOne,
    RightBottom,
    CenterTop,
    CenterBottom,
    RightTop
  }

  // mounted() {
  //   window.addEventListener("resize", this.handleWindowResize);
  // },
  // beforeDestroy() {
  //   window.removeEventListener("resize", this.handleWindowResize);
  // },
  // methods: {
  //   handleWindowResize() {
  //     this.refreshPage();
  //   },
  //   // 页面变化就刷新
  //   refreshPage() {
  //     window.location.reload();
  //   },
  // },

}
</script>

<style scoped lang="scss">

.dashboard {
  width: 100%;
  height: 100vh;
  // height: calc(100vh - 60px);
  color: #fff;
  display: flex;
  flex-direction: column;
  background-color: #041D45;
  // background: url(../../../assets/images/log.png) no-repeat center center/cover;
  .top{
    flex: 2;
    height: 100%;
    width: 100%;
    display: flex;
    justify-content: space-between;
    .left{
      flex: 1;
      height: 100%;
      width: 100%;
      display: flex;
      flex-direction: column;
      .top{
        flex: 1;
      height: 100%;
      width: 100%;
      padding: 3px;
      }
      .bottom{
        flex: 1;
      height: 100%;
      width: 100%;
      padding: 3px;

      }
    }
    .center{
      flex: 2;
      height: 100%;
      width: 100%;
      display: flex;
      flex-direction: column;
      .top{
        flex: 1;
        height: 100%;
      width: 100%;
      }
      .bottom{
        flex: 5;
        height: 100%;
      width: 100%;
      padding: 0 3px;

      }

    }
    .right{
      flex: 1;
      height: 100%;
      width: 100%;
      display: flex;
      flex-direction: column;
      .top{
        flex: 1;
      height: 100%;
      width: 100%;
      padding: 3px;

      }
      .bottom{
        flex: 1;
      height: 100%;
      width: 100%;
      padding: 3px;

      }

    }
  }
  .bottom{
    flex: 1;
    height: 100%;
    width: 100%;
    display: flex;
    justify-content: space-between;
    .one{
      flex: 1;
    height: 100%;
    width: 100%;
    padding: 3px;

    }

  }

}
</style>

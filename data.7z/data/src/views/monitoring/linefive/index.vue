<template>
  <div class="dashboard">
    <div class="row">
      <div class="sub-row"><TopOne /></div>
      <div class="sub-row"><TopTwo /></div>
      <div class="sub-row"><TopThree /></div>

    </div>
    <div class="row">
      <div class="sub-row"><BottomOne /></div>
      <div class="sub-row"><BottomTwo /></div>
      <div class="sub-row"><BottomThree /></div>

    </div>

  </div>
</template>

<script>
import TopOne from '@/commonfive/TopOne'
import TopTwo from '@/commonfive/TopTwo'
import BottomOne from '@/commonfive/BottomOne'
import TopThree from '@/commonfive/TopThree'
import BottomTwo from '@/commonfive/BottomTwo'
import BottomThree from '@/commonfive/BottomThree'

export default {
  components: {
    TopOne,
    TopTwo,
    TopThree,
    BottomOne,
    BottomTwo,
    BottomThree

  }

}
</script>

<style scoped lang="scss">
.dashboard {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100vh;
    padding: 5px;
    color: #fff;
    background-color: #041D45;
}

.row {
    flex: 1;
    display: flex;
    justify-content: space-between; /* 将内容平均分布在容器中 */
    align-items: center;
    font-size: 1.2rem; /* 使用 rem 单位来设置字体大小 */
    width: 100%;
    height: 100%;
}

.sub-row {
    flex: 1; /* 占比 1 份 */
    height: 100%;
    height: 100%;
    padding: 3px;
    // border: 1px solid red;

}
</style>

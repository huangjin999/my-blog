<template>
  <div class="dashboard">
    <div class="left-section">
      <div class="left-box">
        <LeftTop />
      </div> <!-- 上方的小方格 -->
      <div class="divider" /> <!-- 分隔符 -->
      <div class="left-box">
        <Left-bottom />
      </div> <!-- 下方的小方格 -->
    </div>
    <div class="right-section">
      <!-- 右侧内容区域 -->
      <Right />
    </div>
  </div>
</template>

<script>
import LeftTop from '@/commontwo/LeftTop'
import LeftBottom from '@/commontwo/LeftBottom'
import Right from '@/commontwo/Right'
export default {
  components: {
    LeftTop,
    LeftBottom,
    Right

  },
  data() {
    return {

    }
  },
  created() {

  },
  mounted() {

  },
  methods: {

  }
}
</script>

<style scoped lang='scss'>
.dashboard {
  display: flex;
  // height: calc(100vh - 2.24rem);
  width: 100%;
  height: 100vh;
  color: #ffffff;
  box-sizing: border-box;
  padding: 5px;
  background-color: #041D45;

}

.left-section,
.right-section {
  display: flex;
  // box-sizing: border-box;
  width: 100%;
  height: 100%;
}

.left-section {
  flex: 1;
  /* 左边占一份 */
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
}

.left-box {
  flex: 1;
  width: 100%;
  height: 100%;
  padding: 3px;
}

.divider {
  height: 0.2667rem;
  /* 分隔符高度 */

}

.right-section {
  flex: 2;
  width: 100%;
  height: 100%;
  padding: 3px;

}
</style>

<template>
  <div class="dashboards">
    <div class="top">
      <!-- 添加年份选择 -->
      <el-select v-model="selectedYear" placeholder="选择年份">
        <el-option v-for="year in years" :key="year" :value="year" :label="year" />
      </el-select>
      <!-- 添加导出 Excel 表格按钮 -->
      <div class="export-button">
        <el-button type="primary" @click="exportToExcel">导出报表</el-button>

      </div>
    </div>
    <el-table
      :data="tableData"
      style="width: 100%"
      :row-class-name="tableRowClassName"
      row-key="id"
      border
      default-expand-all
      :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
      :header-cell-style="{ background: '#002C69', color: '#fff' }"
    >
      <el-table-column prop="name" label="能耗名称" width="120" />
      <el-table-column prop="one" label="一月" />
      <el-table-column prop="two" label="二月" />
      <el-table-column prop="three" label="三月" />
      <el-table-column prop="four" label="四月" />
      <el-table-column prop="five" label="五月" />
      <el-table-column prop="six" label="六月" />
      <el-table-column prop="seven" label="七月" />
      <el-table-column prop="eight" label="八月" />
      <el-table-column prop="nine" label="九月" />
      <el-table-column prop="ten" label="十月" />
      <el-table-column prop="november" label="十一月" />
      <el-table-column prop="dec" label="十二月" />
      <el-table-column prop="max" label="小计" />
    </el-table>

    <!-- 添加分页 -->
    <el-pagination
      :current-page="currentPage"
      :page-sizes="[10, 20, 30, 40]"
      :page-size="pageSize"
      layout="sizes, prev, pager, next, jumper"
      :total="tableData.length"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
    />
  </div>
</template>

<style  lang="scss">

// elementui 表格公共样式
@import '@/assets/scss/elementui.scss';
.dashboards {
  width: 100%;
  height: 100%;
  background-color: #011F55;
  padding: 5px;
  /* 设置根元素的字体大小 */
  .top {
    display: flex;
    justify-content: space-between;
    // margin: 0.5rem 0;
    padding: 5px;
  }

  .el-pagination {
    text-align: right;
    margin-top: 1rem;
  }
}
</style>

<script>
import XLSX from 'xlsx'

export default {
  data() {
    return {
      selectedYear: '', // 用于存储选择的年份
      currentPage: 1, // 当前页码
      pageSize: 10, // 每页显示条数
      tableData: [
        {
          id: 1,
          one: '1,442,20.0',
          two: '1,442,20.0',
          three: '1,44,520.0',
          four: '1,442520.0',
          five: '1,442520.0',
          six: '1,442,20.0',
          seven: '1,44,520.0',
          eight: '1,44,520.0',
          nine: '1,442520.0',
          ten: '1,442,20.0',
          november: '1442,520.0',
          dec: '1,442,20.0',
          max: '1,442',
          name: '精密空调'
        },
        {
          id: 2,
          one: '1,442,20.0',
          two: '1,442,20.0',
          three: '1,44,520.0',
          four: '1,442520.0',
          five: '1,442520.0',
          six: '1,442,20.0',
          seven: '1,44,520.0',
          eight: '1,44,520.0',
          nine: '1,442520.0',
          ten: '1,442,20.0',
          november: '1442,520.0',
          dec: '1,442,20.0',
          max: '1,442',
          name: '精密空调'
        },
        {
          id: 3,
          one: '1,442,20.0',
          two: '1,442,20.0',
          three: '1,44,520.0',
          four: '1,442520.0',
          five: '1,442520.0',
          six: '1,442,20.0',
          seven: '1,44,520.0',
          eight: '1,44,520.0',
          nine: '1,442520.0',
          ten: '1,442,20.0',
          november: '1442,520.0',
          dec: '1,442,20.0',
          max: '1,442',
          name: '精密空调',
          children: [{
            id: 4,
            one: '1,442,20.0',
            two: '1,442,20.0',
            three: '1,44,520.0',
            four: '1,442520.0',
            five: '1,442520.0',
            six: '1,442,20.0',
            seven: '1,44,520.0',
            eight: '1,44,520.0',
            nine: '1,442520.0',
            ten: '1,442,20.0',
            november: '1442,520.0',
            dec: '1,442,20.0',
            max: '1,442',
            name: '精密空调1'
          },
          {
            id: 5,
            one: '1,442,20.0',
            two: '1,442,20.0',
            three: '1,44,520.0',
            four: '1,442520.0',
            five: '1,442520.0',
            six: '1,442,20.0',
            seven: '1,44,520.0',
            eight: '1,44,520.0',
            nine: '1,442520.0',
            ten: '1,442,20.0',
            november: '1442,520.0',
            dec: '1,442,20.0',
            max: '1,442',
            name: '精密空调2'
          }]
        },
        {
          id: 6,
          one: '1,442,20.0',
          two: '1,442,20.0',
          three: '1,44,520.0',
          four: '1,442520.0',
          five: '1,442520.0',
          six: '1,442,20.0',
          seven: '1,44,520.0',
          eight: '1,44,520.0',
          nine: '1,442520.0',
          ten: '1,442,20.0',
          november: '1442,520.0',
          dec: '1,442,20.0',
          max: '1,442',
          name: '精密空调'
        },
        {
          id: 7,
          one: '1,442,20.0',
          two: '1,442,20.0',
          three: '1,44,520.0',
          four: '1,442520.0',
          five: '1,442520.0',
          six: '1,442,20.0',
          seven: '1,44,520.0',
          eight: '1,44,520.0',
          nine: '1,442520.0',
          ten: '1,442,20.0',
          november: '1442,520.0',
          dec: '1,442,20.0',
          max: '1,442',
          name: '精密空调'
        },
        {
          id: 8,
          one: '1,442,20.0',
          two: '1,442,20.0',
          three: '1,44,520.0',
          four: '1,442520.0',
          five: '1,442520.0',
          six: '1,442,20.0',
          seven: '1,44,520.0',
          eight: '1,44,520.0',
          nine: '1,442520.0',
          ten: '1,442,20.0',
          november: '1442,520.0',
          dec: '1,442,20.0',
          max: '1,442',
          name: '精密空调'
        },
        {
          id: 9,
          one: '1,442,20.0',
          two: '1,442,20.0',
          three: '1,44,520.0',
          four: '1,442520.0',
          five: '1,442520.0',
          six: '1,442,20.0',
          seven: '1,44,520.0',
          eight: '1,44,520.0',
          nine: '1,442520.0',
          ten: '1,442,20.0',
          november: '1442,520.0',
          dec: '1,442,20.0',
          max: '1,442',
          name: '精密空调'
        },
        {
          id: 10,
          one: '1,442,20.0',
          two: '1,442,20.0',
          three: '1,44,520.0',
          four: '1,442520.0',
          five: '1,442520.0',
          six: '1,442,20.0',
          seven: '1,44,520.0',
          eight: '1,44,520.0',
          nine: '1,442520.0',
          ten: '1,442,20.0',
          november: '1442,520.0',
          dec: '1,442,20.0',
          max: '1,442',
          name: '精密空调'
        },
        {
          id: 11,
          one: '1,442,20.0',
          two: '1,442,20.0',
          three: '1,44,520.0',
          four: '1,442520.0',
          five: '1,442520.0',
          six: '1,442,20.0',
          seven: '1,44,520.0',
          eight: '1,44,520.0',
          nine: '1,442520.0',
          ten: '1,442,20.0',
          november: '1442,520.0',
          dec: '1,442,20.0',
          max: '1,442',
          name: '精密空调'
        },
        {
          id: 12,
          one: '1,442,20.0',
          two: '1,442,20.0',
          three: '1,44,520.0',
          four: '1,442520.0',
          five: '1,442520.0',
          six: '1,442,20.0',
          seven: '1,44,520.0',
          eight: '1,44,520.0',
          nine: '1,442520.0',
          ten: '1,442,20.0',
          november: '1442,520.0',
          dec: '1,442,20.0',
          max: '1,442',
          name: '精密空调'
        },
        {
          id: 13,
          one: '1,442,20.0',
          two: '1,442,20.0',
          three: '1,44,520.0',
          four: '1,442520.0',
          five: '1,442520.0',
          six: '1,442,20.0',
          seven: '1,44,520.0',
          eight: '1,44,520.0',
          nine: '1,442520.0',
          ten: '1,442,20.0',
          november: '1442,520.0',
          dec: '1,442,20.0',
          max: '1,442',
          name: '精密空调13'
        }

      ]

    }
  },
  computed: {
    years() {
      // 返回年份的数组，根据实际情况进行调整
      const currentYear = new Date().getFullYear()
      return Array.from({ length: 10 }, (_, index) => currentYear - index)
    }
    // tableData() {
    //   // 假设这里是表格数据
    //   // 根据选择的年份来过滤或获取相应的数据
    //   // 返回根据年份过滤后的数据
    // },
  },
  methods: {
    tableRowClassName({ row, rowIndex }) {
      if ((rowIndex + 1) % 2 === 0) {
        return 'warning-row'
      } else {
        return 'success-row'
      }
    },
    // 导出报表
    exportToExcel() {
      const wb = XLSX.utils.table_to_book(this.$refs.exportTable.$el)
      XLSX.writeFile(wb, 'data.xlsx')
    },
    // 改变页码
    handleSizeChange(newSize) {
      this.pageSize = newSize
    },
    handleCurrentChange(newPage) {
      this.currentPage = newPage
    }
  }
}
</script>

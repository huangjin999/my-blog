<template>
  <div class="dashboard">
    <div class="row-top">
      <div class="left">
        <LeftTop />
      </div>
      <div class="center">
        <TopCenter />
      </div>
      <div class="right">
        <TopRight />
      </div>
    </div>
    <div class="row-center">
      <div class="sub-row">
        <CenterOne />
      </div>
      <div class="sub-row">
        <CenterTwo />
      </div>
      <div class="sub-row">
        <CenterThree />
      </div>
      <div class="sub-row">
        <CenterFour />
      </div>
    </div>
    <div class="row-bottom">
      <div class="sub-row">
        <BottomOne />
      </div>
      <div class="sub-row">
        <BottomTwo />
      </div>
      <div class="sub-row">
        <BottomThree />
      </div>
      <div class="sub-row">
        <BottomFour />
      </div>
    </div>
  </div>
</template>

<script>
import LeftTop from '@/commonfour/LeftTop'
import TopCenter from '@/commonfour/TopCenter'
import TopRight from '@/commonfour/TopRight'
import CenterOne from '@/commonfour/CenterOne'
import CenterTwo from '@/commonfour/CenterTwo'
import CenterThree from '@/commonfour/CenterThree'
import CenterFour from '@/commonfour/CenterFour'
import BottomTwo from '@/commonfour/BottomTwo'
import BottomThree from '@/commonfour/BottomThree'
import BottomFour from '@/commonfour/BottomFour'
import BottomOne from '@/commonfour/BottomOne'

export default {
  components: {
    LeftTop,
    TopCenter,
    TopRight,
    CenterOne,
    CenterTwo,
    CenterThree,
    CenterFour,
    BottomTwo,
    BottomThree,
    BottomFour,
    BottomOne

  }

}
</script>

<style scoped lang="scss">
.dashboard {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100vh;
    padding: 5px;
    color: #fff;
    background-color: #041D45;
    .row-top{
        flex: 1;
        display: flex;
        width: 100%;
        height: 100%;
        justify-content: space-between;
       .left{
        flex: 1;
        height: 100%;
        width: 100%;
        padding: 3px;

       }
       .center,.right{
        flex: 1.5;
        height: 100%;
        width: 100%;
        padding: 3px;

       }
    }
    .row-center{
        flex: 1;
        display: flex;
        width: 100%;
        height: 100%;
        justify-content: space-between;
        .sub-row{
            flex: 1;
            height: 100%;
            width: 100%;
            padding: 3px;

        }
    }
    .row-bottom{
        flex: 1;
        display: flex;
        width: 100%;
        height: 100%;
        justify-content: space-between;
        .sub-row{
            flex: 1;
            height: 100%;
            width: 100%;
            padding: 3px;

        }

        // .sub-row{
        //     flex: 1;
        //     height: 100%;
        //     width: 100%;
        //     border: 1px solid #fff;
        // }
    }
}

</style>

<template>
  <div class="ech-box">
    <div class="top">
      <div class="left">
        lt、末端、冷站能耗能耗环比
      </div>
      <div class="right" />
    </div>
    <div class="bottom">
      <div ref="chartContainer" style="width: 100%; height: 100%;" />
    </div>

  </div>
</template>

<script>
import echarts from 'echarts'

export default {
  name: 'CenterThree',
  mounted() {
    this.renderChart()
    window.addEventListener('resize', this.handleResize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      this.chart = echarts.init(chartContainer)

      const option = {
        textStyle: {
          color: '#fff'
        },

        title: {
          // text: 'lt、末端、冷站能耗能耗环比',
          // top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#fff'

          }
        },
        grid: {
          top: '40px',
          bottom: '13%',
          left: '13%',
          right: '5%'
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            crossStyle: {
              color: '#999'
            }
          }
        },
        // toolbox: {
        //     feature: {
        //         dataView: { show: true, readOnly: false },
        //         magicType: { show: true, type: ['line', 'bar'] },
        //         restore: { show: true },
        //         saveAsImage: { show: true }
        //     }
        // },
        legend: {
          // top: '20px',
          data: ['IT环比', '末端环比', '冷站环比'],
          textStyle: {
            fontSize: 8,
            color: '#AEC8DF'
          },
          itemWidth: 6, // 设置图例项宽度
          itemHeight: 6 // 设置图例项高度

        },
        xAxis: [
          {
            type: 'category',
            data: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'],

            axisPointer: {
              type: 'shadow'
            },
            axisLabel: {
              textStyle: {
                fontSize: 10
              }
            }
          }
        ],
        yAxis: [
          {
            name: '%',
            nameTextStyle: {
              fontSize: 8
            },
            type: 'value',
            splitLine: {
              show: true,
              lineStyle: {
                type: 'dashed' //
              }
            },
            axisLabel: {
              textStyle: {
                fontSize: 10
              }
            }
          }
        ],
        series: [
          {
            name: 'IT环比',
            type: 'bar',
            itemStyle: {
              color: '#358FC1', //
              fontSize: 10

            },
            data: [
              2.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3
            ]
          },
          {
            name: '末端环比',
            type: 'bar',
            itemStyle: {
              color: '#13F8FD', //
              fontSize: 10

            },
            data: [
              2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6, 182.2, 48.7, 18.8, 6.0, 2.3
            ]
          },
          {
            name: '冷站环比',
            type: 'bar',
            itemStyle: {
              color: '#FD9D04',
              fontSize: 10
            },
            data: [2.0, 2.2, 3.3, 4.5, 6.3, 10.2, 20.3, 23.4, 23.0, 16.5, 12.0, 6.2]
          }
        ]
      }

      this.chart.setOption(option)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    }
  }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;
    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;

        }

        .right {
            display: flex;
            font-size: .2133rem;

            .day,
            .mouth,
            .year {
                background-color: #024596;
                border-radius: .1333rem;
                margin: 2px;
                padding: 2px;
                box-sizing: border-box;
                cursor: pointer;

                span {
                    color: #fff;

                }
            }

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
    }

}

</style>

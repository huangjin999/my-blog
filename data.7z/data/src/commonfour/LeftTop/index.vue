<template>
  <div class="ech-box">
    <div class="top">
      <div class="left">
        总耗电、总耗水
      </div>
      <div class="right">
        <div class="day"><span>日</span></div>
        <div class="mouth"><span>月</span></div>
        <div class="year"><span>年</span></div>
      </div>
    </div>
    <div class="bottom">
      <div class="left">
        <div class="center-content">
          <div class="icon">
            <i class="el-icon-coin" />
            <!-- <img src="../../assets/images/icon_04.png" alt=""> -->
          </div>
          <div class="number textbig">323.4</div>
          <div class="and textccc">总用电量 ( kwh )</div>
        </div>
      </div>
      <div class="right">
        <div class="center-content">
          <div class="icon">
            <i class="el-icon-coin" />
            <!-- <img src="../../assets/images/icon_04.png" alt=""> -->
          </div>
          <div class="number textbig">323.4</div>
          <div class="and textccc">总用水量 ( t )</div>
        </div>
      </div>
    </div>
  </div>
</template>

  <style scoped lang="scss">
  .ech-box {
    width: 100%;
    height: 100%;
    border: 1px solid #024596;
    display: flex;
    flex-direction: column;

    .top {
      width: 100%;
      height: 100%;
      flex: 1;
      color: #fff;
      padding: 5px;
      display: flex;
      justify-content: space-between;
      .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;

        }

        .right {
            display: flex;
            font-size: .2133rem;

            .day,
            .mouth,
            .year {
                background-color: #024596;
                border-radius: .1333rem;
                margin: 2px;
                padding: 2px;
                box-sizing: border-box;
                cursor: pointer;

                span {
                    color: #fff;

                }
            }

        }
    }

    .bottom {
      flex: 9;
      width: 100%;
      height: 100%;
      display: flex;
      justify-content: space-between;

      .left {
        flex: 1;
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center; /* 水平居中 */
        align-items: center; /* 垂直居中 */

        .center-content {
          text-align: center; /* 内容水平居中 */
          .icon{
            color: #fff;
          }
          .number{
            margin: 10px 0;
          }
        }
      }

      .right {
        flex: 1;
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center; /* 水平居中 */
        align-items: center; /* 垂直居中 */

        .center-content {
          text-align: center; /* 内容水平居中 */
          .icon{
            color: #fff;
          }
          .number{
            margin: 10px 0;
          }
        }
      }
    }
  }
  .textccc {
    color: #AEC8DF;
    font-size: 0.26rem;
}
.textbig{
    font-size: 1.2rem;
    color: #fff;
    font-weight: 800;
}

  </style>

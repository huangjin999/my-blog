<template>
  <div class="ech-box">
    <div class="top">
      <div class="left">
        总电耗同比
      </div>
      <div class="right" />
    </div>
    <div class="bottom">
      <div ref="chartContainer" style="width: 100%; height: 100%;" />
    </div>

  </div>
</template>

<script>
import echarts from 'echarts'

export default {
  name: 'TopLeft',
  mounted() {
    this.renderChart()
    window.addEventListener('resize', this.handleResize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      this.chart = echarts.init(chartContainer)

      const option = {
        textStyle: {
          color: '#fff'
        },

        title: {
          //   text: '总电耗同比',
          //   top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#fff'

          }
        },
        grid: {
          top: '40px',
          bottom: '13%',
          left: '10%',
          right: '5%'
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          //   top: '20px',
          data: ['总电耗同比'],
          textStyle: {
            fontSize: 8,
            color: '#AEC8DF'
          },
          itemWidth: 6, // 设置图例项宽度
          itemHeight: 6 // 设置图例项高度
        },
        xAxis: {
          type: 'category',
          // boundaryGap: true,
          boundaryGap: false, //
          data: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'],
          axisLabel: {
            interval: 0,
            // rotate: 45,
            textStyle: {
              fontSize: 10
            }
          }
        },
        yAxis: {
          name: '%',
          nameTextStyle: {
            fontSize: 8
          },
          type: 'value',
          splitLine: {
            show: true,
            lineStyle: {
              type: 'dashed' // S
            }
          },
          axisLabel: {
            textStyle: {
              fontSize: 10
            }
          }
        },
        series: [
          {
            name: '总电耗同比',
            type: 'line',
            stack: 'stacked',
            data: [110, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 120],
            itemStyle: {
              color: '#FD9D04', //
              fontSize: 10

            }
          }

        ]
      }

      this.chart.setOption(option)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    }
  }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;
    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;

        }

        .right {
            display: flex;
            font-size: .2133rem;

            .day,
            .mouth,
            .year {
                background-color: #024596;
                border-radius: .1333rem;
                margin: 2px;
                padding: 2px;
                box-sizing: border-box;
                cursor: pointer;

                span {
                    color: #fff;

                }
            }

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
    }

}

</style>

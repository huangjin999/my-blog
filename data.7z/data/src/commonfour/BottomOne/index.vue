<template>
  <!-- <dv-border-box-8> -->
  <div class="ech-box">
    <div class="top">
      <div class="left">
        机载主机、蓄冰主机、水泵、水塔及占比
      </div>
      <div class="right" />
    </div>
    <div class="bottom">
      <div class="upper-section">
        <div ref="chartContainer" style="width: 100%; height: 100%; " />
      </div>
      <div class="lower-section">
        <div ref="chartContainers" style="width: 100%; height: 100%;" />
      </div>
    </div>
  </div>
  <!-- </dv-border-box-8> -->
</template>

<script>
import echarts from 'echarts'

export default {
  name: 'BottomOne',
  mounted() {
    this.renderChart()
    window.addEventListener('resize', this.handleResize)
    window.addEventListener('resize', this.handleResizes)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
    window.removeEventListener('resize', this.handleResizes)
  },
  methods: {
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      const chartContainers = this.$refs.chartContainers
      this.chart = echarts.init(chartContainer)
      this.charts = echarts.init(chartContainers)
      // 柱状图
      const option = {
        textStyle: {
          color: '#fff'
        },
        title: {
          // text: '机载主机、蓄冰主机、水泵、水塔及占比',
          // top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#fff'
          }
        },
        grid: {
          top: '5px',
          left: '60px',
          right: '10px',
          bottom: '10px'
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            crossStyle: {
              color: '#999'
            }
          }

        },
        legend: {
          show: false
        },
        yAxis: {
          type: 'category',
          data: ['机载主机', '蓄冰主机', '水泵', '水塔'],
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            fontSize: 10,
            color: '#fff'
          }
        },
        xAxis: {
          show: false
        },
        series: [
          {
            type: 'bar',
            barWidth: '50%',
            itemStyle: {
              color: '#358FC1',
              barBorderRadius: [10, 10, 10, 10]
            },
            label: {
              show: true,
              position: 'inside', // Display label inside the bar
              formatter: '{c}', // Display the data value
              fontSize: 10,
              color: '#fff'
            },
            data: [{
              value: 2.0,
              itemStyle: {
                color: '#358FC1',
                normal: {
                  //   渐变色
                  color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
                    {
                      offset: 0,
                      color: '#358FC1'
                    },
                    {
                      offset: 1,
                      color: '#C8E0EE'
                    }
                  ], false)
                }
              }
            }, {
              value: 4.9,
              itemStyle: {
                color: '#13F8FD',
                normal: {
                  //   渐变色
                  color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
                    {
                      offset: 0,
                      color: '#13F8FD'
                    },
                    {
                      offset: 1,
                      color: '#D6FDFE'
                    }
                  ], false)
                }

              }
            }, {
              value: 7.0,
              itemStyle: {
                color: '#FD9D04',
                normal: {
                  //   渐变色
                  color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
                    {
                      offset: 0,
                      color: '#FD9D04'
                    },
                    {
                      offset: 1,
                      color: '#FFF8EC'
                    }
                  ], false)
                }
              }
            },
            {
              value: 3.0,
              itemStyle: {
                color: '#D8506A',
                normal: {
                  //   渐变色
                  color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
                    {
                      offset: 0,
                      color: '#D8506A'
                    },
                    {
                      offset: 1,
                      color: '#F6D8DE'
                    }
                  ], false)
                }
              }
            }
            ]
          }
        ]
      }

      // 饼图
      const options = {
        textStyle: {
          color: '#fff'
        },
        title: {
          // text: 'lt、末端、冷站能耗能耗同比',
          // top: '5px',
          // textStyle: {
          //     fontSize: 14,
          //     color: '#fff'
          // }
        },
        tooltip: {
          trigger: 'item',
          formatter: '{b}: {c} ({d}%)',
          textStyle: {
            fontSize: 6,
            color: '#fff'
          }
        },
        grid: {
          top: '10px',
          left: '60px',
          right: '10px',
          bottom: '10px'
        },
        series: [
          {
            name: '能耗占比',
            type: 'pie',
            radius: ['40%', '60%'],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: true,
                formatter: '{d}%',
                textStyle: {
                  fontSize: 8,
                  fontWeight: 'bold'
                }
              },
              emphasis: {
                show: true
              }
            },
            emphasis: {
              label: {
                show: true,
                fontSize: 10,
                fontWeight: 'bold'
              }
            },
            labelLine: {
              normal: {
                show: true
              },
              emphasis: {
                show: true
              }
            },
            data: [
              { value: 2.0, name: '机载主机', itemStyle: { color: '#358FC1' }},
              { value: 4.9, name: '蓄冰主机', itemStyle: { color: '#13F8FD' }},
              { value: 7.0, name: '水泵', itemStyle: { color: '#FD9D04' }},
              { value: 3.0, name: '水塔', itemStyle: { color: '#D8506A' }}
            ]
          }
        ]
      }

      this.chart.setOption(option)
      this.charts.setOption(options)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    },
    handleResizes() {
      if (this.charts) {
        this.charts.resize()
      }
    }
  }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;

    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;

        }

        .right {
            display: flex;
            font-size: .2133rem;

            .day,
            .mouth,
            .year {
                background-color: #024596;
                border-radius: .1333rem;
                margin: 2px;
                padding: 2px;
                box-sizing: border-box;
                cursor: pointer;

                span {
                    color: #fff;

                }
            }

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;

        .upper-section {
            flex: 1;
            width: 100%;
            height: 100%;

        }

        .lower-section {
            flex: 1;
            width: 100%;
            height: 100%;

        }
    }

}
</style>

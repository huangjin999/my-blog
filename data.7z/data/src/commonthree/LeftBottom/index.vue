<template>
  <div class="ech-box-three">
    <div class="top">
      <div class="left">
        逐时策略
      </div>
      <div class="right" />
    </div>
    <div class="bottom">
      <el-table :data="tableData" max-height="150" style="width: 35vw" :row-class-name="tableRowClassName" :header-cell-style="{ background: '#002C69', color: '#fff' }">
        <el-table-column prop="date" label="时间" width="100" height="20" />
        <el-table-column prop="one" label="B3-X-L-1" />
        <el-table-column prop="two" label="B3-X-L-2" />
        <el-table-column prop="three" label="B3-X-L-3" />
        <el-table-column prop="four" label="B3-X-L-4" />
        <el-table-column prop="five" label="B3-X-L-5" />
        <el-table-column prop="six" label="B3-X-L-6" />
      </el-table>

    </div>
  </div>
</template>

<script>
export default {
  name: 'LeftBottom',
  data() {
    return {
      tableData: [
        {
          date: '2016-05-03',
          one: 'icon01',
          two: 'icon02',
          three: 'icon03',
          four: 'icon04',
          five: 'icon05',
          six: 'icon06'

        },
        {
          date: '2016-05-04',
          one: 'icon01',
          two: 'icon02',
          three: 'icon03',
          four: 'icon04',
          five: 'icon05',
          six: 'icon06'

        },
        {
          date: '2016-05-05',
          one: 'icon01',
          two: 'icon02',
          three: 'icon03',
          four: 'icon04',
          five: 'icon05',
          six: 'icon06'

        },
        {
          date: '2016-05-06',
          one: 'icon01',
          two: 'icon02',
          three: 'icon03',
          four: 'icon04',
          five: 'icon05',
          six: 'icon06'

        },
        {
          date: '2016-05-06',
          one: 'icon01',
          two: 'icon02',
          three: 'icon03',
          four: 'icon04',
          five: 'icon05',
          six: 'icon06'

        },
        {
          date: '2016-05-06',
          one: 'icon01',
          two: 'icon02',
          three: 'icon03',
          four: 'icon04',
          five: 'icon05',
          six: 'icon06'

        },
        {
          date: '2016-05-06',
          one: 'icon01',
          two: 'icon02',
          three: 'icon03',
          four: 'icon04',
          five: 'icon05',
          six: 'icon06'

        },
        {
          date: '2016-05-06',
          one: 'icon01',
          two: 'icon02',
          three: 'icon03',
          four: 'icon04',
          five: 'icon05',
          six: 'icon06'

        },
        {
          date: '2016-05-06',
          one: 'icon01',
          two: 'icon02',
          three: 'icon03',
          four: 'icon04',
          five: 'icon05',
          six: 'icon06'

        },
        {
          date: '2016-05-06',
          one: 'icon01',
          two: 'icon02',
          three: 'icon03',
          four: 'icon04',
          five: 'icon05',
          six: 'icon06'

        },
        {
          date: '2016-05-06',
          one: 'icon01',
          two: 'icon02',
          three: 'icon03',
          four: 'icon04',
          five: 'icon05',
          six: 'icon06'

        }

      ]
    }
  },
  mounted() {
    // 初始化 DataV 轮播表
  },
  methods: {
  // 表格颜色
    tableRowClassName({ row, rowIndex }) {
      if ((rowIndex + 1) % 2 === 0) {
        return 'warning-row'
      } else {
        return 'warning-row'
      }
    }
  }
}
</script>

<style  lang="scss">

// elementui 表格公共样式
@import '@/assets/scss/elementui.scss';

.ech-box-three {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;

    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;

        }

        .right {
            display: flex;
            font-size: .2133rem;

            .day,
            .mouth,
            .year {
                background-color: #024596;
                border-radius: .1333rem;
                margin: 2px;
                padding: 2px;
                box-sizing: border-box;
                cursor: pointer;

                span {
                    color: #fff;

                }
            }

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
    }

}
</style>

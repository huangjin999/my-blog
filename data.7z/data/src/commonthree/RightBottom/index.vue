<template>
  <div class="ech-box">
    <div class="top">
      <div class="left">
        冷冻水温度、COP、PUE曲线
      </div>
      <div class="right">
        <!-- <div class="day" @click="handle"><span>日</span></div>
                <div class="mouth"><span>月</span></div>
                <div class="year"><span>年</span></div> -->
      </div>
    </div>
    <div class="bottom">
      <div ref="chartContainer" style="width: 100%; height: 100%;" />
    </div>

  </div>
</template>

<script>
import echarts from 'echarts'

export default {
  name: 'RightTop',
  mounted() {
    this.renderChart()
    window.addEventListener('resize', this.handleResize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      this.chart = echarts.init(chartContainer)
      const colors = ['#5470C6', '#91CC75', '#F79C04']
      const option = {
        color: colors,
        textStyle: {
          color: '#fff'
        },
        title: {
          // text: '冷冻水温度、COP、PUE曲线',
          // top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#fff'

          }
        },

        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross'
          }
        },
        grid: {
          top: '40px',
          bottom: '13%',
          right: '10%'
        },
        // toolbox: {
        //     feature: {
        //         dataView: { show: true, readOnly: false },
        //         restore: { show: true },
        //         saveAsImage: { show: true }
        //     }
        // },
        legend: {
          // top: '20px',
          data: ['温度', 'PUE', 'COP'],

          textStyle: {
            fontSize: 8,
            color: '#AEC8DF'

          },
          itemWidth: 6, // 设置图例项宽度
          itemHeight: 6// 设置图例项高度
        },
        xAxis: [
          {
            type: 'category',
            axisTick: {
              alignWithLabel: true
            },
            // prettier-ignore
            data: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'],
            axisLabel: {
              fontSize: 10

            }
          }
        ],
        yAxis: [
          {
            type: 'value',
            name: '温度°C',
            nameTextStyle: {
              fontSize: 8
            },
            position: 'left',
            alignTicks: true,
            axisLine: {
              show: true,
              lineStyle: {
                color: colors[0]
              }
            },
            axisLabel: {
              formatter: '{value}',
              fontSize: 10
            }
          },
          {
            type: 'value',
            name: 'PUE,COP',
            nameTextStyle: {
              fontSize: 8
            },
            position: 'right',
            alignTicks: true,
            axisLine: {
              show: true,
              lineStyle: {
                color: colors[1]
              }
            },
            axisLabel: {
              formatter: '{value}',
              fontSize: 10
            }
          }

        ],
        series: [
          {
            name: '温度',
            type: 'bar',
            yAxisIndex: 0,
            data: [
              2.0, 4.9, 2.0, 4.9, 7.0, 23.2, 33, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4
            ],
            itemStyle: {
              barBorderRadius: [5, 5, 0, 0]
            }
          },
          {
            name: 'PUE',
            type: 'line',
            yAxisIndex: 1,
            data: [4.5, 2.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3, 43, 6.3, 10.2, 20.3, 23.4, 23.0, 2.0, 2.2, 3.3, 16.5, 99]
          },
          {
            name: 'COP',
            type: 'line',
            yAxisIndex: 1,
            data: [2.0, 2.2, 3.3, 4.5, 6.3, 10.2, 20.3, 23.4, 2.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3, 22, 23.0, 16, 99]

          }
        ]
      }

      this.chart.setOption(option)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    }
  }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;
    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;

        }

        .right {
            display: flex;
            font-size: .2133rem;

            .day,
            .mouth,
            .year {
                background-color: #024596;
                border-radius: .1333rem;
                margin: 2px;
                padding: 2px;
                box-sizing: border-box;
                cursor: pointer;

                span {
                    color: #fff;

                }
            }

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
    }

}

</style>

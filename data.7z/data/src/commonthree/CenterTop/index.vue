<template>
  <!-- <dv-border-box-8> -->
  <div class="ech-box">
    <div class="ech-left">
      <div class="top textrig">2023-08-23</div>
      <div class="bottom">
        <div class="left">
          <div class="left-item">
            <div class="left-item-top textrig"><i class="el-icon-coin" /></div>
            <div class="left-item-center textccc">日温度</div>
            <div class="left-item-bottom textrig">19°C</div>
          </div>
          <div class="right-item">
            <div class="left-item-top textrig"><i class="el-icon-coin" /></div>
            <div class="left-item-center textccc">夜温度</div>
            <div class="left-item-bottom textrig">19°C</div>
          </div>
        </div>
        <div class="right">
          <div class="top-item textrig">负荷预测热量</div>
          <div class="bottom-item">
            <span class="yellow">0</span> <span class="textccc"> GJ</span>
          </div>
        </div>
      </div>
    </div>
    <div class="ech-center">
      <div class="top textrig">2023-08-24</div>
      <div class="bottom">
        <div class="left">
          <div class="left-item">
            <div class="left-item-top textrig"><i class="el-icon-coin" /></div>
            <div class="left-item-center textccc">日温度</div>
            <div class="left-item-bottom textrig">19°C</div>
          </div>
          <div class="right-item">
            <div class="left-item-top textrig"><i class="el-icon-coin" /></div>
            <div class="left-item-center textccc">夜温度</div>
            <div class="left-item-bottom textrig">19°C</div>
          </div>
        </div>
        <div class="right">
          <div class="top-item textrig">负荷预测热量</div>
          <div class="bottom-item">
            <span class="yellow">0</span> <span class="textccc"> GJ</span>
          </div>
        </div>
      </div>
    </div>
    <div class="ech-right">
      <div class="top textrig">2023-08-25</div>
      <div class="bottom">
        <div class="left">
          <div class="left-item">
            <div class="left-item-top textrig"><i class="el-icon-coin" /></div>
            <div class="left-item-center textccc">日温度</div>
            <div class="left-item-bottom textrig">19°C</div>
          </div>
          <div class="right-item">
            <div class="left-item-top textrig"><i class="el-icon-coin" /></div>
            <div class="left-item-center textccc">夜温度</div>
            <div class="left-item-bottom textrig">19°C</div>
          </div>
        </div>
        <div class="right">
          <div class="top-item textrig">负荷预测热量</div>
          <div class="bottom-item">
            <span class="yellow">0</span> <span class="textccc"> GJ</span>
          </div>
        </div>
      </div>

    </div>
  </div>

  <!-- </dv-border-box-8> -->
</template>

<script>
export default {
  name: 'CenterTop',
  data() {
    return {

    }
  },
  created() {

  },
  mounted() {

  },
  methods: {

  }
}
</script>
<style scoped lang='scss'>
.yellow {
  color: #D99B3F;
  font-size: 16px;
  font-weight: bold;
  margin-right: 1px;
}

.textccc {
  color: #AEC8DF;
}
.textrig {
  color: #dde8f2;
  // font-size: .5rem;
}

// 中间上面
.ech-box {
  width: 100%;
  height: 100%;
  // border: 1px solid #024596;
  display: flex;
  flex-direction: row;

  .ech-left,
  .ech-center {
    border-right: 1px solid #333;
  }

  .ech-left,
  .ech-center,
  .ech-right {
    flex: 1;
    display: flex;
    flex-direction: column;
    font-size: 8px;
    margin-top: 5px;

    .top {
      flex: 0.8;
      // background-color: #a5b6d0;
      text-align: center;
    }

    .bottom {
      flex: 2;
      display: flex;
      padding-right: 5px;

      .left {
        flex: 2;
        // background-color: #beaa4f;
        display: flex;
        flex-direction: row;

        .left-item,
        .right-item {
          flex: 1;
          display: flex;
          flex-direction: column;

          .left-item-top {
            flex: 1;
            // background-color: #a5b6d0;
            text-align: center;
          }

          .left-item-center {
            flex: 1;
            // background-color: #a5b6d0;
            text-align: center;
          }

          .left-item-bottom {
            flex: 1;
            // background-color: #a5b6d0;
            text-align: center;
          }
        }
      }

      .right {
        flex: 1;
        // background-color: #044516;
        display: flex;
        flex-direction: column;

        .top-item {
          flex: 1;
          // background-color: #a5b6d0;
          text-align: center;
          font-size: 8px;
        }

        .bottom-item {
          flex: 1;
          // background-color: #a5b6d0;
          text-align: center;
          display: flex;
          flex-direction: row;
          justify-content: center;
          align-items: center;
        }
      }
    }
  }

}</style>

<template>
  <div class="ech-box-three">
    <div class="top">
      <div class="left">
        策略库
      </div>
      <div class="right" />
    </div>
    <div class="bottom">
      <el-table :data="tableData" max-height="150" border style="width: 35vw" :row-class-name="tableRowClassName" :header-cell-style="{ background: '#002C69', color: '#fff' }">
        <el-table-column prop="date" label="时间" width="100" height="20" />
        <el-table-column prop="one" label="策略内容" width="300" />
        <el-table-column prop="two" width="300" />
      </el-table>

    </div>
  </div>
</template>

<script>
export default {
  name: 'LeftBottom',
  data() {
    return {
      tableData: [
        {
          date: '2016-05-03',
          one: '主机: 主机B3-X-L-1: 开，出水温度:5C ',
          two: '主机: 主机B3-X-L-1: 开，出水温度:5C'
        },
        {
          date: '2016-05-03',
          one: '主机: 主机B3-X-L-1: 开，出水温度:5C'
        },
        {
          date: '2016-05-03',
          one: '主机: 主机B3-X-L-1: 开，出水温度:5C'
        },
        {
          date: '2016-05-03',
          one: '主机: 主机B3-X-L-1: 开，出水温度:5C'
        },
        {
          date: '2016-05-03',
          one: '主机: 主机B3-X-L-1: 开，出水温度:5C'
        },
        {
          date: '2016-05-03',
          one: '主机: 主机B3-X-L-1: 开，出水温度:5C'
        },
        {
          date: '2016-05-03',
          one: '主机: 主机B3-X-L-1: 开，出水温度:5C'
        },
        {
          date: '2016-05-03',
          one: '主机: 主机B3-X-L-1: 开，出水温度:5C'
        }

      ]
    }
  },
  mounted() {
    // 初始化 DataV 轮播表
  },
  methods: {
  // 表格颜色
    tableRowClassName({ row, rowIndex }) {
      if ((rowIndex + 1) % 2 === 0) {
        return 'warning-row'
      } else {
        return 'warning-row'
      }
    }
  }
}
</script>

<style  lang="scss">

// elementui 表格公共样式
@import '@/assets/scss/elementui.scss';

.ech-box-three {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;

    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;

        }

        .right {
            display: flex;
            font-size: .2133rem;

            .day,
            .mouth,
            .year {
                background-color: #024596;
                border-radius: .1333rem;
                margin: 2px;
                padding: 2px;
                box-sizing: border-box;
                cursor: pointer;

                span {
                    color: #fff;

                }
            }

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
    }

}
</style>

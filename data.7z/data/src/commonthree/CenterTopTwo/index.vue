<template>
  <!-- <dv-border-box-8> -->
  <div class="ech-box">
    <img src="../../assets/images/log.png" alt="">
    
  </div>
  <!-- </dv-border-box-8> -->
</template>

<script>
export default {
  name: 'CenterTopTwo',
  data() {
    return {

    }
  },
  mounted() {
    // 初始化 DataV 轮播表
  }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    border: 1px solid #024596;
    img{
      width: 100%;
      height: 100%;
    }

}
</style>

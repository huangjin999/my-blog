<template>
  <div class="ech-box">
    <div class="top">
      <div class="left">
        熔值与空调负荷散点图
      </div>
      <div class="right" />
    </div>
    <div class="bottom">
      <div ref="chartContainer" style="width: 100%; height: 100%;" />
    </div>

  </div>
</template>

<script>
import echarts from 'echarts'

export default {
  name: 'LeftCenter',
  mounted() {
    this.renderChart()
    window.addEventListener('resize', this.handleResize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      this.chart = echarts.init(chartContainer)

      const option = {
        textStyle: {
          color: '#fff'
        },

        title: {
          // text: '熔值与空调负荷散点图',
          // top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#fff'
          }
        },
        grid: {
          top: '40px',
          bottom: '13%',
          // right: '15%',
          left: '13%'
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          // top: '20px',
          data: ['熔值', '负荷'],
          textStyle: {
            fontSize: 8,
            color: '#AEC8DF'
          },
          itemWidth: 6,
          itemHeight: 6
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: ['50', '60', '70', '80', '90', '100', '120', '130'],
          axisLabel: {
            interval: 0,
            textStyle: {
              fontSize: 10
            }
          },
          name: '负荷', // 添加 x 轴名称
          nameTextStyle: {
            fontSize: 8
          },
          nameLocation: 'end', // 将 x 轴名称放在轴末尾
          nameGap: 5 // 调整 x 轴名称与轴之间的距离
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: true,
            lineStyle: {
              type: 'dashed'
            }
          },
          axisLabel: {
            fontSize: 10
          },
          name: '熔值', // 添加 y 轴名称
          nameTextStyle: {
            fontSize: 8
          },
          nameLocation: 'end', // 将 y 轴名称放在轴中间
          nameGap: 10 // 调整 y 轴名称与轴之间的距离
        },
        series: [
          {
            name: '熔值',
            type: 'scatter',
            stack: 'stacked',
            data: [
              '23', '34', '45', '56', '67', '78', '89', '90'
            ],
            symbolSize: 8,
            itemStyle: {
              color: '#332FC1',
              fontSize: 10
            }
          },
          {
            name: '负荷',
            type: 'scatter',
            stack: 'stacked',
            data: [
              '32', '43', '54', '65', '76', '87', '98', '99'
            ],
            symbolSize: 8,
            itemStyle: {
              color: '#358FC1',
              fontSize: 10
            }
          }
        ]
      }

      this.chart.setOption(option)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    }
  }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;
    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;

        }

        .right {
            display: flex;
            font-size: .2133rem;

            .day,
            .mouth,
            .year {
                background-color: #024596;
                border-radius: .1333rem;
                margin: 2px;
                padding: 2px;
                box-sizing: border-box;
                cursor: pointer;

                span {
                    color: #fff;

                }
            }

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
    }

}

</style>

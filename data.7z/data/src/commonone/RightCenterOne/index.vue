<template>
  <!-- <dv-border-box-8> -->

  <div class="ech-box">
    <div class="top">
      <div class="left">
        负荷、PUE、COP、CLF曲线
      </div>
      <div class="right">
        <div class="day" @click="handle"><span>日</span></div>
        <div class="mouth"><span>月</span></div>
        <div class="year"><span>年</span></div>
      </div>
    </div>
    <div class="bottom">
      <div ref="chartContainer" style="width: 100%; height: 100%;" />
    </div>

  </div>
  <!-- </dv-border-box-8> -->
</template>

<script>
import echarts from 'echarts'

export default {
  name: 'RightCenterOne',
  mounted() {
    this.renderChart()
    window.addEventListener('resize', this.handleResize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    handle() {
      console.log(111)
    },
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      this.chart = echarts.init(chartContainer)

      const colors = ['#5470C6', '#069ADE', '#F79F00', '#874EA7']
      const option = {
        color: colors,
        textStyle: {
          color: '#fff'
        },
        title: {
          // text: '负荷、PUE、COP、CLF曲线',
          // top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#fff'

          }
        },

        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross'
          }
        },
        grid: {
          top: '40px',
          bottom: '13%',
          left: '13%',
          right: '15%'
        },
        // 数据切换显示
        // toolbox: {
        //     feature: {
        //         dataView: { show: true, readOnly: false },
        //         restore: { show: true },
        //         saveAsImage: { show: true }
        //     }
        // },
        legend: {
          // top: '5px',
          data: ['负荷', 'PUE', 'COP', 'CLF'],

          textStyle: {
            fontSize: 8,
            color: '#AEC8DF'

          },
          itemWidth: 8, // 设置图例项宽度
          itemHeight: 8 // 设置图例项高度
        },
        xAxis: [
          {
            type: 'category',
            axisTick: {
              alignWithLabel: true
            },
            // prettier-ignore
            data: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'],
            axisLabel: {
              // interval: 0, //x轴所有数据都显示
              textStyle: {
                fontSize: 10
              }
            }
          }
        ],
        yAxis: [
          {
            type: 'value',
            name: '负荷',
            position: 'left',
            alignTicks: true,
            axisLine: {
              show: true,
              lineStyle: {
                color: colors[0]
              }
            },
            nameTextStyle: {
              fontSize: 8
            },
            axisLabel: {
              formatter: '{value}',
              fontSize: 10
            }
          },
          {
            type: 'value',
            name: 'PUE,COP,CLF',
            position: 'right',
            alignTicks: true,
            nameTextStyle: {
              fontSize: 8
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: colors[1]
              }
            },
            axisLabel: {
              formatter: '{value}',
              fontSize: 10
            }
          }

        ],
        series: [
          {
            name: '负荷',
            type: 'bar',
            yAxisIndex: 1,
            data: [4.5, 2.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3, 43, 6.3, 10.2, 20.3, 23.4, 23.0, 2.0, 2.2, 3.3, 16.5, 99]

          },
          {
            name: 'PUE',
            type: 'line',
            yAxisIndex: 0,
            data: [4.5, 2.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 23.4, 23.0, 2.0, 2.2, 3.3, 16.5, 99, 32.6, 20.0, 6.4, 3.3, 43, 6.3, 10.2, 20.3]

          },
          {
            name: 'COP',
            type: 'line',
            yAxisIndex: 0,
            data: [25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3, 43, 6.3, 10.2, 20.3, 23.4, 4.5, 2.0, 4.9, 7.0, 23.2, 23.0, 2.0, 2.2, 3.3, 16.5, 99]

          },
          {
            name: 'CLF',
            type: 'line',
            yAxisIndex: 0,
            data: [32.6, 20.0, 6.4, 3.3, 43, 6.3, 10.2, 20.3, 23.4, 23.0, 2.0, 2.2, 3.3, 4.5, 2.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 16.5, 99]

          }
        ]
      }

      this.chart.setOption(option)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    }
  }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;
    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;

        }

        .right {
            display: flex;
            font-size: .2133rem;

            .day,
            .mouth,
            .year {
                background-color: #024596;
                border-radius: .1333rem;
                margin: 2px;
                padding: 2px;
                box-sizing: border-box;
                cursor: pointer;

                span {
                    color: #fff;

                }
            }

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
    }

}

</style>

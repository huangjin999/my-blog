<template>
  <div class="ech-box">
    <!-- <dv-border-box-8> -->
      <img src="../../assets/images/log.png" alt="">
    <!-- </dv-border-box-8> -->
  </div>
</template>

<script>
export default {
  name: 'CenterBottom',
  data() {
    return {

    }
  },
  created() {

  },
  mounted() {

  },
  methods: {

  }
}
</script>
<style scoped lang='scss'>
.ech-box {
  width: 100%;
  height: 100%;
  border: 1px solid #024596;

  img{
    width: 100%;
    height: 100%;
  }
  // background: url(../../assets/images/log.png) no-repeat center center/cover;

}
</style>

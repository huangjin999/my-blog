<!-- <template>
    <dv-border-box-8>
        <div class="ech-box">
            <div ref="chartContainer" style="width: 100%; height: 100%; "></div>
        </div>
    </dv-border-box-8>
</template>

<script>
import echarts from 'echarts';
import { echartDataTwo } from "@/api/echart" //引入echart数据接口

export default {
    name: "LeftCenter",
    data(){
        return{
            echartList:{

            }
        }
    },
    mounted() {
        this.getChartData();

        window.addEventListener("resize", this.handleResize);
    },
    beforeDestroy() {
        window.removeEventListener("resize", this.handleResize);
    },
    methods: {
        async getChartData() { //接口数据
            try {
                const response = await echartDataTwo();
                // console.log(response);
                this.echartList = response.data;
                this.renderChart(); //获取到数据再渲染图表
                console.log(this.echartList);
            } catch (error) {
                console.error(error);
            }
        },
        renderChart() {
            const chartContainer = this.$refs.chartContainer;
            this.chart = echarts.init(chartContainer);

            const option = {
                textStyle: {
                    color: '#fff'
                },

                title: {
                    text: '负荷预测与实际负荷曲线',
                    top: '5px',
                    textStyle: {
                        fontSize: '8px',
                        color: '#fff'

                    }
                },
                grid: {
                    top: '80px',
                },
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    top: '30px',
                    data: ['负荷预测', '实际负荷',],

                    textStyle: {
                        fontSize: 10,
                        color:"#fff"
                    },
                    itemWidth: 10, // 设置图例项宽度
                    itemHeight: 10 // 设置图例项高度
                },
                xAxis: {
                    type: 'category',
                    // boundaryGap: true,
                    boundaryGap: false, //
                    data:this.echartList.xAxisData, //接口数据
                    // data: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'],
                    axisLabel: {
                        interval: 0,
                        // rotate: 45,
                        textStyle: {
                            fontSize: 10
                        }
                    }
                },
                yAxis: {
                    type: 'value',
                    splitLine: {
                        show: true,
                        lineStyle: {
                            type: 'dashed' // S
                        }
                    }
                },
                series: [
                    {
                        name: '负荷预测',
                        type: 'line',
                        stack: 'stacked',
                        data:this.echartList.one, //接口数据
                        // data: [110, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 132, 101, 134],
                        itemStyle: {
                            color: '#358FC1',//
                            fontSize: 10

                        }
                    },
                    {
                        name: '实际负荷',
                        type: 'line',
                        stack: 'stacked',
                        data:this.echartList.two,   //接口数据
                        // data: [132, 220, 182, 191, 234, 290, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 132, 101, 134, 134, 90,],
                        itemStyle: {
                            color: '#C39F49',//
                            fontSize: 10
                        }
                    },

                ]
            };

            this.chart.setOption(option);
        },
        handleResize() {
            if (this.chart) {
                this.chart.resize();
            }
        }
    }
};
</script>

<style scoped>
.ech-box {
    /* width: calc(100% - 20px); */
    /* height: calc(100vh / 3 - 40px); */
    width: 100%;
    height: 100%;
    display: flex;
    /* margin: 0.1433rem; */
    flex-direction: column;
    box-sizing: border-box;

}
</style> -->

<template>
  <!-- <dv-border-box-8> -->
  <div class="ech-box">
    <div class="right-top">
      建议策略
      <span class="right-top-icon">{{ currentTime }}</span>
    </div>
    <!-- 上 -->
    <div class="right-center">
      <div class="item-top title-color">
        主机
      </div>
      <div class="item-bottom">
        <div class="one textccc">主机B3-X-L-1:开，出水温度:5C</div>
        <div class="one textccc">主机B3-X-L-2: 开，出水温度:5C</div>
        <div class="one textccc">主机B3-X-L-3:关</div>
      </div>
    </div>
    <!-- 下 -->
    <div class="right-bottom">
      <div class="item-top title-color2">
        冷冻泵
      </div>
      <div class="item-bottom">
        <div class="one textccc">冷冻泵1:开，频率:70Hz</div>
        <div class="one textccc">冷冻泵2: 开，频率: 70Hz</div>
        <div class="one textccc">冷冻泵3:关</div>
      </div>
    </div>
  </div>
  <!-- </dv-border-box-8> -->
</template>

<script>
export default {
  name: 'RightCenter',
  data() {
    return {
      currentTime: new Date().toLocaleString()
    }
  },

  created() {

  },
  mounted() {
    // 每秒更新一次时间
    this.timer = setInterval(() => {
      this.currentTime = new Date().toLocaleString()
    }, 1000)
  },
  // 卸载的时候清除
  beforeDestroy() {
    clearInterval(this.timer)
  }
}
</script>
<style scoped lang='scss'>
.textccc{
    color: #c1d4e5;
    font-size: .36rem;
}
.title-color{
    color: #379661;
}
.title-color2{
    color: #115AB1;
}
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    border: 1px solid #024596;

    .right-top{
        flex:1;
        display: flex;
        height: 100%;
        width: 100%;
        justify-content: space-between;
        margin-top: 10px;
        margin-left: 5px;
        font-size: 0.21rem;
        .right-top-icon{
            margin-right: 10px;
        }

    }
    .right-center{
        flex:5;
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;
        margin-left: 10px;

        .item-top{
            flex:1;
            height: 100%;
            width: 100%;
            display: flex;
            font-size: 0.32rem;
            font-weight: bold;
            margin: 5px 0;
            position: relative;
            &::before {
             content: "";
             position: absolute;
             bottom: 0;
             left: -5px;
             width: 2px;
             height: 100%;
             background-color: #379661;
            }

        }
        .item-bottom{
            flex:5;
            height: 100%;
            width: 100%;
            display: flex;
            flex-direction: column;

            .one{
                flex:1;
                height: 100%;
                width: 100%;
                display: flex;
                margin-left:10px;

            }
        }

    }
     .right-bottom{
        flex:5;
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;
        margin-left: 10px;

        .item-top{
            flex:1;
            height: 100%;
            width: 100%;
            display: flex;
            font-size: .32rem;
            font-weight: bold;
            margin: 5px 0;
            position: relative;
            &::before {
             content: "";
             position: absolute;
             bottom: 0;
             left: -5px;
             width: 2px;
             height: 100%;
             background-color: #115AB1;
            }

        }
        .item-bottom{
            flex:5;
            height: 100%;
            width: 100%;
            display: flex;
            flex-direction: column;

            .one{
                flex:1;
                height: 100%;
                width: 100%;
                display: flex;
                margin-left:10px;
            }
        }

    }
}

</style>

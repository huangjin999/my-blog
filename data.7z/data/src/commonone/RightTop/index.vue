<template>
  <!-- <dv-border-box-8> -->
  <div class="ech-box">
    <div class="title txtccc" v-if="weatherData && nowData && airData && lunarDate && hourData">{{
      weatherData.daily[0].fxDate }}&nbsp; {{ getWeekday(weatherData.daily[0].fxDate) }}
      &nbsp;
      农历{{ lunarDate.dateStr
      }}</div>
    <div class="top" v-if="weatherData && nowData && airData && lunarDate && hourData">
      <div class="one-item">
        <div class="top"> <i :class=activeOne></i></div>
        <div class="center">
          <div class="left">{{ nowData.now.temp }}</div>
          <div class="center">
            <div class="top textccc">°C</div>
            <div class="bottom textccc">{{ nowData.now.text }}</div>
          </div>
          <div class="right textccc">实时</div>
        </div>
        <div class="botom">
          <!-- 温度 -->
          <div class="one textccc">{{ weatherData.daily[0].tempMin }}-{{ weatherData.daily[0].tempMax }}°C</div>
          <!-- 天气 -->
          <div class="two textccc">{{ weatherData.daily[0].textDay }}</div>
          <!-- 风 -->
          <div class="three textccc">{{ weatherData.daily[0].windDirDay }} {{ weatherData.daily[0].windScaleDay }}级</div>
          <div class="four "><span class="bgc"> {{ airData.daily[0].aqi }} &nbsp;{{ airData.daily[0].category
          }}</span></div>
        </div>
      </div>
      <div class="two-item">
        <div class="top">
          <div class="top-item" v-if="weatherData">{{ getWeekday(weatherData.daily[1].fxDate) }}</div>
          <div class="bottom-item textccc">{{ weatherData.daily[1].fxDate }}</div>
        </div>
        <div class="center"><i :class=activeTwo></i></div>
        <div class="bottom">
          <div class="one textccc">{{ weatherData.daily[1].tempMin }}-{{ weatherData.daily[1].tempMax }}°C</div>
          <div class="two textccc">{{ weatherData.daily[1].textDay }}</div>
          <div class="three textccc">{{ weatherData.daily[1].windDirDay }} {{ weatherData.daily[1].windScaleDay }}级</div>
          <div class="four "><span class="bgc"> {{ airData.daily[1].aqi }} &nbsp;{{ airData.daily[1].category
          }}</span></div>
        </div>
      </div>
      <div class="three-item">
        <div class="top">
          <div class="top-item" v-if="weatherData">{{ getWeekday(weatherData.daily[2].fxDate) }}</div>
          <div class="bottom-item textccc">{{ weatherData.daily[2].fxDate }}</div>
        </div>
        <div class="center"><i :class=activeThree></i></div>
        <div class="bottom">
          <!-- 温度 -->
          <div class="one textccc">{{ weatherData.daily[2].tempMin }}-{{ weatherData.daily[0].tempMax }}°C</div>
          <!-- 天气 -->
          <div class="two textccc">{{ weatherData.daily[2].textDay }}</div>
          <!-- 风 -->
          <div class="three textccc">{{ weatherData.daily[2].windDirDay }} {{ weatherData.daily[0].windScaleDay }}级</div>
          <div class="four "><span class="bgc"> {{ airData.daily[2].aqi }} &nbsp;{{ airData.daily[2].category
          }}</span></div>
        </div>
      </div>
      <div class="four-item">
        <div class="top">
          <div class="top-item" v-if="weatherData">{{ getWeekday(weatherData.daily[3].fxDate) }}</div>
          <div class="bottom-item textccc">{{ weatherData.daily[3].fxDate }}</div>
        </div>
        <div class="center"><i :class=activeFour></i></div>
        <div class="bottom">
          <!-- 温度 -->
          <div class="one textccc">{{ weatherData.daily[3].tempMin }}-{{ weatherData.daily[0].tempMax }}°C</div>
          <!-- 天气 -->
          <div class="two textccc">{{ weatherData.daily[3].textDay }}</div>
          <!-- 风 -->
          <div class="three textccc">{{ weatherData.daily[3].windDirDay }} {{ weatherData.daily[0].windScaleDay }}级</div>
          <div class="four "><span class="bgc"> {{ airData.daily[3].aqi }} &nbsp;{{ airData.daily[3].category
          }}</span></div>
        </div>
      </div>
      <div class="five-item">
        <div class="top">
          <div class="top-item" v-if="weatherData">{{ getWeekday(weatherData.daily[4].fxDate) }}</div>
          <div class="bottom-item textccc">{{ weatherData.daily[4].fxDate }}</div>
        </div>
        <div class="center"><i :class=activeFive></i></div>
        <div class="bottom">
          <!-- 温度 -->
          <div class="one textccc">{{ weatherData.daily[4].tempMin }}-{{ weatherData.daily[0].tempMax }}°C</div>
          <!-- 天气 -->
          <div class="two textccc">{{ weatherData.daily[4].textDay }}</div>
          <!-- 风 -->
          <div class="three textccc">{{ weatherData.daily[4].windDirDay }} {{ weatherData.daily[0].windScaleDay }}级</div>
          <div class="four "><span class="bgc"> {{ airData.daily[4].aqi }} &nbsp;{{ airData.daily[4].category
          }}</span></div>
        </div>
      </div>
    </div>
    <div class="bottom">
      <div class="chart-container">
        <div ref="chartContainer" style="width: 100%; height: 50%; padding-left: 5px;" />
      </div>
    </div>

  </div>
  <!-- </dv-border-box-8> -->
</template>
<script>
import axios from 'axios';
import echarts from 'echarts'

// 引入农历插件
import { getLunar } from 'chinese-lunar-calendar'


export default {
  name: 'RightTop',
  data() {
    return {
      // 未来七天
      weatherData: null,
      // 天气指数
      airData: null,
      // 实时天气
      nowData: null,
      // 未来24小时
      hourData: null,
      // 天气的key
      apiKey: '4f0f9d6cc3894b41914feeb996c34545',
      city: '101020100', //城市,上海
      // 天气图表相关的数据
      iconOne: null,
      activeOne: null,
      iconTwo: null,
      activeTwo: null,
      iconThree: null,
      activeThree: null,
      iconFour: null,
      activeFour: null,
      iconFive: null,
      activeFive: null,

      // 空气指数相关的数据
      airOne: null,
      airThree: null,
      airTwo: null,
      airFour: null,
      airFive: null,
      // 农历相关
      lunarDate: null,
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      date: new Date().getDate()


    }
  },
  created() {
    this.getWeatherData();
    this.getAirData();
    this.getNowData();
    // this.getHourData();
  },
  mounted() {
    // 获取农历
    this.lunarDate = getLunar(this.year, this.month, this.date);
    // console.log(this.lunarDate);
    this.getHourData();


    window.addEventListener('resize', this.handleResize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    // 获取农历函数
    getLunarDate(dateString) {
      const date = new Date(dateString);
      const lunarDate = LunarCalendar.solarToLunar(date.getFullYear(), date.getMonth() + 1, date.getDate());
      const lunarMonth = lunarDate.lMonth;
      const lunarDay = lunarDate.lDay;
      return `农历${lunarMonth}月${lunarDay}`;
    },

    // 未来七天
    getWeatherData() {

      const apiUrl = `https://devapi.qweather.com/v7/weather/7d?location=101020100&key=4f0f9d6cc3894b41914feeb996c34545`;

      axios.get(apiUrl)
        .then(response => {
          this.weatherData = response.data;
          // this.iconOne = this.weatherData.daily[0].iconDay;
          // this.activeOne = 'qi-' + this.iconOne;
          this.iconTwo = this.weatherData.daily[1].iconDay;
          this.activeTwo = 'qi-' + this.iconTwo;
          this.iconThree = this.weatherData.daily[2].iconDay;
          this.activeThree = 'qi-' + this.iconThree;
          this.iconFour = this.weatherData.daily[3].iconDay;
          this.activeFour = 'qi-' + this.iconFour;
          this.iconFive = this.weatherData.daily[4].iconDay;
          this.activeFive = 'qi-' + this.iconFive;

        })
        .catch(error => {
          console.error('Error fetching weather data:', error);
        });
    },
    // 空气指数
    getAirData() {

      const apiUrl = `https://devapi.qweather.com/v7/air/5d?type=1,2&location=101020100&key=4f0f9d6cc3894b41914feeb996c34545`;
      axios.get(apiUrl)
        .then(response => {
          this.airData = response.data;
          // console.log(this.airData);
        })
        .catch(error => {
          console.error(error);
        });
    },
    // 实时天气
    getNowData() {
      const apiUrl = `https://devapi.qweather.com/v7/weather/now?location=101020100&key=4f0f9d6cc3894b41914feeb996c34545`;
      axios.get(apiUrl)
        .then(response => {
          this.nowData = response.data;
          // console.log(this.nowData);
          this.iconOne = this.nowData.now.icon;
          this.activeOne = 'qi-' + this.iconOne;

        })
        .catch(error => {
          console.error(error);
        });

    },
    // 未来24小时
    getHourData() {
      const apiUrl = `https://devapi.qweather.com/v7/weather/24h?location=101020100&key=4f0f9d6cc3894b41914feeb996c34545`;
      axios.get(apiUrl)
        .then(response => {
          this.hourData = response.data;
          console.log(this.hourData);
          // 获取到数据再进行渲染图表
          this.renderChart()


        })
        .catch(error => {
          console.error(error);
        });

    },
    // 获取星期几的函数
    getWeekday(date) {
      const weekdays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
      const targetDate = new Date(date);
      const weekdayIndex = targetDate.getDay();
      return weekdays[weekdayIndex];
    },
    // echart图表
    renderChart() {
      const chartContainer = this.$refs.chartContainer;
      this.chart = echarts.init(chartContainer)
      // //  温度数组
      //  const temperatureData = this.hourData.hourly.map(item => item.temp);
      //  console.log(temperatureData);

      //  // x 轴刻度数组（未来 24 小时的时间数据）
      //  const timeData = this.hourData.hourly.map(item => {
      //     const time = new Date(item.fxTime);
      //     return time.getHours() + ':00'; // 只显示小时
      //   });


      // 获取未来6小时的温度和时间数据
      const temperatureData = this.hourData.hourly.slice(0, 6).map(item => item.temp);
      const timeData = this.hourData.hourly.slice(0, 6).map(item => {
        const time = new Date(item.fxTime);
        return time.getHours() + ':00';
      });



      const option = {
        textStyle: {
          color: '#fff'
        },

        title: {
          // text: '节能率曲线',
          // top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#fff'

          }
        },
        grid: {
          top: '8%',
          bottom: '18%',
          left: '13%',
          right: '5%'
        },
        tooltip: {
          trigger: 'axis'
        },
        // legend: {
        //   // top: '5px',
        //   // data: ['节能率'],
        //   textStyle: {
        //     fontSize: 8,
        //     color: '#AEC8DF'
        //   },
        //   itemWidth: 8, // 设置图例项宽度
        //   itemHeight: 8 // 设置图例项高度
        // },
        xAxis: {
          type: 'category',
          // boundaryGap: true,
          boundaryGap: false, //
          // data: ['现在', '', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'],
          data: timeData,
          axisLabel: {
            interval: 0,
            // rotate: 45,
            textStyle: {
              fontSize: 10
            }
          }
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: true,
            lineStyle: {
              type: 'dashed' // S
            }
          },
          axisLabel: {
            formatter: '{value}°C',
            textStyle: {
              fontSize: 10
            }
          },
          min: 0,
          max: 45,
          interval: 15
        },
        series: [
          {
            name: '温度',
            type: 'line',
            stack: 'stacked',
            // smooth: true, // 平滑曲线
            // data: [99, 110, 167, 122, 191, 234, 132, 101, 134, 101, 134, 90, 220],
            data: temperatureData,
            itemStyle: {
              color: '#358FC1', //
              fontSize: 10

            },
            // areaStyle: { // 添加阴影效果
            //   color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            //     { offset: 0, color: '#358FC1' }, // 渐变的起始颜色
            //     { offset: 1, color: 'rgba(53, 143, 193, 0.2)' } // 渐变的结束颜色，这里设置了透明度
            //   ])
            // }
          }

        ]
      }

      this.chart.setOption(option)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    }
  }
}
</script>

<style scoped lang="scss">
.textccc {
  color: #ccc;
  font-size: 12px;
  zoom: 0.6;
}

.txtccc {
  color: #ccc;
  font-size: 0.21rem;


}

.bgc {
  border-radius: 5px;
  background-color: #46BE5B;
  padding: 2px;
  font-size: 1px;
  zoom: 0.6;



}

.ech-box {

  width: 100%;
  height: 100%;
  // padding: 10px;
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  // background-color: #f15b5b;
  border: 1px solid #024596;

  .title {
    margin-left: 1%;
    padding: 5px;
  }

  .top {
    flex: 1;
    height: 100%;
    width: 100%;
    display: flex;
    justify-content: space-between;

    .top-item {
      color: #fff;
      font-size: 1px;


    }

    .one,
    .two,
    .three,
    .four {
      // border-right: 1px dashed #324B73;
    }

    .one-item {
      flex: 1.3;
      height: 100%;
      width: 100%;
      display: flex;
      flex-direction: column;

      position: relative;

      &::before {
        content: "";
        position: absolute;
        bottom: 0;
        right: 0;
        width: 1px;
        height: 100%;
        border-right: 1px dashed #324B73;

      }

      .top {
        flex: 0.5;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: center;
      }

      .center {
        flex: 0.5;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: space-between;

        .left {
          flex: 1;
          height: 100%;
          width: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
        }

        .center {
          flex: 0.5;
          height: 100%;
          width: 100%;
          display: flex;
          flex-direction: column;
          justify-content: space-between;

          .top {
            flex: 1;
            height: 100%;
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
          }

          .bottom {
            flex: 1;
            height: 100%;
            width: 100%;
            justify-content: center;
            align-items: center;
            display: flex;
          }
        }

        .right {
          flex: 1;
          height: 100%;
          width: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
        }
      }

      .botom {
        flex: 1;
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;

        .one,
        .two,
        .three,
        .four {
          flex: 1;
          height: 100%;
          width: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
          margin-bottom: 1px;
        }
      }
    }


    .two-item,
    .three-item,
    .four-item {
      flex: 1;
      height: 100%;
      width: 100%;
      display: flex;
      flex-direction: column;
      position: relative;

      &::before {
        content: "";
        position: absolute;
        bottom: 0;
        right: 0;
        width: 1px;
        height: 100%;
        border-right: 1px dashed #324B73;
      }

      .top {
        flex: 0.5;
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;

        .top-item {
          flex: 1;
          height: 100%;
          width: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
        }

        .bottom-item {
          flex: 1;
          height: 100%;
          width: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
        }
      }

      .center {
        flex: 0.5;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
      }

      .bottom {
        flex: 1;
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;

        .one,
        .two,
        .three {
          font-size: 1px;


        }

        .one,
        .two,
        .three,
        .four {
          flex: 1;
          height: 100%;
          width: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
          font-size: 1px;

          margin-bottom: 1px;
        }
      }
    }

    // .four-item   {
    //   flex: 1;
    //   height: 100%;
    //   width: 100%;
    //   display: flex;
    //   flex-direction: column;
    //   position: relative;
    //         &::before {
    //          content: "";
    //          position: absolute;
    //          bottom: 0;
    //          right: -5px;
    //          width: 1px;
    //          height: 100%;
    //          background-color: #379661;
    //         }

    //   .top {
    //     flex: 0.5;
    //     height: 100%;
    //     width: 100%;
    //     display: flex;
    //     flex-direction: column;

    //     .top-item {
    //       flex: 1;
    //       height: 100%;
    //       width: 100%;
    //       display: flex;
    //       justify-content: center;
    //       align-items: center;
    //     }

    //     .bottom-item {
    //       flex: 1;
    //       height: 100%;
    //       width: 100%;
    //       display: flex;
    //       justify-content: center;
    //       align-items: center;
    //     }
    //   }

    //   .center {
    //     flex: 0.5;
    //     height: 100%;
    //     width: 100%;
    //     display: flex;
    //     justify-content: center;
    //     align-items: center;
    //   }

    //   .bottom {
    //     flex: 1;
    //     height: 100%;
    //     width: 100%;
    //     display: flex;
    //     flex-direction: column;

    //     .one,
    //     .two,
    //     .three {
    //       font-size: 1px;


    //     }

    //     .one,
    //     .two,
    //     .three,
    //     .four {
    //       flex: 1;
    //       height: 100%;
    //       width: 100%;
    //       display: flex;
    //       justify-content: center;
    //       align-items: center;
    //       font-size: 1px;

    //       margin-bottom: 1px;
    //     }
    //   }
    // }
    .five-item {
      flex: 1;
      height: 100%;
      width: 100%;
      display: flex;
      flex-direction: column;
      // position: relative;
      //       &::before {
      //        content: "";
      //        position: absolute;
      //        bottom: 0;
      //        right: -5px;
      //        width: 1px;
      //        height: 100%;
      //        background-color: #379661;
      //       }

      .top {
        flex: 0.5;
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;

        .top-item {
          flex: 1;
          height: 100%;
          width: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
        }

        .bottom-item {
          flex: 1;
          height: 100%;
          width: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
        }
      }

      .center {
        flex: 0.5;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
      }

      .bottom {
        flex: 1;
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;

        .one,
        .two,
        .three {
          font-size: 1px;


        }

        .one,
        .two,
        .three,
        .four {
          flex: 1;
          height: 100%;
          width: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
          font-size: 1px;

          margin-bottom: 1px;
        }
      }
    }

  }

  .bottom {
    flex: 1;
    height: 100%;
    width: 100%;
    // zoom: 0.5;

    .chart-container {
      width: 100%;
      height: 100%;
    }
  }

}
</style>

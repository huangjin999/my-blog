<template>
  <!-- <dv-border-box-8> -->

  <div class="ech-box">
    <!-- 左下的上半部分 -->
    <div class="top-half-lef">
      <div class="title-left">运行能耗的实时统计</div>
    </div>
    <!-- 左下的下半部分 -->
    <div class="bottom-half-lef">
      <div class="item-top">
        <div class="one texttit">设备</div>
        <div class="two texttit">运行台数</div>
        <div class="three texttit">运行总功率</div>
      </div>
      <div class="item-bottom">
        <div class="one">
          <div class="item textccc">精密空调</div>
          <div class="item textccc">列头柜</div>
          <div class="item textccc">冷冻泵</div>
          <div class="item textccc">主机</div>
          <div class="item textccc">冷却水泵</div>
          <div class="item textccc">冷却水塔</div>
          <div class="item textccc">蒸发冷</div>
        </div>
        <div class="two">
          <div class="item textccc"><span>12</span>/<span>12</span></div>
          <div class="item textccc"><span>12</span>/<span>13</span></div>
          <div class="item textccc"><span>12</span>/<span>18</span></div>
          <div class="item textccc"><span>12</span>/<span>17</span></div>
          <div class="item textccc"><span>12</span>/<span>20</span></div>
          <div class="item textccc"><span>12</span>/<span>16</span></div>
          <div class="item textccc"><span>12</span>/<span>15</span></div>
        </div>
        <div class="three">
          <div class="item textccc">
            <div class="one">6088 &nbsp; KW </div>
            <!-- 进度条 -->
            <div class="one"><el-progress :percentage="80" :text-inside="true" :stroke-width="13" /></div>
          </div>
          <div class="item textccc">
            <div class="one">6088 &nbsp; KW </div>
            <!-- 进度条 -->
            <div class="one"><el-progress :percentage="80" :text-inside="true" :stroke-width="13" /></div>
          </div>
          <div class="item textccc">
            <div class="one">6088 &nbsp; KW </div>
            <!-- 进度条 -->
            <div class="one"><el-progress :percentage="80" :text-inside="true" :stroke-width="13" status="warning" /></div>
          </div>
          <div class="item textccc">
            <div class="one">6088 &nbsp; KW </div>
            <!-- 进度条 -->
            <div class="one"><el-progress :percentage="80" :text-inside="true" :stroke-width="13" /></div>
          </div>
          <div class="item textccc">
            <div class="one">6088 &nbsp; KW </div>
            <!-- 进度条 -->
            <div class="one"><el-progress :percentage="80" :text-inside="true" :stroke-width="13" /></div>
          </div>
          <div class="item textccc">
            <div class="one">6088 &nbsp; KW </div>
            <!-- 进度条 -->
            <div class="one"><el-progress :percentage="80" :text-inside="true" :stroke-width="13" /></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- </dv-border-box-8> -->
</template>

<script>
export default {
  name: 'LeftBottom',
  data() {
    return {

    }
  },
  computed: {

  },

  created() {

  },
  mouted() {

  },
  methods: {

  }
}
</script>
<style scoped lang="scss">
.title-left {
  margin-left: 1%;
  margin-top: 5px;
  font-size: .2133rem;
}

.ech-box{
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  border: 1px solid #024596;

  .top-half-lef {
  flex: 1;
  display: flex;
  margin: 5px;
  height: 100%;
  width: 100%;
  // background-color: #1F2D3D;
}

.bottom-half-lef {
  flex: 9;
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
  .item-top{
    flex: 0.5;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: space-between;
    margin-bottom: 5px;
    .one,.two{
      flex: 1;
      width: 100%;
      height: 100%;
      // border:1px solid #ccc;
      // margin: 5px;
      text-align: center;
      margin-bottom: 5px;
    }
    .three{
      flex: 2;
      width: 100%;
      height: 100%;
      // border:1px solid #ccc;
      // margin: 5px;
      text-align: center;
      margin-bottom: 5px;
    }
  }
  .item-bottom{
    flex: 9;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: space-between;
    .one,.two{
      flex: 1;
      width: 100%;
      height: 100%;
      // border:1px solid #ccc;
      // margin: 5px;
      display: flex;
      flex-direction: column;
      text-align: center;

      .item{
        flex: 1;
        width: 100%;
        height: 100%;
        font-size: .2rem;
        // border:1px solid #ccc;
        // margin: 5px;
      }
    }
    .three{
        flex: 2;
      width: 100%;
      height: 100%;
      display: flex;
      flex-direction: column;
      text-align: left;
      text-align: center;

      .item{
        flex: 1;
        width: 100%;
        height: 100%;
        font-size: .2rem;
        // border:1px solid #ccc;
        // margin: 5px;
        display: flex;
        justify-content: space-between;
        padding-right: 0.2rem;
        .one{
          flex: 1;
          height: 100%;
          width: 100%;

        }
      }
      }
  }

}

}

// 全局灰色字体
.textccc {
  color: #c7d5e1;
}
.texttit {
  color: #dde8f2;
  font-size: .4rem;
}

// 千瓦和数字的距离
.number {
  margin-right: 0.1rem;
}
</style>

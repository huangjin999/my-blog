<template>
  <!-- <dv-border-box-8> -->
  <div class="ech-box">
    <div class="top">
      <div class="left">
        负荷预测与实际负荷曲线
      </div>
      <div class="right" />
    </div>
    <div class="bottom">
      <div ref="chartContainer" style="width: 100%; height: 100%; padding-left: 5px;" />
    </div>
  </div>
  <!-- </dv-border-box-8> -->
</template>

<script>
import echarts from 'echarts'
import { echartDataTwo } from '@/api/echart' // 引入echart数据接口

export default {
  name: 'LeftCenter',
  data() {
    return {
      echartList: {

      }
    }
  },
  mounted() {
    this.renderChart()
    // this.getChartData();
    // window.addEventListener("resize", this.handleResize);
  },
  beforeDestroy() {
    // window.removeEventListener("resize", this.handleResize);
  },
  methods: {
    // async getChartData() { //接口数据
    //     try {
    //         const response = await echartDataTwo();
    //         // console.log(response);
    //         this.echartList = response.data;
    //         this.renderChart(); //获取到数据再渲染图表
    //         console.log(this.echartList);
    //     } catch (error) {
    //         console.error(error);
    //     }
    // },
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      this.chart = echarts.init(chartContainer)

      const option = {
        textStyle: {
          color: '#fff'
        },

        title: {
          // text: '负荷预测与实际负荷曲线',
          // top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#fff'
          }
        },
        grid: {
          top: '40px',
          bottom: '13%',
          left: '13%',
          right: '5%'
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          // top: '10px',
          data: ['负荷预测', '实际负荷'],

          textStyle: {
            fontSize: 8,
            color: '#AEC8DF'
          },
          itemWidth: 8, // 设置图例项宽度
          itemHeight: 8 // 设置图例项高度
        },
        xAxis: {
          type: 'category',
          // boundaryGap: true,
          boundaryGap: false, //
          // data:this.echartList.xAxisData, //接口数据
          data: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'],
          axisLabel: {
            interval: 0,
            // rotate: 45,
            textStyle: {
              fontSize: 10
            }
          }
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: true,
            lineStyle: {
              type: 'dashed' // S
            }
          },
          axisLabel: {
            textStyle: {
              fontSize: 10
            }
          }
        },
        series: [
          {
            name: '负荷预测',
            type: 'line',
            stack: 'stacked',
            smooth: true, // 平滑曲线

            // data:this.echartList.one, //接口数据
            data: [110, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 132, 101, 134],
            itemStyle: {
              color: '#358FC1', //
              fontSize: 10

            }
          },
          {
            name: '实际负荷',
            type: 'line',
            stack: 'stacked',
            smooth: true, // 平滑曲线

            // data:this.echartList.two,   //接口数据
            data: [132, 220, 182, 191, 234, 290, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 132, 101, 134, 134, 90],
            itemStyle: {
              color: '#C39F49', //
              fontSize: 10
            }
          }

        ]
      }

      this.chart.setOption(option)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    }
  }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;
    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;

        }

        .right {
            display: flex;
            font-size: .2133rem;

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
    }

}
</style>

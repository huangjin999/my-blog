<template>
  <div class="ech-box">
    <div class="one">
      <div class="left">
        <div class="top color-yellow">系统PUE</div>
        <div class="bottom colorRig">1.2</div>
      </div>
      <div class="other-yellow" />
      <div class="right">
        <div class="top"><span class="color-text">同比：</span> <span class="colorRig">12.70%</span> </div>
        <div class="bottom"><span class="color-text">环比：</span> <span class="colorRig">12.70%</span></div>
      </div>
    </div>

    <div class="two">
      <div class="left">
        <div class="top color-red">系统COP</div>
        <div class="bottom colorRig">2.3</div>
      </div>
      <div class="other-red" />

      <div class="right">
        <div class="top"><span class="color-text">同比：</span>   <span class="colorRig">12.70%</span></div>
        <div class="bottom"><span class="color-text">环比：</span> <span class="colorRig">12.70%</span></div>
      </div>
    </div>
    <div class="three">
      <div class="left">
        <div class="top color-blue">制冷因子CLF</div>
        <div class="bottom colorRig">1.2</div>
      </div>
      <div class="other-blue" />

      <div class="right">
        <div class="top"><span class="color-text">同比：</span> <span class="colorRig">12.70%</span></div>
        <div class="bottom"><span class="color-text">环比：</span>  <span class="colorRig">12.70%</span></div>
      </div>
    </div>

  </div>
</template>

<script>
export default {
  name: 'CenterTop',
  data() {
    return {

    }
  },
  created() {

  },
  mounted() {

  },
  methods: {

  }
}
</script>
<style scoped lang='scss'>

.ech-box{
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: space-between;
  .two,.three{
      position: relative;
      &::before {
             content: "";
             position: absolute;
             bottom: 5px;
             left: -5px;
             width: 1px;
             height: 85%;
             border-left: 1px dashed #324B73;
      }
    }

  .one,.two,.three{
    width:100%;
    height:100%;
    margin: 0 0.5rem;
    display: flex;
    justify-content: center;

    .left{
      width: 100%;
      height: 100%;
      flex:0.7;
      display: flex;
      flex-direction: column;

      .top{
        width: 100%;
        height: 100%;
        display: flex;
        justify-content: center;
        align-items: center;

      }
      .bottom{
        width: 100%;
        height: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
      }
    }
    .right{
      width: 100%;
      height: 100%;
      flex: 1;
      display: flex;
      flex-direction: column;

      .top{
        width: 100%;
        height: 100%;
        display: flex;
        // justify-content: center;
        align-items: center;
        text-align: left;
      }
      .bottom{
        width: 100%;
        height: 100%;
        display: flex;
        // justify-content: center;
        align-items: center;
        text-align: left;

      }

    }
  }

}

.color-yellow {
  color: #BD8C40;
  margin-right: 0.3rem;
  font-size: 0.42rem;
}

.color-red {
  color: #E74C3C;
  margin-right: 0.3rem;
  font-size: 0.42rem;

}

.color-blue {
  color: #009EE3;
  margin-right: 0.3rem;
  font-size: 0.42rem;

}

.color-text {
  color: #AEC8DF;
  font-size: 0.32rem;

}
.colorRig{
  color: #dde8f2;

}

.color-title-yellow {
  border-right: 2px solid #BD8C40;
}

.color-title-red {
  border-right: 2px solid #E74C3C;
}

.color-title-blue {
  border-right: 2px solid #009EE3;
}
.bor{
  border-right: 1px solid #009EE3;
}

.divider {
      // width: 1px;
      // background-color: #333;
      // border: none;
      // border-style: none;
      // position: relative;
      // margin: 0 0.1rem;
      // &:after {
      //   content: '';
      //   position: absolute;
      //   width: 1px;
      //   height: 5px;
      //   background-color: #333;
      //   top: 100%;
      //   left: 0;
      //   transform: translateY(-50%);
      // }
    }

    .other-yellow {
      width: 2px;
      background-color: #BD8C40;
      border: none;
      border-style: none;
      position: relative;
      margin: 0.8rem 0.3rem;

      &:after {
        content: '';
        position: absolute;
        width: 2px;
        height: 5px;
        background-color:#BD8C40;
        top: 80%;
        left: 0;
        transform: translateY(-50%);
      }
    }
    .other-red {
      width: 2px;
      background-color: #E74C3C;
      border: none;
      border-style: none;
      position: relative;
      margin:0.8rem 0.3rem;

      &:after {
        content: '';
        position: absolute;
        width: 2px;
        height: 5px;
        background-color:#E74C3C;
        top: 80%;
        left: 0;
        transform: translateY(-50%);
      }
    }
    .other-blue {
      width: 2px;
      background-color: #009EE3;
      border: none;
      border-style: none;
      position: relative;
      margin: 0.8rem 0.3rem;
      &:after {
        content: '';
        position: absolute;
        width: 2px;
        height: 5px;
        background-color:009EE3;
        top: 80%;
        left: 0;
        transform: translateY(-50%);
      }
    }

</style>

<template>
  <!-- <dv-border-box-8> -->
  <div class="ech-box">
    <div class="left">
      <div class="top">
        <div class="title">
          系统能耗占比
        </div>
        <div class="icon" />
      </div>
      <div class="bottom">
        <div ref="chartContainer" style="width: 100%; height: 100%;" />
      </div>
    </div>
    <div class="right">
      <div class="top">
        <div class="title">
          设备能耗占比
        </div>
        <div class="icon" />
      </div>
      <div class="bottom">
        <div ref="chartContainers" style="width: 100%; height: 100%;" />

      </div>
    </div>
  </div>
  <!-- </dv-border-box-8> -->
</template>

<script>
import echarts from 'echarts'

export default {
  name: 'LeftCenterOne',
  mounted() {
    this.renderChart()
    window.addEventListener('resize', this.handleResize)
    window.addEventListener('resize', this.handleResizes)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
    window.removeEventListener('resize', this.handleResizes)
  },
  methods: {
    renderChart() {
      // 左侧饼图
      const chartContainer = this.$refs.chartContainer
      // 右侧饼图
      const chartContainers = this.$refs.chartContainers
      // 左侧饼图
      this.chart = echarts.init(chartContainer)
      // 右侧饼图
      this.charts = echarts.init(chartContainers)

      // 左侧饼图
      const option = {
        textStyle: {
          color: '#fff'
        },
        title: {
          // text: '系统能耗占比',
          top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#FFF'
          }
        },
        grid: {
          top: '30px',
          bottom: '10%',
          left: '13%',
          right: '5%'
        },

        tooltip: {
          trigger: 'item',
          formatter: '{b}: {c} ({d}%)'
        },
        legend: {
          top: '70%',
          // bottom: '5px',
          data: ['系统一', '系统二', '系统三', '系统四'],

          textStyle: {
            fontSize: 8,
            color: '#AEC8DF'
          },
          itemWidth: 6, // 设置图例项宽度
          itemHeight: 6 // 设置图例项高度
        },
        series: [
          {
            name: '能耗占比',
            type: 'pie',
            radius: ['40%', '60%'],
            center: ['50%', '40%'],
            avoidLabelOverlap: false,
            label: {
              show: true,
              position: 'center',
              formatter: '系统能耗', //
              fontSize: 10
              // fontWeight: 'bold'
            },
            emphasis: {
              label: {
                show: true,
                fontSize: 10
                // fontWeight: 'bold'
              }
            },
            labelLine: {
              show: false
            },
            data: [
              { value: 2.0, name: '系统一', itemStyle: { color: '#F79F00' }},
              { value: 4.9, name: '系统二', itemStyle: { color: '#009EE3' }},
              { value: 7.0, name: '系统三', itemStyle: { color: '#E44D49' }},
              { value: 2.0, name: '系统四', itemStyle: { color: '#66C13D' }}

            ]
          }
        ]
      }
      // 右侧饼图
      const options = {
        textStyle: {
          color: '#fff'
        },
        title: {
          // text: '设备能耗占比',
          // top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#fff'
          }
        },
        grid: {
          top: '1%',
          bottom: '10%',
          left: '13%',
          right: '5%'
        },

        tooltip: {
          trigger: 'item',
          formatter: '{b}: {c} ({d}%)'
        },

        legend: {
          top: '70%',
          // bottom: '5px',
          data: ['精密空调', '列头柜', '冷冻泵', '主机', '冷却水泵', '冷却水塔', '蒸发冷'],

          textStyle: {
            fontSize: 8,
            color: '#AEC8DF'
          },
          itemWidth: 6, // 设置图例项宽度
          itemHeight: 6 // 设置图例项高度
        },
        series: [
          {
            name: '能耗占比',
            type: 'pie',
            radius: ['40%', '60%'],
            center: ['50%', '40%'],
            avoidLabelOverlap: false,
            label: {
              show: true,
              position: 'center',
              formatter: '设备能耗', //
              fontSize: 10
              // fontWeight: 'bold'
            },
            emphasis: {
              label: {
                show: true,
                fontSize: 10
                // fontWeight: 'bold'
              }
            },
            labelLine: {
              show: false
            },
            data: [
              { value: 2.0, name: '精密空调', itemStyle: { color: '#FA9B01' }},
              { value: 4.9, name: '列头柜', itemStyle: { color: '#DB4B47' }},
              { value: 7.0, name: '冷冻泵', itemStyle: { color: '#8B4EAF' }},
              { value: 7.0, name: '主机', itemStyle: { color: '#FD9D04' }},
              { value: 7.0, name: '冷却水泵', itemStyle: { color: '#02A8C1' }},
              { value: 7.0, name: '冷却水塔', itemStyle: { color: '#6BC038' }},
              { value: 7.0, name: '蒸发冷', itemStyle: { color: '#A9CF1E' }}

            ]
          }
        ]
      }
      this.chart.setOption(option)
      this.charts.setOption(options)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    },
    handleResizes() {
      if (this.charts) {
        this.charts.resize()
      }
    }
  }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: space-between;
    box-sizing: border-box;
    border: 1px solid #024596;

    .left,.right {
        flex: 1;
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;

        .top {
            flex: 0.5;
            display: flex;
            justify-content: space-between;
            height: 100%;
            width: 100%;
            padding: 5px;

            .title {
                font-size: 8px;
                margin-top: .1333rem;
                margin-left: 1%;
            }
            .icon{

            }

        }

        .bottom {
            flex: 9;
            height: 100%;
            width: 100%;
        }

    }

}
</style>

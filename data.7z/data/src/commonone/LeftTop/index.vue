<template>
  <!-- <dv-border-box-8> -->

  <div class="ech-box">
    <!-- 左上的上半部分 -->
    <div class="top-half">
      <div class="sub-box">
        <div class="icon">
          <i class="el-icon-coin" />
        </div>
        <div class="text"><span class="textccc">干球温度:</span> <span>25°C</span> </div>
      </div>
      <div class="sub-box">
        <div class="icon">
          <i class="el-icon-coin" />
        </div>
        <div class="text"><span class="textccc">温球温度:</span><span>50%</span></div>
      </div>
      <div class="sub-box">
        <div class="icon">
          <i class="el-icon-coin" />
        </div>
        <div class="text"><span class="textccc">相对湿度:</span><span>50%</span></div>
      </div>
    </div>
    <!-- 左上的下半部分 -->
    <div class="bottom-half">
      <div class="left">
        <div class="item-left">
          <div class="one textccc">累计电耗：</div>
          <div class="one textccc">累计IT电耗:</div>
          <div class="one textccc">累计空调电耗:</div>
          <div class="one textccc">累计冷量:</div>
          <div class="one textccc">累计补水量</div>
        </div>
        <div class="item-right">
          <div class="one textrig">500kwh</div>
          <div class="one textrig">500kwh</div>
          <div class="one textrig">7000kwh</div>
          <div class="one textrig">200KW</div>
          <div class="one textrig">150t</div>
        </div>
      </div>
      <div class="right">
        <div class="item-left">
          <div class="one textccc">累计电耗：</div>
          <div class="one textccc">累计IT电耗:</div>
          <div class="one textccc">累计空调电耗:</div>
          <div class="one textccc">累计冷量:</div>
          <div class="one textccc">累计补水量</div>
        </div>
        <div class="item-right">
          <div class="one textrig">500kwh</div>
          <div class="one textrig">500kwh</div>
          <div class="one textrig">7000kwh</div>
          <div class="one textrig">200KW</div>
          <div class="one textrig">150t</div>
        </div>
      </div>

    </div>

  </div>
  <!-- </dv-border-box-8> -->
</template>

<script>
export default {
  name: 'LeftTop',
  data() {
    return {

    }
  },
  created() {

  },
  mounted() {

  },
  methods: {

  }

}
</script>
<style scoped lang='scss'>
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    border: 1px solid #024596;

}

.top-half {
    flex: 1;
    display: flex;
    flex-wrap: wrap;
    border-bottom: 1px dashed #324B73;
    width: 100%;
    height: 100%;
}

.bottom-half {
    flex: 2;
    display: flex;
    height: auto;
    margin-left: 3px;
    margin-top: 3px;
    width: 100%;
    height: 100%;
    justify-content: space-between;
    position: relative; // 伪元素
    &::after {
        content: "";
        position: absolute;
        top: 0;
        left: 48%;
        transform: translateX(-50%);
        width: 1px;
        height: 99%;
        border-left: 1px dashed #324B73; //
    }

    .left {
        flex: 1;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: space-between;

        .item-left {
            flex: 1.4;
            height: 100%;
            width: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;

            .one {
                flex: 1;
                height: 100%;
                width: 100%;
                // border: 1px solid #333;
                // margin-left: 3px;
            }

        }

        .item-right {
            flex: 1;
            height: 100%;
            width: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;

            .one {
                flex: 1;
                height: 100%;
                width: 100%;
                // border: 1px solid #333;
            }
        }
    }

    .right {
        flex: 1;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: space-between;

        .item-left {
            flex: 1.4;
            height: 100%;
            width: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            margin-left: 3px;

            .one {
                flex: 1;
                height: 100%;
                width: 100%;
                // border: 1px solid #333;
            }

        }

        .item-right {
            flex: 1;
            height: 100%;
            width: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;

            .one {
                flex: 1;
                height: 100%;
                width: 100%;
                // border: 1px solid #333;
            }
        }
    }
}

.sub-box {
    flex-basis: 33.33%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.icon {
    margin-top: .2667rem;
}

.text {
    font-size: .32rem;
    text-align: center;
    display: flex;
    align-items: center;
    margin-top: .6rem;
    // line-height: .5333rem;
    margin-bottom: 0.15rem;
}

// 灰色color
.textccc {
    color: #AEC8DF;
    font-size: .28rem;
}

.textrig {
    color: #dde8f2;
    font-size: .5rem;
}
</style>

<template>
    <div class="ech-box">
        <div class="top">
            <div class="left">
                供电范围
            </div>
            <div class="right">

            </div>

        </div>
        <div class="bottom">
        <div ref="chartContainer" style="width: 100%; height: 100%; " />
          
        </div>
    </div>
</template>

<script>
import echarts from 'echarts'


export default {

    name: 'CenterTop',
    mounted() {
    this.renderChart()
    window.addEventListener('resize', this.handleResize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      this.chart = echarts.init(chartContainer)

      const option = {
        textStyle: {
          color: '#fff'
        },

        title: {
          // text: '机载主机、蓄冰主机、水泵、水塔能耗环比',
          // top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#fff'

          }
        },
        grid: {
          top: '40px',
          bottom: '13%',
          left: '13%',
          right: '5%'
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            crossStyle: {
              color: '#999'
            }
          }

        },
        legend: {
          // top: '25px',
          data: ['用电量'],
          textStyle: {
            fontSize: 8,
            color: '#AEC8DF'
          },
          itemWidth: 6, // 设置图例项宽度
          itemHeight: 6 // 设置图例项高度
        },
        xAxis: [
          {
            type: 'category',
            data: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '九月', '十月', '十一月', '十二月'],

            axisPointer: {
              type: 'shadow'
            },
            axisLabel: {
              textStyle: {
                fontSize: 10
              }
            }
          }
        ],
        yAxis: [
          {
            name: 'KWH',
            nameTextStyle: {
              fontSize: 8
            },
            type: 'value',
            splitLine: {
              show: true,
              lineStyle: {
                type: 'dashed' //
              }
            },
            axisLabel: {
              textStyle: {
                fontSize: 10
              }
            }
          }
        ],
        series: [
          {
            name: '用电量',
            type: 'bar',
            itemStyle: {
              color: '#358FC1', //
              fontSize: 10

            },
            data: [
              0, 0, 0, 0, 0, 0, 6760, 435, 234, 2342, 23432, 0
            ]
          },


        ]
      }

      this.chart.setOption(option)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    }
  }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;

    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;


        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;
            position: relative;

            &::before {
                content: "";
                position: absolute;
                bottom: 5%;
                left: -5px;
                width: 2px;
                height: 100%;
                background-color: #0BC2C8;
            }

        }

        .right {
            display: flex;
            font-size: .2133rem;

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
        display: flex;


       

    }

}</style>

<template>
    <div class="ech-box">
        <div class="top">
            <div class="left">
                昨日电量
            </div>
            <div class="right" />
        </div>
        <div class="bottom">
            <div class="bottom-one">
                <div class="left">尖</div>
                <div class="right">
                    <div class="one">
                        <div class="one-top">313</div>
                        <div class="one-bottom">正向有功</div>
                    </div>
                    <div class="two">
                        <div class="two-top">313</div>
                        <div class="two-bottom">正向无功</div>
                    </div>
                    <div class="three">
                        <div class="three-top">313</div>
                        <div class="three-bottom">反向有功</div>
                    </div>
                    <div class="four">
                        <div class="four-top">313</div>
                        <div class="four-bottom">反向无功</div>
                    </div>
                </div>

            </div>
            <div class="bottom-two">
                <div class="left">峰</div>
                <div class="right">
                    <div class="one">
                        <div class="one-top">313</div>
                        <div class="one-bottom">正向有功</div>
                    </div>
                    <div class="two">
                        <div class="two-top">313</div>
                        <div class="two-bottom">正向无功</div>
                    </div>
                    <div class="three">
                        <div class="three-top">313</div>
                        <div class="three-bottom">反向有功</div>
                    </div>
                    <div class="four">
                        <div class="four-top">313</div>
                        <div class="four-bottom">反向无功</div>
                    </div>
                </div>

            </div>
            <div class="bottom-three">
                <div class="left">谷</div>
                <div class="right">
                    <div class="one">
                        <div class="one-top">313</div>
                        <div class="one-bottom">正向有功</div>
                    </div>
                    <div class="two">
                        <div class="two-top">313</div>
                        <div class="two-bottom">正向无功</div>
                    </div>
                    <div class="three">
                        <div class="three-top">313</div>
                        <div class="three-bottom">反向有功</div>
                    </div>
                    <div class="four">
                        <div class="four-top">313</div>
                        <div class="four-bottom">反向无功</div>
                    </div>
                </div>

            </div>
            <div class="bottom-four">
                <div class="left">平</div>
                <div class="right">
                    <div class="one">
                        <div class="one-top">313</div>
                        <div class="one-bottom">正向有功</div>
                    </div>
                    <div class="two">
                        <div class="two-top">313</div>
                        <div class="two-bottom">正向无功</div>
                    </div>
                    <div class="three">
                        <div class="three-top">313</div>
                        <div class="three-bottom">反向有功</div>
                    </div>
                    <div class="four">
                        <div class="four-top">313</div>
                        <div class="four-bottom">反向无功</div>
                    </div>
                </div>

            </div>

        </div>

    </div>
</template>
  
<script>
import echarts from 'echarts'

export default {
    name: 'CenterBottom',
    mounted() {

    },

    methods: {




    }
}
</script>
  
<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;

    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;
            position: relative;

            &::before {
                content: "";
                position: absolute;
                bottom: 5%;
                left: -5px;
                width: 2px;
                height: 100%;
                background-color: #0BC2C8;
            }

        }

        .right {
            display: flex;
            font-size: .2133rem;

            .day,
            .mouth,
            .year {
                background-color: #024596;
                border-radius: .1333rem;
                margin: 2px;
                padding: 2px;
                box-sizing: border-box;
                cursor: pointer;

                span {
                    color: #fff;

                }
            }

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;

        .bottom-one,
        .bottom-two,
        .bottom-three,
        .bottom-four {
            flex: 1;
            display: flex;
            justify-content: space-between;
            .left{
                flex: 1;
                display: flex;
                justify-content: center;
                align-items: center;
                font-size: 10;
               
            }
            .right{
                flex: 10;
                display: flex;
                justify-content: space-between;
                .one {
                flex: 1;
                height: 100%;
                width: 100%;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;

                .one-top {
                    font-size: 1rem;
                    font-weight: 600;
                    color: #fff;
                    margin-bottom: 0.5rem;
                }

                .one-bottom {
                    font-size: .1333rem;
                    color: #006CFF;
                    position: relative;

                    &::before {
                        content: "";
                        position: absolute;
                        bottom: 2;
                        left: -5px;
                        width: 3px;
                        height: 90%;
                        border-radius: 10px;
                        background-color: #006CFF;
                    }
                }

            }

            .two {
                flex: 1;
                height: 100%;
                width: 100%;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;

                .two-top {
                    font-size: 1rem;
                    font-weight: 600;
                    color: #fff;
                    margin-bottom: 0.5rem;
                }


                .two-bottom {
                    font-size: .1333rem;
                    color: #006CFF;
                    position: relative;

                    &::before {
                        content: "";
                        position: absolute;
                        bottom: 2;
                        left: -5px;
                        width: 3px;
                        height: 90%;
                        border-radius: 10px;
                        background-color: #6ACCA3;
                    }
                }
            }

            .three {
                flex: 1;
                height: 100%;
                width: 100%;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;

                .three-top {
                    font-size: 1rem;
                    font-weight: 600;
                    color: #fff;
                    margin-bottom: 0.5rem;
                }

                .three-bottom {
                    font-size: .1333rem;
                    color: #006CFF;
                    position: relative;

                    &::before {
                        content: "";
                        position: absolute;
                        bottom: 2;
                        left: -5px;
                        width: 3px;
                        height: 90%;
                        border-radius: 10px;
                        background-color: #6ACCA3;
                    }
                }
            }

            .four {
                flex: 1;
                height: 100%;
                width: 100%;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;

                .four-top {
                    font-size: 1rem;
                    font-weight: 600;
                    color: #fff;
                    margin-bottom: 0.5rem;
                }

                .four-bottom {
                    font-size: .1333rem;
                    color: #006CFF;
                    position: relative;

                    &::before {
                        content: "";
                        position: absolute;
                        bottom: 2;
                        left: -5px;
                        width: 3px;
                        height: 90%;
                        border-radius: 10px;
                        background-color: red;
                    }
                }

            }
            }

          
        }
    }

}
</style>
  
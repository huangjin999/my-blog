<template>
    <div class="ech-box">
        <div class="top">
            <div class="left">
                用电量
            </div>
            <div class="right">

            </div>

        </div>
        <div class="bottom">
            <div class="top-box">
                <div class="left">
                    <div class="one-top">372</div>
                    <div class="one-bottom">昨日用电量（KWH）</div>
                </div>
                <div class="right">
                    <div class="one-top">265</div>
                    <div class="one-bottom">今日用电量（KWH）</div>
                </div>
            </div>
            <div class="bottom-box">
                <div class="left">
                    <div class="one-top">72553</div>
                    <div class="one-bottom">上月总电量（KWH）</div>
                </div>
                <div class="right">
                    <div class="one-top">87613</div>
                    <div class="one-bottom">本月总电量（KWH）</div>
                </div>
            </div>

        </div>
    </div>
</template>

<script>


export default {
    name: 'LeftTop',
    mounted() {

    },

    methods: {







    }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;

    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;


        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;
            position: relative;

            &::before {
                content: "";
                position: absolute;
                bottom: 5%;
                left: -5px;
                width: 2px;
                height: 100%;
                background-color: #0BC2C8;
            }

        }

        .right {
            display: flex;
            font-size: .2133rem;

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;

        .top-box {
            flex: 1;
            display: flex;
            justify-content: space-between;
            height: 100%;
            width: 100%;
            padding: 5px;

            .left {
                flex: 1;
                display: flex;

                font-size: .2133rem;
                // background-color: #0BC2C8;
                color: #fff;
                flex-direction: column;
                justify-content: center;
                align-items: center;

                .one-top {
                    font-size: 1rem;
                    font-weight: 600;
                    color: #fff;
                    margin-bottom: 0.6rem;
                }

                .one-bottom {
                    font-size: .1333rem;
                    color: #006CFF;
                    position: relative;
                    // &::before {
                    //     content: "";
                    //     position: absolute;
                    //     bottom: 2;
                    //     left: -5px;
                    //     width: 3px;
                    //     height: 90%;
                    //     border-radius: 10px;
                    //     background-color: #006CFF;
                    // }
                }
            }

            .right {
                flex: 1;
                display: flex;

                font-size: .2133rem;
                // background-color: #0BC2C8;
                color: #fff;
                flex-direction: column;
                justify-content: center;
                align-items: center;

                .one-top {
                    font-size: 1rem;
                    font-weight: 600;
                    color: #fff;
                    margin-bottom: 0.6rem;
                }

                .one-bottom {
                    font-size: .1333rem;
                    color: #006CFF;
                    position: relative;
                    // &::before {
                    //     content: "";
                    //     position: absolute;
                    //     bottom: 2;
                    //     left: -5px;
                    //     width: 3px;
                    //     height: 90%;
                    //     border-radius: 10px;
                    //     background-color: #006CFF;
                    // }
                }
            }
        }

        .bottom-box {
            flex: 1;
            display: flex;
            justify-content: space-between;
            height: 100%;
            width: 100%;
            padding: 5px;

            .left {
                flex: 1;
                display: flex;

                font-size: .2133rem;
                // background-color: #0BC2C8;
                color: #fff;
                flex-direction: column;
                justify-content: center;
                align-items: center;

                .one-top {
                    font-size: 1rem;
                    font-weight: 600;
                    color: #fff;
                    margin-bottom: 0.6rem;
                }

                .one-bottom {
                    font-size: .1333rem;
                    color: #006CFF;
                    position: relative;
                    // &::before {
                    //     content: "";
                    //     position: absolute;
                    //     bottom: 2;
                    //     left: -5px;
                    //     width: 3px;
                    //     height: 90%;
                    //     border-radius: 10px;
                    //     background-color: #006CFF;
                    // }
                }
            }

            .right {
                flex: 1;
                display: flex;

                font-size: .2133rem;
                // background-color: #0BC2C8;
                color: #fff;
                flex-direction: column;
                justify-content: center;
                align-items: center;

                .one-top {
                    font-size: 1rem;
                    font-weight: 600;
                    color: #fff;
                    margin-bottom: 0.6rem;
                }

                .one-bottom {
                    font-size: .1333rem;
                    color: #006CFF;
                    position: relative;
                    // &::before {
                    //     content: "";
                    //     position: absolute;
                    //     bottom: 2;
                    //     left: -5px;
                    //     width: 3px;
                    //     height: 90%;
                    //     border-radius: 10px;
                    //     background-color: #006CFF;
                    // }
                }
            }
        }



    }

}</style>

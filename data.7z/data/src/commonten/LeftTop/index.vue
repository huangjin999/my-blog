<template>
    <div class="ech-box">
        <div class="top">
            <div class="left">
                电表分析
            </div>
            <div class="right">

            </div>

        </div>
        <div class="bottom">
            <div class="one">
                <div class="one-top">313</div>
                <div class="one-bottom">接入电表</div>
            </div>
            <div class="two">
                <div class="two-top">313</div>
                <div class="two-bottom">在线电表</div>
            </div>
            <div class="three">
                <div class="three-top">313</div>
                <div class="three-bottom">离线电表</div>
            </div>
            <div class="four">
                <div class="four-top">313</div>
                <div class="four-bottom">故障电表</div>
            </div>
        </div>
    </div>
</template>

<script>


export default {
    name: 'LeftTop',
    mounted() {

    },

    methods: {







    }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;

    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;


        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;
            position: relative;

            &::before {
                content: "";
                position: absolute;
                bottom: 5%;
                left: -5px;
                width: 2px;
                height: 100%;
                background-color: #0BC2C8;
            }

        }

        .right {
            display: flex;
            font-size: .2133rem;

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: space-between;

        .one {
            flex: 1;
            height: 100%;
            width: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;

            .one-top {
                font-size: 1rem;
                font-weight: 600;
                color: #fff;
                margin-bottom: 0.5rem;
            }

            .one-bottom {
                font-size: .1333rem;
                color: #006CFF;
                position: relative;
                &::before {
                    content: "";
                    position: absolute;
                    bottom: 2;
                    left: -5px;
                    width: 3px;
                    height: 90%;
                    border-radius: 10px;
                    background-color: #006CFF;
                }
            }
            
        }
        .two {
            flex: 1;
            height: 100%;
            width: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;

            .two-top {
                font-size: 1rem;
                font-weight: 600;
                color: #fff;
                margin-bottom: 0.5rem;
            }

           
            .two-bottom {
                font-size: .1333rem;
                color: #006CFF;
                position: relative;
                &::before {
                    content: "";
                    position: absolute;
                    bottom: 2;
                    left: -5px;
                    width: 3px;
                    height: 90%;
                    border-radius: 10px;
                    background-color: #6ACCA3;
                }
            }
        }
        .three {
            flex: 1;
            height: 100%;
            width: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;

            .three-top {
                font-size: 1rem;
                font-weight: 600;
                color: #fff;
                margin-bottom: 0.5rem;
            }
            .three-bottom {
                font-size: .1333rem;
                color: #006CFF;
                position: relative;
                &::before {
                    content: "";
                    position: absolute;
                    bottom: 2;
                    left: -5px;
                    width: 3px;
                    height: 90%;
                    border-radius: 10px;
                    background-color: #6ACCA3;
                }
            }
        }
        .four {
            flex: 1;
            height: 100%;
            width: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;

            .four-top {
                font-size: 1rem;
                font-weight: 600;
                color: #fff;
                margin-bottom: 0.5rem;
            }

            .four-bottom {
                font-size: .1333rem;
                color: #006CFF;
                position: relative;
                &::before {
                    content: "";
                    position: absolute;
                    bottom: 2;
                    left: -5px;
                    width: 3px;
                    height: 90%;
                    border-radius: 10px;
                    background-color: red;
                }
            }
           
        }
       

    }

}</style>

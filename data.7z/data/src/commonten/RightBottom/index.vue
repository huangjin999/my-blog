<template>
    <div class="ech-box">
        <div class="top">
            <div class="left">
                间隔名称

            </div>
            <div class="right">
                电量读数
            </div>

        </div>
        <div class="bottom">
          
        </div>
    </div>
</template>

<script>


export default {
    name: 'RightBottom',
    mounted() {

    },

    methods: {







    }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;

    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;


        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;
            position: relative;

            &::before {
                content: "";
                position: absolute;
                bottom: 5%;
                left: -5px;
                width: 2px;
                height: 100%;
                background-color: #0BC2C8;
            }

        }

        .right {
            display: flex;
            font-size: .2133rem;

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
        display: flex;


       

    }

}</style>

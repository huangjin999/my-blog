
<template>
  <!-- <dv-border-box-8> -->
  <div class="ech-box-eight">
    <div class="top">
      <div class="left">
        故障列表
      </div>
      <div class="right" />
    </div>
    <div class="bottom">
      <div class="tabs">
        <div
          v-for="(tab, index) in tabs"
          :key="index"
          :class="{ active: activeTab === index }"
          class="tab textccc"
          @click="activeTab = index"
        >
          {{ tab.label }}
        </div>
      </div>
      <div class="content">
        <div class="top textccc">
          <div class="top-item">{{ title.name }}</div>
          <div class="top-item">{{ title.tool }}</div>
          <div class="top-item">{{ title.time }}</div>
          <div class="top-item">{{ title.hours }}</div>
        </div>
        <div class="bottom">
          <div v-if="currentData && currentData.length > 0">
            <div v-for="(item, index) in currentData" :key="index">
              <div class="bottoms textrig">
                <div class="bottom-item">{{ item.name }}</div>
                <div class="bottom-item">{{ item.tool }}</div>
                <div class="bottom-item">{{ item.time }}</div>
                <div class="bottom-item">{{ item.hours }}</div>
              </div>
            </div>
          </div>
          <div v-else class="no-data-message">没有数据</div>
        </div>
      </div>
      <div class="pages">
        <el-pagination
          background
          small
          layout="prev, pager, next"
          :total="30"
          :current-page="pageNo"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>
  </div>
  <!-- </dv-border-box-8> -->
</template>

<script>

export default {
  data() {
    return {
      pageNo: 1, // 默认当前是第一页
      pageSize: 5, // 当前每页的数据是5条
      total: 0, // 总数默认为0
      activeTab: 0,
      currentData: [], // 当前显示的数据数组
      tabs: [
        { label: '严重' },
        { label: '重要' },
        { label: '普通' },
        { label: '提示' }
      ],
      title: {
        name: ' 告警名称',
        tool: '设备名称',
        time: '发生时间',
        hours: '告警时长'
      },
      text: {
        table1: [
          {
            name: ' 高压报警',
            tool: 'AHU001',
            time: '2022-07-08-12：13：00',
            hours: '4H'
          },
          {
            name: ' 高压报警',
            tool: 'AHU002',
            time: '2022-07-08-12：13：00',
            hours: '4H'
          },
          {
            name: ' 高压报警',
            tool: 'AHU003',
            time: '2022-07-08-12：13：00',
            hours: '4H'
          }
        ],
        table2: [
          {
            name: ' 重要告警',
            tool: 'AHU004',
            time: '2022-07-08-12：13：00',
            hours: '3H'
          },
          {
            name: ' 重要告警',
            tool: 'AHU005',
            time: '2022-07-08-12：13：00',
            hours: '2H'
          },
          {
            name: ' 重要告警',
            tool: 'AHU005',
            time: '2022-07-08-12：13：00',
            hours: '2H'
          }
        ],
        table3: [
          {
            name: ' 普通告警',
            tool: 'AHU003',
            time: '2022-07-08-12：13：00',
            hours: '3H'
          },
          {
            name: ' 普通告警',
            tool: 'AHU004',
            time: '2022-07-08-12：13：00',
            hours: '2H'
          },
          {
            name: ' 普通告警',
            tool: 'AHU005',
            time: '2022-07-08-12：13：00',
            hours: '2H'
          }
        ],
        table4: [
          {
            name: ' 提示告警',
            tool: 'AHU001',
            time: '2022-07-08-12：13：00',
            hours: '3H'
          },
          {
            name: ' 提示告警',
            tool: 'AHU002',
            time: '2022-07-08-12：13：00',
            hours: '2H'
          },
          {
            name: ' 提示告警',
            tool: 'AHU003',
            time: '2022-07-08-12：13：00',
            hours: '2H'
          }
        ]

      }
    }
  },

  computed: {
    // 用于计算总页数
    totalPage() {
      return Math.ceil(this.total / this.pageSize)
    }

  },
  watch: {
    activeTab() {
      this.updateCurrentData()
    }
  },
  created() {
    this.updateCurrentData()
  },
  mounted() {

  },
  methods: {
    updateCurrentData() {
      if (this.activeTab === 0) {
        this.currentData = this.text.table1
      } else if (this.activeTab === 1) {
        this.currentData = this.text.table2
      } else if (this.activeTab === 2) {
        this.currentData = this.text.table3
      } else if (this.activeTab === 3) {
        this.currentData = this.text.table4
      } else {
        this.currentData = []
      }
    },

    // 页码改变的时候
    handleCurrentChange(pageNo) {
      this.pageNo = pageNo
      this.getData()
    },
    // 每页显示条数改变的时候
    handleSizeChange(pageSize) {
      this.pageSize = pageSize
      this.getData()
    },
    getData() {
      // 模拟请求数据
      setTimeout(() => {
        // 模拟请求数据
        this.total = 100
      }, 1000)
    }
  }

}

</script>

<style lang="scss">

.el-pagination.is-background.el-pagination--small .btn-prev, .el-pagination.is-background.el-pagination--small .btn-next, .el-pagination.is-background.el-pagination--small .el-pager li{
    background-color: #024596;
}
.textccc {
    color: #AEC8DF;
    font-size: 0.32rem;
}
.tit{
    font-size: 10;
}
.textrig {
    color: #dde8f2;
    font-size: .5rem;
}

.ech-box-eight {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;

    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;
        border-bottom: 1px dashed #333 ;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;
            position: relative;
            &::before {
                content: "";
                position: absolute;
                bottom: 5%;
                left: -5px;
                width: 2px;
                height: 100%;
                background-color: #0BC2C8;
            }

        }

        .right {
            display: flex;
            font-size: .2133rem;

        }
    }

   .bottom{
    flex: 9;
    height: 100%;
    width: 100%;
    display: flex;
    flex-direction: column;
    .tabs {
        flex: .5;
        display: flex;
        justify-content: space-between;
        text-align: center;
        align-items: center;
        background-color: #032B66;
        width: 100%;
        height: 100%;
        margin-top: 2px;
        box-sizing: border-box;

        .tab {
            flex: 1;
            cursor: pointer;
            width: 100%;
            height: 100%;
            color: #fff;
        }

        .tab.active {
            color: #0BC2C8;
            background-color: #041D45;
        }
    }

    .content {
        flex: 5;
        display: flex;
        flex-direction: column;
        width: 100%;
        height: 100%;

        .top {
            flex: 1;
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            height: 100%;

            .top-item {
                flex: 1;
                text-align: center;
                padding: 8px;
                width: 100%;
                height: 100%;
            }
        }

        .bottom {
            flex: 5;
            display: flex;
            flex-direction: column;
            width: 100%;
            height: 100%;

            .bottoms {
                flex: 1;
                display: flex;
                justify-content: space-between;
                align-items: center;
                width: 100%;
                height: 100%;

                .bottom-item {
                    flex: 1;
                    text-align: center;
                    padding: 8px;
                    width: 100%;
                    height: 100%;
                }
            }
        }

        .no-data-message {
            width: 100%;
            height: 100%;
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            padding: 8px;
        }
    }

    .pages {
        flex: 1;
        width: 100%;
        height: 100%;
        // background-color: bisque;
        display: flex;
        justify-content: flex-end
    }
   }
}

</style>

<template>
  <div class="ech-box">
    <!-- 每一行5F -->
    <!-- <div class="row"><cardfive></cardfive></div> -->

    <!-- 4F -->
    <div class="row">
      <!-- 最左侧楼栋号 -->
      <div class="left">4F</div>
      <!-- 右侧五个小卡片 -->
      <div class="right">
        <!-- 从左到右第一个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 第二个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 第三个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 第四个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 第五个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 3F -->
    <div class="row">
      <!-- 最左侧楼栋号 -->
      <div class="left">3F</div>
      <!-- 右侧五个小卡片 -->
      <div class="right">
        <!-- 从左到右第一个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 第二个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 第三个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 第四个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 第五个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 2F 两行变一行-->
    <div class="row special-row">
      <!-- 左边 -->
      <div class="special-row-left">2F</div>
      <!-- 右边 -->
      <div class="special-row-right">
        <!-- 上半部分 -->
        <div class="special-row-right-top">
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <div class="item-bottom-center">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">平均温度:</div>
                  <div class="item-bottom-left-top-right">23</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">平均湿度:</div>
                  <div class="item-bottom-left-top-right">55</div>
                </div>
              </div>
              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <div class="item-bottom-center">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">平均温度:</div>
                  <div class="item-bottom-left-top-right">23</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">平均湿度:</div>
                  <div class="item-bottom-left-top-right">55</div>
                </div>
              </div>
              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <div class="item-bottom-center">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">平均温度:</div>
                  <div class="item-bottom-left-top-right">23</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">平均湿度:</div>
                  <div class="item-bottom-left-top-right">55</div>
                </div>
              </div>
              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <div class="item-bottom-center">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">平均温度:</div>
                  <div class="item-bottom-left-top-right">23</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">平均湿度:</div>
                  <div class="item-bottom-left-top-right">55</div>
                </div>
              </div>
              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <div class="item-bottom-center">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">平均温度:</div>
                  <div class="item-bottom-left-top-right">23</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">平均湿度:</div>
                  <div class="item-bottom-left-top-right">55</div>
                </div>
              </div>
              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- 下半部分 -->
        <div class="special-row-right-bottom">
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <div class="item-bottom-center">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">平均温度:</div>
                  <div class="item-bottom-left-top-right">23</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">平均湿度:</div>
                  <div class="item-bottom-left-top-right">55</div>
                </div>
              </div>
              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <div class="item-bottom-center">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">平均温度:</div>
                  <div class="item-bottom-left-top-right">23</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">平均湿度:</div>
                  <div class="item-bottom-left-top-right">55</div>
                </div>
              </div>
              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <div class="item-bottom-center">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">平均温度:</div>
                  <div class="item-bottom-left-top-right">23</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">平均湿度:</div>
                  <div class="item-bottom-left-top-right">55</div>
                </div>
              </div>
              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <div class="item-bottom-center">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">平均温度:</div>
                  <div class="item-bottom-left-top-right">23</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">平均湿度:</div>
                  <div class="item-bottom-left-top-right">55</div>
                </div>
              </div>
              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <div class="item-bottom-center">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">平均温度:</div>
                  <div class="item-bottom-left-top-right">23</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">平均湿度:</div>
                  <div class="item-bottom-left-top-right">55</div>
                </div>
              </div>
              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
    <!-- 1F -->
    <div class="row zom">
      <!-- 最左侧楼栋号 -->
      <div class="left">1F</div>
      <!-- 右侧五个小卡片 -->
      <div class="right">
        <!-- 从左到右第一个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 从左到右第一个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 从左到右第一个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 从左到右第一个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 从左到右第一个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 从左到右第一个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- B1F -->
    <div class="row">
      <!-- 最左侧楼栋号 -->
      <div class="left">B1F</div>
      <!-- 右侧五个小卡片 -->
      <div class="right">
        <!-- 从左到右第一个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 第二个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 第三个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 第四个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 第五个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- B2F -->
    <div class="row">
      <!-- 最左侧楼栋号 -->
      <div class="left">B2F</div>
      <!-- 右侧五个小卡片 -->
      <div class="right">
        <!-- 从左到右第一个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 第二个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 第三个小卡片 -->
        <div class="right-item">
          <!-- 小卡片标题 -->
          <div class="item-top">533机房</div>
          <!-- 小卡片下面部分 -->
          <div class="item-bottom">
            <!-- 小卡片下面分为左中右三部分 -->
            <!-- 左边的部分又分为上下两部分 -->
            <div class="item-bottom-left">
              <!-- 上 -->
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <!-- 下 -->
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
            <!-- 中间的部分分为上下两部分 -->

            <div class="item-bottom-center">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">平均温度:</div>
                <div class="item-bottom-left-top-right">23</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">平均湿度:</div>
                <div class="item-bottom-left-top-right">55</div>
              </div>
            </div>
            <!-- 右边的部分又分为上下两部分 -->

            <div class="item-bottom-right">
              <div class="item-bottom-left-top">
                <div class="item-bottom-left-top-left">运行台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
              <div class="item-bottom-left-bottom">
                <div class="item-bottom-left-top-left">故障台数:</div>
                <div class="item-bottom-left-top-right">5/50</div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
    <!-- B3F 两行变一行-->
    <div class="row special-row ">
      <!-- 左边 -->
      <div class="special-row-left">B3F</div>
      <!-- 右边 -->
      <div class="special-row-right">
        <!-- 上半部分 -->
        <div class="special-row-right-top">
          <div class="right-item zom">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <div class="item-bottom-center">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">平均温度:</div>
                  <div class="item-bottom-left-top-right">23</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">平均湿度:</div>
                  <div class="item-bottom-left-top-right">55</div>
                </div>
              </div>
              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-item zom">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <div class="item-bottom-center">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">平均温度:</div>
                  <div class="item-bottom-left-top-right">23</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">平均湿度:</div>
                  <div class="item-bottom-left-top-right">55</div>
                </div>
              </div>
              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>

        </div>
        <!-- 下半部分 -->
        <div class="special-row-right-bottom">
          <div class="right-item zom">
            <!-- 小卡片标题 -->
            <div class="item-top">533机房</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
              <!-- 中间的部分分为上下两部分 -->

              <div class="item-bottom-center">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">平均温度:</div>
                  <div class="item-bottom-left-top-right">23</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">平均湿度:</div>
                  <div class="item-bottom-left-top-right">55</div>
                </div>
              </div>
              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="three-bottom">
            <div class="item-top">主机/板换</div>
            <div class="item-center">
              <div class="one"><span class="textccc">供冷量：</span>25</div>
              <div class="two"><span class="textccc">供冷量：</span>25</div>
              <div class="three"><span class="textccc">供冷量：</span>25</div>
              <div class="four"><span class="textccc">供冷量：</span>25</div>
            </div>
            <div class="item-bottom">
              <div class="one">
                <div class="top"><span>机载</span></div>
                <div class="bottom">
                  <div class="bottom-left">
                    <div class="bottom-left-top">
                      <div class="bottom-left-top-left textccc">运行台数:</div>
                      <div class="bottom-left-top-right">5/50</div>
                    </div>
                    <div class="bottom-left-bottom">
                      <div class="bottom-left-top-left textccc">故障台数:</div>
                      <div class="bottom-left-top-right">5/50</div>
                    </div>
                  </div>
                  <div class="bottom-right">
                    <div class="bottom-left-top">
                      <div class="bottom-left-top-left textccc">手动台数:</div>
                      <div class="bottom-left-top-right">5/50</div>
                    </div>
                    <div class="bottom-left-bottom">
                      <div class="bottom-left-top-left textccc">可用台数:</div>
                      <div class="bottom-left-top-right">5/50</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="two">
                <div class="top"><span>蓄冰</span></div>
                <div class="bottom">
                  <div class="bottom-left textccc">运行台数: <span>5/50</span></div>
                  <!-- <div class="bottom-right"></div> -->
                </div>
              </div>
              <div class="three">
                <div class="top"><span>板换</span></div>
                <div class="bottom">
                  <div class="bottom-left textccc">运行台数:<span>5/50</span> </div>
                  <!-- <div class="bottom-right">5/50</div> -->
                </div>
              </div>
            </div>
          </div>
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">冷却水泵</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>

              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">手动台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">可用台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">冷却水泵</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>

              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">手动台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">可用台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-item">
            <!-- 小卡片标题 -->
            <div class="item-top">冷却水泵</div>
            <!-- 小卡片下面部分 -->
            <div class="item-bottom">
              <!-- 小卡片下面分为左中右三部分 -->
              <!-- 左边的部分又分为上下两部分 -->
              <div class="item-bottom-left">
                <!-- 上 -->
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">运行台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <!-- 下 -->
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">故障台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>

              <!-- 右边的部分又分为上下两部分 -->

              <div class="item-bottom-right">
                <div class="item-bottom-left-top">
                  <div class="item-bottom-left-top-left">手动台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
                <div class="item-bottom-left-bottom">
                  <div class="item-bottom-left-top-left">可用台数:</div>
                  <div class="item-bottom-left-top-right">5/50</div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

    </div>

  </div>
</template>

<script>
// import cardfive from "@/commoneight/cardfive";
export default {
  components: {
    // cardfive,
  },
  data() {
    return {}
  },
  created() { },
  mounted() { },
  methods: {}
}
</script>

<style scoped lang="scss">
.ech-box {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  color: #ffffff;
  padding: 3px;
  box-sizing: border-box;
  zoom: 0.75;

  .textccc {
    color: #AEC8DF;

  }
 .zom{
  zoom: 0.77 !important;
 }
  .row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex: 1;
    // border: 1px solid #ccc;
    width: 100%;
    height: 100%;
    border: 1px solid #024596;

    &.special-row {
      flex: 2;
      display: flex;
      // flex-direction: column;
      justify-content: space-between;
      width: 100%;
      height: 100%;

      .special-row-left {
        flex: 1;
        background-color: #05193C;
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.21rem;
        ;
      }

      .special-row-right {
        flex: 35;
        // background-color: #ffffff;
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;

        .special-row-right-top {
          flex: 1;
          // background-color: #4684ef;
          width: 100%;
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 0.13rem;
          display: flex;
          ;

          .right-item {
            flex: 1;
            // background-color: lightpink;
            // border: 1px solid #ccc;
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            // margin-left: 1px;
            padding: 5px;

            .item-top {
              flex: 1;
              background-color: #002D6C;
              font-size: 0.21rem;
              width: 100%;
              height: 100%;
              padding-left: 3px;
              display: flex;
              align-items: center;
              /* 垂直居中 */

            }

            .item-bottom {
              flex: 3;
              width: 100%;
              height: 100%;
              background-color: #04204F;
              font-size: 0.13rem;
              display: flex;
              justify-content: space-between;
              padding-left: 3px;
              ;

              .item-bottom-left,
              .item-bottom-center,
              .item-bottom-right {
                flex: 1;
                // background-color: #ccc;
                width: 100%;
                height: 100%;
                font-size: 0.13rem;
                display: flex;
                flex-direction: column;
                ;


                .item-bottom-left-top,
                .item-bottom-left-bottom {
                  flex: 1;
                  // background-color: #ffbfbf;
                  width: 100%;
                  height: 100%;
                  font-size: 0.13rem;
                  display: flex;
                  justify-content: space-between;
                  ;


                  .item-bottom-left-top-left {
                    flex: 1.5;
                    // background-color: #ccc;
                    width: 100%;
                    height: 100%;
                    font-size: 0.13rem;
                    display: flex;
                    align-items: center;
                    color: #AEC8DF;
                    ;


                  }

                  .item-bottom-left-top-right {
                    flex: 1;
                    // background-color: #ffbfbf;
                    width: 100%;
                    height: 100%;
                    font-size: 0.13rem;
                    /* 调整字体大小 */
                    display: flex;
                    align-items: center;
                    /* 垂直居中 */

                  }
                }

              }

            }

          }
        }

        .special-row-right-bottom {
          flex: 1;
          // background-color: #ffffff;
          width: 100%;
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 0.21rem;
          display: flex;
          ;


          .right-item {
            flex: 1;
            // background-color: lightpink;
            // border: 1px solid #ccc;
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;

            // margin-left: 1px;
            padding: 5px;

            .item-top {
              flex: 1;
              background-color: #002D6C;
              font-size: 0.21rem;
              width: 100%;
              height: 100%;
              padding-left: 3px;
              display: flex;
              align-items: center;

            }

            .item-bottom {
              flex: 3;
              width: 100%;
              height: 100%;
              background-color: #04204F;
              font-size: 0.13rem;
              display: flex;
              justify-content: space-between;
              padding-left: 3px;
              ;

              .item-bottom-left,
              .item-bottom-center,
              .item-bottom-right {

                flex: 1;
                width: 100%;
                height: 100%;
                display: flex;
                flex-direction: column;

                .item-bottom-left-top,
                .item-bottom-left-bottom {
                  flex: 1;
                  width: 100%;
                  height: 100%;
                  display: flex;
                  justify-content: space-between;

                  .item-bottom-left-top-left {
                    flex: 1.5;
                    width: 100%;
                    height: 100%;
                    display: flex;
                    align-items: center;
                    color: #AEC8DF;
                  }

                  .item-bottom-left-top-right {
                    flex: 1;
                    width: 100%;
                    height: 100%;
                    display: flex;
                    align-items: center;
                  }
                }

              }

            }

          }

          .three-bottom {
            flex: 2;
            width: 100%;
            height: 100%;
            // border: 1px solid #ccc;
            display: flex;
            flex-direction: column;
            padding: 5px;

            .item-top {
              flex: 1;
              background-color: #002D6C;
              font-size: 0.21rem;
              width: 100%;
              height: 100%;
              padding-left: 3px;
              display: flex;
              align-items: center;

            }

            .item-center {
              flex: 1;
              width: 100%;
              height: 100%;
              display: flex;
              justify-content: space-between;
              border-bottom: 1px solid #333;

              .one,
              .two,
              .three,
              .four {
                flex: 1;
                width: 100%;
                height: 100%;
                display: flex;
                align-items: center;
                // justify-content: space-between;

              }
            }

            .item-bottom {
              flex: 2;
              height: 100%;
              width: 100%;
              display: flex;
              justify-content: space-between;

              .one {
                flex: 1.5;
                width: 100%;
                height: 100%;
                display: flex;
                flex-direction: column;

                .top {
                  flex: 1;
                  width: 100%;
                  height: 100%;
                  text-align: center;
                  align-items: center;
                  margin: auto;
                }

                .bottom {
                  flex: 2;
                  width: 100%;
                  height: 100%;
                  display: flex;
                  justify-content: space-between;

                  .bottom-left {
                    flex: 1;
                    width: 100%;
                    height: 100%;
                    display: flex;
                    flex-direction: column;

                    .bottom-left-top {
                      flex: 1;
                      width: 100%;
                      height: 100%;
                      display: flex;
                      justify-content: space-between;
                    }

                    .bottom-left-bottom {
                      flex: 1;
                      width: 100%;
                      height: 100%;
                      display: flex;
                      justify-content: space-between;
                    }
                  }

                  .bottom-right {
                    flex: 1;
                    width: 100%;
                    height: 100%;
                    display: flex;
                    flex-direction: column;
                    margin-left: 3px;

                    .bottom-left-top {
                      flex: 1;
                      width: 100%;
                      height: 100%;
                      display: flex;
                      justify-content: space-between;
                    }

                    .bottom-left-bottom {
                      flex: 1;
                      width: 100%;
                      height: 100%;
                      display: flex;
                      justify-content: space-between;
                    }
                  }

                }
              }

              .two,
              .three {
                flex: 1;
                width: 100%;
                height: 100%;
                display: flex;
                flex-direction: column;

                .top {
                  flex: 1;
                  width: 100%;
                  height: 100%;
                  text-align: center;
                  align-items: center;
                  margin: auto;
                }

                .bottom {
                  flex: 2;
                  width: 100%;
                  height: 100%;
                  text-align: center;
                  align-items: center;
                  margin: auto;

                  // display: flex;
                  // justify-content: space-between;
                }
              }
            }

          }

        }

      }

    }

    .left {
      flex: 1;
      background-color: #05193C;
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.21rem;
      ;

    }

    .right {
      flex: 35;
      // background-color: lightgreen;
      display: flex;
      justify-content: space-between;
      width: 100%;
      height: 100%;

      .right-item {
        flex: 1;
        // background-color: lightpink;
        // border: 1px solid #ccc;
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        // margin-left: 1px;
        padding: 5px;

        .item-top {
          flex: 1;
          background-color: #002D6C;
          font-size: 0.21rem;
          width: 100%;
          height: 100%;
          padding-left: 3px;
          display: flex;
          align-items: center;
          /* 垂直居中 */

        }

        .item-bottom {
          flex: 3;
          width: 100%;
          height: 100%;
          background-color: #04204F;
          font-size: 0.13rem;
          display: flex;
          justify-content: space-between;
          padding-left: 3px;

          .item-bottom-left,
          .item-bottom-center,
          .item-bottom-right {
            flex: 1;
            // background-color: #ccc;
            width: 100%;
            height: 100%;
            font-size: 0.13rem;
            display: flex;
            flex-direction: column;
            ;

            .item-bottom-left-top,
            .item-bottom-left-bottom {
              flex: 1;
              // background-color: #ffbfbf;
              width: 100%;
              height: 100%;
              font-size: 0.13rem;
              display: flex;
              justify-content: space-between;
              ;

              .item-bottom-left-top-left {
                flex: 1.5;
                // background-color: #ccc;
                width: 100%;
                height: 100%;
                font-size: 0.13rem;
                display: flex;
                align-items: center;
                color: #AEC8DF;
                ;

              }

              .item-bottom-left-top-right {
                flex: 1;
                // background-color: #ffbfbf;
                width: 100%;
                height: 100%;
                font-size: 0.13rem;
                /* 调整字体大小 */
                display: flex;
                align-items: center;
                ;

              }
            }

          }

        }

      }
    }
  }
}</style>

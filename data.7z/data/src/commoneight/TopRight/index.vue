<template>
  <div class="ech-box">
    <div class="top">
      <div class="left">
        故障分析饼图
      </div>
      <div class="right" />
    </div>
    <div class="bottom">
      <div ref="chartContainer" style="width: 100%; height: 100%;" />
    </div>
  </div>
  <!-- </dv-border-box-8> -->
</template>

<script>
import echarts from 'echarts'

export default {
  name: 'TopOne',
  mounted() {
    this.renderChart()
    window.addEventListener('resize', this.handleResize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
  },

  methods: {
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      this.chart = echarts.init(chartContainer)

      const option = {
        textStyle: {
          color: '#fff'
        },
        // title: {
        //     text: '故障分析饼图',
        //     top: '5px',
        //     textStyle: {
        //         fontSize: "8px",
        //         color: '#fff'
        //     }
        // },
        grid: {
          top: '10px',
          left: '60px',
          right: '10px',
          bottom: '10px'
        },
        tooltip: {
          trigger: 'item',
          formatter: '{b}: {c} ({d}%)',
          textStyle: {
            fontSize: 6,
            color: '#fff'
          }
        },
        legend: {
          top: 30,
          right: 100,
          // left: 'right',
          orient: 'vertical', // 垂直显示
          textStyle: {
            fontSize: 8,
            color: '#AEC8DF'
          },
          itemWidth: 8,
          itemHeight: 8
        },
        series: [
          {
            name: '故障分析',
            type: 'pie',
            radius: ['40%', '60%'],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: true,
                formatter: '{d}%',
                textStyle: {
                  fontSize: 8,
                  fontWeight: 'bold'
                }
              },
              emphasis: {
                show: true
              }
            },
            emphasis: {
              label: {
                show: true,
                fontSize: 10,
                fontWeight: 'bold'
              }
            },
            labelLine: {
              normal: {
                show: true
              },
              emphasis: {
                show: true
              }
            },
            data: [
              { value: 2.0, name: '严重', itemStyle: { color: '#E34D4E' }},
              { value: 4.9, name: '重要', itemStyle: { color: '#F99C01' }},
              { value: 7.0, name: '普通', itemStyle: { color: '#0362D6' }},
              { value: 3.0, name: '提示', itemStyle: { color: '#00FEFE' }}

            ]
          }
        ]
      }

      this.chart.setOption(option)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    }

  }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;

    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;
        border-bottom: 1px dashed #333 ;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;
            position: relative;
            &::before {
                content: "";
                position: absolute;
                bottom: 5%;
                left: -5px;
                width: 2px;
                height: 100%;
                background-color: #0BC2C8;
            }

        }

        .right {
            display: flex;
            font-size: .2133rem;

        }
    }
    // .top::after {
    //     content: "";
    //     display: block;
    //     width: 100%;
    //     border-bottom: 1px dashed #333;
    // }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
    }

}
</style>

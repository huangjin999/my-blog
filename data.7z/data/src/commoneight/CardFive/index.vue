<template>

  <!-- <div class="row"> -->
  <!-- 最左侧楼栋号 -->
  <div class="left">5F</div>
  <!-- 右侧五个小卡片 -->
  <div class="right">
    <!-- 从左到右第一个小卡片 -->
    <div class="right-item">
      <!-- 小卡片标题 -->
      <div class="item-top">533机房</div>
      <!-- 小卡片下面部分 -->
      <div class="item-bottom">
        <!-- 小卡片下面分为左中右三部分 -->
        <!-- 左边的部分又分为上下两部分 -->
        <div class="item-bottom-left">
          <!-- 上 -->
          <div class="item-bottom-left-top">
            <div class="item-bottom-left-top-left">运行台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
          <!-- 下 -->
          <div class="item-bottom-left-bottom">
            <div class="item-bottom-left-top-left">故障台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
        </div>
        <!-- 中间的部分分为上下两部分 -->

        <div class="item-bottom-center">
          <div class="item-bottom-left-top">
            <div class="item-bottom-left-top-left">平均温度:</div>
            <div class="item-bottom-left-top-right">23</div>
          </div>
          <div class="item-bottom-left-bottom">
            <div class="item-bottom-left-top-left">平均湿度:</div>
            <div class="item-bottom-left-top-right">55</div>
          </div>
        </div>
        <!-- 右边的部分又分为上下两部分 -->

        <div class="item-bottom-right">
          <div class="item-bottom-left-top">
            <div class="item-bottom-left-top-left">运行台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
          <div class="item-bottom-left-bottom">
            <div class="item-bottom-left-top-left">故障台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
        </div>
      </div>
    </div>
    <!-- 第二个小卡片 -->
    <div class="right-item">
      <!-- 小卡片标题 -->
      <div class="item-top">533机房</div>
      <!-- 小卡片下面部分 -->
      <div class="item-bottom">
        <!-- 小卡片下面分为左中右三部分 -->
        <!-- 左边的部分又分为上下两部分 -->
        <div class="item-bottom-left">
          <!-- 上 -->
          <div class="item-bottom-left-top">
            <div class="item-bottom-left-top-left">运行台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
          <!-- 下 -->
          <div class="item-bottom-left-bottom">
            <div class="item-bottom-left-top-left">故障台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
        </div>
        <!-- 中间的部分分为上下两部分 -->

        <div class="item-bottom-center">
          <div class="item-bottom-left-top">
            <div class="item-bottom-left-top-left">平均温度:</div>
            <div class="item-bottom-left-top-right">23</div>
          </div>
          <div class="item-bottom-left-bottom">
            <div class="item-bottom-left-top-left">平均湿度:</div>
            <div class="item-bottom-left-top-right">55</div>
          </div>
        </div>
        <!-- 右边的部分又分为上下两部分 -->

        <div class="item-bottom-right">
          <div class="item-bottom-left-top">
            <div class="item-bottom-left-top-left">运行台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
          <div class="item-bottom-left-bottom">
            <div class="item-bottom-left-top-left">故障台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
        </div>
      </div>
    </div>
    <!-- 第三个小卡片 -->
    <div class="right-item">
      <!-- 小卡片标题 -->
      <div class="item-top">533机房</div>
      <!-- 小卡片下面部分 -->
      <div class="item-bottom">
        <!-- 小卡片下面分为左中右三部分 -->
        <!-- 左边的部分又分为上下两部分 -->
        <div class="item-bottom-left">
          <!-- 上 -->
          <div class="item-bottom-left-top">
            <div class="item-bottom-left-top-left">运行台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
          <!-- 下 -->
          <div class="item-bottom-left-bottom">
            <div class="item-bottom-left-top-left">故障台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
        </div>
        <!-- 中间的部分分为上下两部分 -->

        <div class="item-bottom-center">
          <div class="item-bottom-left-top">
            <div class="item-bottom-left-top-left">平均温度:</div>
            <div class="item-bottom-left-top-right">23</div>
          </div>
          <div class="item-bottom-left-bottom">
            <div class="item-bottom-left-top-left">平均湿度:</div>
            <div class="item-bottom-left-top-right">55</div>
          </div>
        </div>
        <!-- 右边的部分又分为上下两部分 -->

        <div class="item-bottom-right">
          <div class="item-bottom-left-top">
            <div class="item-bottom-left-top-left">运行台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
          <div class="item-bottom-left-bottom">
            <div class="item-bottom-left-top-left">故障台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
        </div>
      </div>
    </div>
    <!-- 第四个小卡片 -->
    <div class="right-item">
      <!-- 小卡片标题 -->
      <div class="item-top">533机房</div>
      <!-- 小卡片下面部分 -->
      <div class="item-bottom">
        <!-- 小卡片下面分为左中右三部分 -->
        <!-- 左边的部分又分为上下两部分 -->
        <div class="item-bottom-left">
          <!-- 上 -->
          <div class="item-bottom-left-top">
            <div class="item-bottom-left-top-left">运行台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
          <!-- 下 -->
          <div class="item-bottom-left-bottom">
            <div class="item-bottom-left-top-left">故障台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
        </div>
        <!-- 中间的部分分为上下两部分 -->

        <div class="item-bottom-center">
          <div class="item-bottom-left-top">
            <div class="item-bottom-left-top-left">平均温度:</div>
            <div class="item-bottom-left-top-right">23</div>
          </div>
          <div class="item-bottom-left-bottom">
            <div class="item-bottom-left-top-left">平均湿度:</div>
            <div class="item-bottom-left-top-right">55</div>
          </div>
        </div>
        <!-- 右边的部分又分为上下两部分 -->

        <div class="item-bottom-right">
          <div class="item-bottom-left-top">
            <div class="item-bottom-left-top-left">运行台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
          <div class="item-bottom-left-bottom">
            <div class="item-bottom-left-top-left">故障台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
        </div>
      </div>
    </div>
    <!-- 第五个小卡片 -->
    <div class="right-item">
      <!-- 小卡片标题 -->
      <div class="item-top">533机房</div>
      <!-- 小卡片下面部分 -->
      <div class="item-bottom">
        <!-- 小卡片下面分为左中右三部分 -->
        <!-- 左边的部分又分为上下两部分 -->
        <div class="item-bottom-left">
          <!-- 上 -->
          <div class="item-bottom-left-top">
            <div class="item-bottom-left-top-left">运行台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
          <!-- 下 -->
          <div class="item-bottom-left-bottom">
            <div class="item-bottom-left-top-left">故障台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
        </div>
        <!-- 中间的部分分为上下两部分 -->

        <div class="item-bottom-center">
          <div class="item-bottom-left-top">
            <div class="item-bottom-left-top-left">平均温度:</div>
            <div class="item-bottom-left-top-right">23</div>
          </div>
          <div class="item-bottom-left-bottom">
            <div class="item-bottom-left-top-left">平均湿度:</div>
            <div class="item-bottom-left-top-right">55</div>
          </div>
        </div>
        <!-- 右边的部分又分为上下两部分 -->

        <div class="item-bottom-right">
          <div class="item-bottom-left-top">
            <div class="item-bottom-left-top-left">运行台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
          <div class="item-bottom-left-bottom">
            <div class="item-bottom-left-top-left">故障台数:</div>
            <div class="item-bottom-left-top-right">5/50</div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- </div> -->
</template>

<script>
export default {
  name: 'CardFive',
  data() {
    return {

    }
  },
  created() {

  },
  mouted() {

  },
  methods: {

  }
}
</script>
<style scoped lang='scss'>
              .row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex: 1;
        border: 1px solid #ccc;
        width: 100%;
        height: 100%;

        &.special-row {
            flex: 2;
            display: flex;
            // flex-direction: column;
            justify-content: space-between;
            width: 100%;
            height: 100%;

            .special-row-left {
                flex: 1;
                background-color: #05193C;
                width: 100%;
                height: 100%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 8px;
            }

            .special-row-right {
                flex: 35;
                // background-color: #ffffff;
                width: 100%;
                height: 100%;
                display: flex;
                flex-direction: column;

                .special-row-right-top {
                    flex: 1;
                    // background-color: #4684ef;
                    width: 100%;
                    height: 100%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 3px;
                    display: flex;

                    .right-item {
                        flex: 1;
                        // background-color: lightpink;
                        // border: 1px solid #ccc;
                        width: 100%;
                        height: 100%;
                        display: flex;
                        flex-direction: column;
                        // margin-left: 1px;
                        padding:5px;

                        .item-top {
                            flex: 1;
                            background-color: #002D6C;
                            font-size: 8px;
                            width: 100%;
                            height: 100%;
                            padding-left:3px
                        }

                        .item-bottom {
                            flex: 3;
                            width: 100%;
                            height: 100%;
                            background-color: #04204F;
                            font-size: 3px;
                            display: flex;
                            justify-content: space-between;
                            padding-left:3px;

                            .item-bottom-left,
                            .item-bottom-center,
                            .item-bottom-right {
                                flex: 1;
                                // background-color: #ccc;
                                width: 100%;
                                height: 100%;
                                font-size: 3px;
                                display: flex;
                                flex-direction: column;

                                .item-bottom-left-top,
                                .item-bottom-left-bottom {
                                    flex: 1;
                                    // background-color: #ffbfbf;
                                    width: 100%;
                                    height: 100%;
                                    font-size: 3px;
                                    display: flex;
                                    justify-content: space-between;

                                    .item-bottom-left-top-left {
                                        flex: 1.5;
                                        // background-color: #ccc;
                                        width: 100%;
                                        height: 100%;
                                        font-size: 3px;
                                        display: flex;
                                        align-items: center;

                                    }

                                    .item-bottom-left-top-right {
                                        flex: 1;
                                        // background-color: #ffbfbf;
                                        width: 100%;
                                        height: 100%;
                                        font-size: 3px;
                                        /* 调整字体大小 */
                                        display: flex;
                                        align-items: center;
                                        /* 垂直居中 */

                                    }
                                }

                            }

                        }

                    }
                }

                .special-row-right-bottom {
                    flex: 1;
                    // background-color: #ffffff;
                    width: 100%;
                    height: 100%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 8px;
                    display: flex;

                    .right-item {
                        flex: 1;
                        // background-color: lightpink;
                        // border: 1px solid #ccc;
                        width: 100%;
                        height: 100%;
                        display: flex;
                        flex-direction: column;
                        // margin-left: 1px;
                        padding:5px;

                        .item-top {
                            flex: 1;
                            background-color: #002D6C;
                            font-size: 8px;
                            width: 100%;
                            height: 100%;
                            padding-left:3px
                        }

                        .item-bottom {
                            flex: 3;
                            width: 100%;
                            height: 100%;
                            background-color: #04204F;
                            font-size: 3px;
                            display: flex;
                            justify-content: space-between;
                            padding-left:3px;

                        }

                    }
                    .three-bottom{
                    flex:2;
                    width: 100%;
                    height:100%;
                    // border: 1px solid #ccc;
                    display: flex;
                    flex-direction: column;
                        padding:5px;
                    .item-top {
                            flex: 1;
                            background-color: #002D6C;
                            font-size: 8px;
                            width: 100%;
                            height: 100%;
                            padding-left:3px
                        }
                        .item-center{
                            flex:1;
                            width: 100%;
                            height: 100%;
                            display: flex;
                            justify-content: space-between;
                            border-bottom:1px solid #333;
                            .one,.two,.three,.four{
                                flex:1;
                                width: 100%;
                                height: 100%;
                                display: flex;
                                justify-content: space-between;

                            }
                        }
                        .item-bottom{
                            flex:2;
                            height: 100%;
                            width:100%;
                            display: flex;
                            justify-content: space-between;
                            .one{
                                flex:2;
                                width: 100%;
                                height: 100%;
                                display: flex;
                                flex-direction: column;
                                .top{
                                    flex:1;
                                    width: 100%;
                                    height: 100%;
                                    display: flex;
                                    // justify-content: space-between;
                                    text-align: center;
                                }
                                .bottom{
                                    flex:2;
                                    width: 100%;
                                    height: 100%;
                                    display: flex;
                                    justify-content: space-between;
                                    .bottom-left{
                                        flex:1;
                                        width: 100%;
                                        height: 100%;
                                        display: flex;
                                        flex-direction: column;
                                        .bottom-left-top{
                                            flex:1;
                                            width: 100%;
                                            height: 100%;
                                            display: flex;
                                            justify-content: space-between;
                                        }
                                        .bottom-left-bottom{
                                            flex:1;
                                            width: 100%;
                                            height: 100%;
                                            display: flex;
                                            justify-content: space-between;
                                        }
                                    }
                                    .bottom-right{
                                        flex:1;
                                        width: 100%;
                                        height: 100%;
                                        display: flex;
                                        flex-direction: column;
                                        .bottom-left-top{
                                            flex:1;
                                            width: 100%;
                                            height: 100%;
                                            display: flex;
                                            justify-content: space-between;
                                        }
                                        .bottom-left-bottom{
                                            flex:1;
                                            width: 100%;
                                            height: 100%;
                                            display: flex;
                                            justify-content: space-between;
                                        }
                                    }

                                }
                            }
                            .two,.three{
                                flex:1;
                                width: 100%;
                                height: 100%;
                                display: flex;
                                .top{
                                    flex:1;
                                    width: 100%;
                                    height: 100%;
                                    display: flex;
                                    justify-content: space-between;
                                }
                                .bottom{
                                    flex:2;
                                    width: 100%;
                                    height: 100%;
                                }
                            }
                        }

                }

                }

            }

        }

        .left {
            flex: 1;
            background-color: #05193C;
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 8px;

        }

        .right {
            flex: 35;
            // background-color: lightgreen;
            display: flex;
            justify-content: space-between;
            width: 100%;
            height: 100%;

            .right-item {
                flex: 1;
                // background-color: lightpink;
                // border: 1px solid #ccc;
                width: 100%;
                height: 100%;
                display: flex;
                flex-direction: column;
                // margin-left: 1px;
                padding:5px;

                .item-top {
                    flex: 1;
                    background-color: #002D6C;
                    font-size: 8px;
                    width: 100%;
                    height: 100%;
                    padding-left:3px
                }

                .item-bottom {
                    flex: 3;
                    width: 100%;
                    height: 100%;
                    background-color: #04204F;
                    font-size: 3px;
                    display: flex;
                    justify-content: space-between;
                    padding-left:3px;

                    .item-bottom-left,
                    .item-bottom-center,
                    .item-bottom-right {
                        flex: 1;
                        // background-color: #ccc;
                        width: 100%;
                        height: 100%;
                        font-size: 3px;
                        display: flex;
                        flex-direction: column;

                        .item-bottom-left-top,
                        .item-bottom-left-bottom {
                            flex: 1;
                            // background-color: #ffbfbf;
                            width: 100%;
                            height: 100%;
                            font-size: 3px;
                            display: flex;
                            justify-content: space-between;

                            .item-bottom-left-top-left {
                                flex: 1.5;
                                // background-color: #ccc;
                                width: 100%;
                                height: 100%;
                                font-size: 3px;
                                display: flex;
                                align-items: center;

                            }

                            .item-bottom-left-top-right {
                                flex: 1;
                                // background-color: #ffbfbf;
                                width: 100%;
                                height: 100%;
                                font-size: 3px;
                                /* 调整字体大小 */
                                display: flex;
                                align-items: center;
                                /* 垂直居中 */

                            }
                        }

                    }

                }

            }
        }
    }
</style>

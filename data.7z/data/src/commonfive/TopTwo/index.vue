<template>
  <div class="ech-box">
    <div class="top">
      <div class="left">
        本月机械制冷、预冷、自然冷却运行时间统计
      </div>
      <div class="right" />
    </div>
    <div class="bottom">
      <div ref="chartContainer" style="width: 100%; height: 100%;" />
    </div>

  </div>
</template>

<script>
import echarts from 'echarts'

export default {
  name: 'TopTwo',
  mounted() {
    this.renderChart()
    window.addEventListener('resize', this.handleResize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      this.chart = echarts.init(chartContainer)

      const option = {
        textStyle: {
          color: '#fff'
        },

        title: {
          //   text: '本月机械制冷、预冷、自然冷却运行时间统计',
          //   top: '5px',
          textStyle: {
            fontSize: '8px',
            color: '#fff'

          }
        },
        grid: {
          top: '40px',
          bottom: '13%',
          left: '13%',
          right: '5%'
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          //   top: '20px',
          data: ['机械制冷', '预冷', '自然冷却'],
          textStyle: {
            fontSize: 8,
            color: '#AEC8DF'
          },
          itemWidth: 6, // 设置图例项宽度
          itemHeight: 6 // 设置图例项高度
        },
        xAxis: {
          type: 'category',
          // boundaryGap: true,
          boundaryGap: false, //
          data: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31'],
          axisLabel: {
            interval: 0,
            // rotate: 45,
            textStyle: {
              fontSize: 8
            }
          }
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: true,
            lineStyle: {
              type: 'dashed' // S
            }
          },
          axisLabel: {
            textStyle: {
              fontSize: 10
            }
          }
        },
        series: [
          {
            name: '机械制冷',
            type: 'line',
            stack: 'stacked',
            data: [120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 132, 101, 134, 101, 134, 90, 220, 182, 191, 234],
            itemStyle: {
              color: '#358FC1', //
              fontSize: 10

            }
          },
          {
            name: '预冷',
            type: 'line',
            stack: 'stacked',
            data: [220, 182, 191, 234, 290, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 132, 101, 134, 134, 90, 101, 134, 90, 220, 182, 191, 234],
            itemStyle: {
              color: '#13F8FD', //
              fontSize: 10
            }
          },
          {
            name: '自然冷却',
            type: 'line',
            stack: 'stacked',
            data: [220, 182, 191, 234, 290, 191, 234, 290, 120, 132, 101, 134, 90, 220, 182, 191, 234, 290, 132, 101, 134, 134, 90, 101, 134, 90, 220, 182, 191, 234],
            itemStyle: {
              color: '#FFAC04', //
              fontSize: 10
            }
          }

        ]
      }

      this.chart.setOption(option)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    }
  }
}
</script>

<style scoped lang="scss">
.ech-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;
    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;

        }

        .right {
            display: flex;
            font-size: .2133rem;

            .day,
            .mouth,
            .year {
                background-color: #024596;
                border-radius: .1333rem;
                margin: 2px;
                padding: 2px;
                box-sizing: border-box;
                cursor: pointer;

                span {
                    color: #fff;

                }
            }

        }
    }

    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
    }

}

</style>

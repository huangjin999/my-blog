<template>
  <!-- <dv-border-box-8> -->
  <div class="ech-box-five-top">
    <div class="top">
      <div class="left">
        机械制冷、预冷、自然冷却运行时间及占比
      </div>
      <div class="right">
        <div class="day"><span>日</span></div>
        <div class="mouth"><span>月</span></div>
        <div class="year"><span>年</span></div>
      </div>
    </div>
    <div class="bottom">
      <div class="left-section">
        <div ref="chartContainer" style="width: 100%; height: 100%;" />
      </div>
      <div class="right-section">
        <div ref="chartContainers" style="width: 100%; height: 100%;" />
      </div>
    </div>
  </div>
  <!-- </dv-border-box-8> -->
</template>

<script>
import echarts from 'echarts'

export default {
  name: 'TopOne',
  mounted() {
    this.renderChart()
    window.addEventListener('resize', this.handleResize)
    window.addEventListener('resize', this.handleResizes)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
    window.removeEventListener('resize', this.handleResizes)
  },
  methods: {
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      const chartContainers = this.$refs.chartContainers
      this.chart = echarts.init(chartContainer)
      this.charts = echarts.init(chartContainers)

      // 柱状图
      const option = {
        // textStyle: {
        //     color: '#fff',
        //     fontSize: '8px',

        // },
        title: {
          // text: '机械制冷、预冷、自然冷却运行时间及占比',
          // top: '5px',
          textStyle: {
            fontSize: 10, // 设置标题字体大小
            color: '#fff'
          }
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: ['机械制冷', '预冷', '自然冷却'],
          axisTick: {
            alignWithLabel: true
          },
          axisLabel: {
            rotate: 45,
            textStyle: {
              fontSize: '5px',
              color: '#fff'
            }
          }
        },
        yAxis: {
          type: 'value',
          axisLabel: {
            textStyle: {
              fontSize: '5px',
              color: '#fff'
            }
          }
        },
        series: [
          {
            type: 'bar',
            barWidth: '30%',
            data: [
              { value: 2.0, itemStyle: { color: '#358FC1' }}, // 机械制冷的颜色
              { value: 4.9, itemStyle: { color: '#13F8FD' }}, // 预冷的颜色
              { value: 7.0, itemStyle: { color: '#FD9D04' }} // 自然冷却的颜色
            ]
          }
        ]
      }

      const options = {
        textStyle: {
          color: '#fff'
        },
        // title: {
        //     text: '',
        //     top: '5px',
        //     textStyle: {
        //         fontSize: 8,
        //         color: '#fff'
        //     }
        // },
        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b}: {c} ({d}%)'
        },
        legend: {
          top: 'auto',
          bottom: '10px',
          data: ['机械制冷', '预冷', '自然冷却'],

          textStyle: {
            fontSize: 8,
            color: '#AEC8DF'
          },
          itemWidth: 6, // 设置图例项宽度
          itemHeight: 6 // 设置图例项高度
        },
        series: [
          {
            name: '能耗占比',
            type: 'pie',
            radius: ['40%', '60%'],
            avoidLabelOverlap: false,
            label: {
              show: true,
              position: 'inside',
              formatter: '{c}', //
              fontSize: 10,
              fontWeight: 'bold'
            },
            emphasis: {
              label: {
                show: true,
                fontSize: 10,
                fontWeight: 'bold'
              }
            },
            labelLine: {
              show: false
            },
            data: [
              { value: 2.0, name: '机械制冷', itemStyle: { color: '#358FC1' }},
              { value: 4.9, name: '预冷', itemStyle: { color: '#13F8FD' }},
              { value: 7.0, name: '自然冷却', itemStyle: { color: '#FD9D04' }}

            ]
          }
        ]
      }

      this.chart.setOption(option)
      this.charts.setOption(options)
    },
    handleResize() {
      if (this.chart) {
        this.chart.resize()
      }
    },
    handleResizes() {
      if (this.charts) {
        this.charts.resize()
      }
    }
  }
}
</script>

<style scoped lang="scss">
.ech-box-five-top {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    border: 1px solid #024596;
    .top {
        flex: 0.5;
        display: flex;
        justify-content: space-between;
        height: 100%;
        width: 100%;
        padding: 5px;

        .left {
            font-size: 8px;
            margin-top: .1333rem;
            margin-left: 1%;

        }

        .right {
            display: flex;
            font-size: .2133rem;

            .day,
            .mouth,
            .year {
                background-color: #024596;
                border-radius: .1333rem;
                margin: 2px;
                padding: 2px;
                box-sizing: border-box;
                cursor: pointer;

                span {
                    color: #fff;

                }
            }

        }
    }
    .bottom {
        flex: 9;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: space-between;
        .left-section {
    flex: 1;
    width: 100%;
    height: 100%;

}

.right-section {
    flex: 1;
    width: 100%;
    height: 100%;

}
    }
}

</style>
